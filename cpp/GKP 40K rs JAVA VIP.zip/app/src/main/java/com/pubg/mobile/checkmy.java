package com.pubg.mobile;

public class checkmy {
    static int langtype = 0;
}
