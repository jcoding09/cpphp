package com.pubg.mobile;

import android.app.*;
import android.widget.*;
import android.content.*;
import android.view.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.content.res.*;
import android.util.*;
import android.os.*;
import java.io.*;
import java.security.spec.*;
import android.text.*;
import android.net.*;
import java.nio.charset.*;
import org.json.*;
import android.annotation.TargetApi;
import android.view.WindowManager.LayoutParams;

public class Launcher extends Service {	
	float density;
	RelativeLayout BM_IconLayout;
	LinearLayout BM_MainLayout;
	ImageView AM_CloseImg;
	
	LinearLayout BM_layoutlogin,BM_layoutlang,BM_loginlayer;
	static boolean lang = false;
	EditText mykey;
	Button BM_loginme,BM_pasteme;
	
	int screenHeight, screenWidth, type, dpi, lastSelectedPage = 0, CheckAttY = 0;
	SharedPreferences configPrefs, sp;
	static Context ctx;
	WindowManager windowManager;
	private static native String Check(Context mContext, String userKey);
	static boolean isBullet;
	boolean CheckAtt;
	int Colorbg = Color.parseColor("#e4a55e");
	int languageBackGround = Color.parseColor("#f40000");
	int Colorbg2 = Color.parseColor("#ffc86a");
	
	String colorBtnBlue="#2833CB";
	String colorBtnNormal = "#313439";
	String[] listTab = {"logo1.txt", "logo2.txt", "logo3.txt", "logo4.txt"};
	LinearLayout[] pageLayouts = new LinearLayout[listTab.length];
	WindowManager.LayoutParams params;
	
	private LinearLayout tabs;
	
	private LinearLayout itemlayout;
	
	private LinearLayout hidel;
	
	private LinearLayout framel;
	
	private TextView mText;
	
	private LinearLayout Holdicon;
	
	int clickme = 0;
	
	static boolean getConfig(String key) {
		SharedPreferences sp=ctx.getSharedPreferences("espValue", Context.MODE_PRIVATE);
		return sp.getBoolean(key, false);
	}
	
	private void UpdateConfiguration(String s, Object v) {
		try {
			onSendConfig(s, v.toString());
			SharedPreferences.Editor configEditor = configPrefs.edit();
			configEditor.putString(s, v.toString());
			configEditor.apply();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public void onCreate() {
		System.loadLibrary("GKPxStudio1");
		ctx = this;
		windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
		Point point = new Point();
		windowManager.getDefaultDisplay().getRealSize(point);
		
		screenWidth = point.x;
		screenHeight = point.y;
		dpi = Resources.getSystem().getDisplayMetrics().densityDpi;
		density = Resources.getSystem().getDisplayMetrics().density;
		final int n = convertSizeToDp(350.0f);
		final int n2 = convertSizeToDp(280.0f);
		
		final GradientDrawable gd = new GradientDrawable();
		gd.setCornerRadius(10.0f);
		gd.setColor(Colorbg);
		gd.setStroke(2, Color.parseColor("#09101a"));
		final GradientDrawable gd2 = new GradientDrawable();
		gd2.setCornerRadius(10.0f);
		gd2.setColor(Colorbg2);
		gd2.setStroke(2, Color.parseColor("#09101a"));
		
		LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1,dp(40));
		ip.setMargins(dp(20),0,dp(20),dp(4));
		LinearLayout.LayoutParams ipg = new LinearLayout.LayoutParams(-1,dp(40));
		ipg.setMargins(dp(40),dp(10),dp(40),dp(10));
		LinearLayout.LayoutParams ip2 = new LinearLayout.LayoutParams(-1,-1);
		ip2.setMargins(dp(5),0,dp(5),dp(0));
		ip2.weight = 1f;
		LinearLayout.LayoutParams ip3 = new LinearLayout.LayoutParams(-1,dp(40));
		ip3.setMargins(dp(40),dp(10),dp(40),dp(10));
		
		final GradientDrawable ARUSI = new GradientDrawable();
		ARUSI.setCornerRadius(10.0f);
		ARUSI.setColor(Colorbg);
		
		BM_layoutlogin = new LinearLayout(this);
		BM_layoutlogin.setLayoutParams(new LinearLayout.LayoutParams(-1,-1));
		BM_layoutlogin.setOrientation(LinearLayout.VERTICAL);
		BM_layoutlogin.setGravity(Gravity.CENTER);
		BM_layoutlogin.setClickable(true);
		BM_layoutlogin.setFocusable(true);
		BM_layoutlogin.setFocusableInTouchMode(true);
		BM_layoutlogin.setBackground(ARUSI);
		TextView txtl = new TextView(this);
		txtl.setText("Login To Continue...");
		txtl.setTextSize(14);
		txtl.setGravity(Gravity.CENTER);
		txtl.setTextColor(Color.parseColor("#000000"));
		
		GradientDrawable gdm = new GradientDrawable();
		gdm.setCornerRadius(dp(10));
		gdm.setStroke(1, Color.parseColor("#000000"));
		gdm.setColor(Color.parseColor("#efefef"));
		
		BM_loginlayer =new LinearLayout(this);
		BM_loginlayer.setLayoutParams(ipg);
		BM_loginlayer.setOrientation(LinearLayout.HORIZONTAL);
		BM_loginlayer.setGravity(Gravity.CENTER);
		BM_loginlayer.setBackground(gdm);
		BM_loginlayer.setPadding(10,10,5,5);
		
		mykey = new EditText(this);
		mykey.setBackgroundColor(Color.TRANSPARENT);
		mykey.setLayoutParams(ip2);
		mykey.setHint("Enter Your Lincence...");
		mykey.setSingleLine(true);
		mykey.setTextSize(12);
		mykey.setHintTextColor(Color.parseColor("#000000"));
		
		GradientDrawable gdmm = new GradientDrawable();
		gdmm.setCornerRadius(dp(10));
		gdmm.setStroke(1, Color.parseColor("#000000"));
		gdmm.setColor(Color.parseColor("#f40000"));
		GradientDrawable gdm2 = new GradientDrawable();
		gdm2.setCornerRadius(dp(10));
		gdm.setStroke(1, Color.parseColor("#000000"));
		gdm2.setColor(Color.parseColor("#f40000"));
		
		BM_pasteme = new Button(this);
		BM_pasteme.setBackground(gdmm);
		BM_pasteme.setLayoutParams(ip3);
		BM_pasteme.setText("Click Me To Paste Key");
		BM_pasteme.setTextSize(12);
		BM_pasteme.setGravity(Gravity.CENTER);
		BM_pasteme.setTextColor(Color.BLACK);
		mykey.setTextColor(Color.BLACK);
		
		BM_loginme = new Button(this);
		BM_loginme.setBackground(gdm2);
		BM_loginme.setLayoutParams(ip3);
		BM_loginme.setText("Verify Key");
		BM_loginme.setTextColor(Color.BLACK);
		BM_loginme.setTextSize(14);
		BM_pasteme.setOnClickListener(new View.OnClickListener(){
				public void onClick(View v){
					android.content.ClipboardManager clipboard = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
					ClipData clipData = clipboard.getPrimaryClip();
					if ((clipData != null)) {
						String s = clipData.getItemAt(0).getText().toString();
						// Toast.makeText(getApplicationContext(),s,1).show();
						mykey.setText(s);
					} else {
						Toast.makeText(getApplicationContext(),"First copy key",1).show();
					}
				}
			});
		
		BM_loginme.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				Login(getApplicationContext(),mykey.getText().toString());
			}
		});
		
		TextView txt2 = new TextView(this);
		txt2.setText("GKP MODS PREMIUM");
		txt2.setTextSize(25);
		Typeface h = Typeface.createFromAsset(getAssets(), "Title.ttf"); 
		txt2.setTypeface(h);
		txt2.setGravity(Gravity.CENTER);
		txt2.setTextColor(Color.parseColor("#000000"));
		
		BM_layoutlogin.addView(txt2);
		BM_layoutlogin.addView(txtl);
		BM_layoutlogin.addView(BM_loginlayer);
		BM_loginlayer.addView(mykey);
		BM_layoutlogin.addView(BM_pasteme);
		BM_layoutlogin.addView(BM_loginme);
		
		BM_layoutlang = new LinearLayout(this);
		BM_layoutlang.setLayoutParams(new LinearLayout.LayoutParams(-1,-1));
		BM_layoutlang.setOrientation(LinearLayout.VERTICAL);
		BM_layoutlang.setGravity(Gravity.CENTER);
		TextView txt = new TextView(this);
		txt.setText("Choose A Language");
		txt.setTextSize(18);
		txt.setGravity(Gravity.CENTER);
		txt.setTextColor(Color.parseColor("#f40000"));
		
		BM_layoutlang.addView(txt);
		GradientDrawable btngd = new GradientDrawable();
		btngd.setColor(languageBackGround);
		btngd.setCornerRadius(dp(5));
		
		Button engbtn = new Button(this);
		engbtn.setText("English");
		engbtn.setTextSize(15);
		engbtn.setTextColor(Color.BLACK);
		engbtn.setLayoutParams(ip);
		engbtn.setBackground(btngd);
		BM_layoutlang.addView(engbtn);
		Button cnbtn = new Button(this);
		cnbtn.setText("中国人");
		cnbtn.setTextSize(15);
		cnbtn.setTextColor(Color.BLACK);
		cnbtn.setLayoutParams(ip);
		cnbtn.setBackground(btngd);
		BM_layoutlang.addView(cnbtn);
		Button arbtn = new Button(this);
		arbtn.setText("عربى");
		arbtn.setTextSize(15);
		arbtn.setTextColor(Color.BLACK);
		arbtn.setLayoutParams(ip);
		arbtn.setBackground(btngd);
		BM_layoutlang.addView(arbtn);
		
		BM_MainLayout = new LinearLayout((Context)this);
		BM_MainLayout.setLayoutParams((ViewGroup.LayoutParams)new LinearLayout.LayoutParams(n2, n));
		BM_MainLayout.setOrientation(LinearLayout.VERTICAL);
		BM_MainLayout.setPadding(dp(5), dp(5), dp(5), dp(5));
		BM_MainLayout.setBackgroundDrawable(gd);
		BM_MainLayout.addView(BM_layoutlogin);
		BM_MainLayout.addView(BM_layoutlang);
		// ==========================//
		framel = new LinearLayout(this);
		framel.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(40)));
		int[] colorsCRNAV = { Color.parseColor("#ffc86a"), Color.parseColor("#ffc86a") }; android.graphics.drawable.GradientDrawable CRNAV = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNAV);
		CRNAV.setCornerRadii(new float[]{(int)23,(int)23,(int)23,(int)23,(int)23,(int)23,(int)23,(int)23});
		CRNAV.setStroke((int) 3, Color.parseColor("#000000"));
		framel.setElevation((float) 3);
		framel.setBackground(CRNAV);
		framel.setGravity(Gravity.CENTER);
		
		mText = new TextView(this);
		mText.setText("GKP MODS PREMIUM");
		Typeface g = Typeface.createFromAsset(getAssets(), "Title.ttf"); 
		mText.setTypeface(g);
		mText.setTextColor(Color.parseColor("#45585f"));
		
		mText.setTextSize(20f);
		Holdicon = new LinearLayout(this);
		Holdicon.setOrientation(0);
		Holdicon.setLayoutParams(new LinearLayout.LayoutParams(-1,-1));
		framel.addView(mText);
		LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(-2,-1);
		// ==========================//
		lp2.setMargins(10,10,10,10);
		tabs = new LinearLayout(this);
		tabs.setOrientation(1);
		tabs.setLayoutParams(lp2);
		
		itemlayout = new LinearLayout(this);
		itemlayout.setOrientation(1);
		LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-1);
		lp.weight=1.0f;
		lp.setMargins(10,10,10,10);
		itemlayout.setLayoutParams(lp);
		itemlayout.setBackground(gd2);

		final GradientDrawable bishnoi_tabd = new GradientDrawable();
		bishnoi_tabd.setColor(Colorbg2);
		bishnoi_tabd.setCornerRadius(10f);
		bishnoi_tabd.setStroke(2, Color.parseColor("#000000"));
		
		final GradientDrawable tabons = new GradientDrawable();
		tabons.setColor(Colorbg2);
		tabons.setCornerRadius(10f);
		tabons.setStroke(3, Color.parseColor("#000000"));
		
		final LinearLayout[] tabButtons = new LinearLayout[listTab.length];
		for (int i = 0; i < tabButtons.length; i++) {
			pageLayouts[i] = new LinearLayout(this);
			pageLayouts[i].setPadding(25, 25, 25, 25);
			pageLayouts[i].setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, convertSizeToDp(25) + convertSizeToDp(15)));
			pageLayouts[i].setOrientation(LinearLayout.VERTICAL);

			final ScrollView scrollView = new ScrollView(this);
			scrollView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
			scrollView.setScrollBarSize(0);
			scrollView.setElevation(15f);
			
			scrollView.addView(pageLayouts[i]);

			tabButtons[i] = new LinearLayout(this);
			LinearLayout.LayoutParams ErrolDec= new LinearLayout.LayoutParams(dp(60),dp(52));
			ErrolDec.setMargins(dp(2), dp(2), dp(2), dp(2)); // Space
			tabButtons[i].setLayoutParams(ErrolDec);
			tabButtons[i].setPadding(0, 0, 0, 0);			
			tabButtons[i].setGravity(Gravity.CENTER);
			if (i != 0) {
				tabButtons[i].setBackground(bishnoi_tabd);
				pageLayouts[i].setVisibility(View.GONE);
			} else {
				tabButtons[i].setBackground(tabons);
				pageLayouts[i].setVisibility(View.VISIBLE);
			}
			ImageView img = new ImageView(this);
			img.setLayoutParams(new LinearLayout.LayoutParams(dp(30),dp(30)));
			setImageFromAssets(img,listTab[i]);
			tabButtons[i].addView(img);
			final int curTab = i;
			tabButtons[i].setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
					
						if (curTab != lastSelectedPage) {
							
							tabButtons[curTab].setBackgroundDrawable(tabons);	
							pageLayouts[curTab].setVisibility(View.VISIBLE);
							pageLayouts[lastSelectedPage].setVisibility(View.GONE);
							tabButtons[lastSelectedPage].setBackgroundDrawable(bishnoi_tabd);
							lastSelectedPage = curTab;
						}
					}
				});
			tabs.addView(tabButtons[i]);
			itemlayout.addView(scrollView);
		}	
		BM_MainLayout.addView(framel);
		BM_MainLayout.addView(Holdicon);
		Holdicon.addView(tabs);
		Holdicon.addView(itemlayout);		
		this.type = Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O ? 2038 : 2002;
		params = new WindowManager.LayoutParams(-2, -2, this.type, 8, -3);
		params.gravity = 51;
		params.x = 0;
		params.y = 0; 

		this.type = Build.VERSION.SDK_INT >= 26 ? 2038 : 2002;
		final WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(n, n2, this.type, 520, -3);
		layoutParams.x = 0;//150
		layoutParams.y = 0;//150
		layoutParams.gravity = Gravity.START | Gravity.TOP;
		View.OnTouchListener onTitleListener = new View.OnTouchListener() {
			float pressedX;
			float pressedY;
			float deltaX;
			float deltaY;
			float newX;
			float newY;
			float maxX;
			float maxY;

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getActionMasked()) {
					case MotionEvent.ACTION_DOWN:
						deltaX = layoutParams.x - event.getRawX();
						deltaY = layoutParams.y - event.getRawY();
						pressedX = event.getRawX();
						pressedY = event.getRawY();
						break;
					case MotionEvent.ACTION_MOVE:
						newX = event.getRawX() + deltaX;
						newY = event.getRawY() + deltaY;
						maxX = screenWidth - BM_MainLayout.getWidth();
						maxY = screenHeight - BM_MainLayout.getHeight();
						if (newX < 0)
							newX = 0;
						if (newX > maxX)
							newX = (int) maxX;
						if (newY < 0)
							newY = 0;
						if (newY > maxY)
							newY = (int) maxY;
						layoutParams.x = (int) newX;
						layoutParams.y = (int) newY;
						windowManager.updateViewLayout(BM_MainLayout, layoutParams);
						break;
					default:
						break;
				}
				return false;
			}
		};
		BM_MainLayout.setOnTouchListener(onTitleListener);
		BM_layoutlogin.setOnTouchListener(onTitleListener);
		

		BM_IconLayout = new RelativeLayout(this);
		BM_IconLayout.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
		ImageView imageView = new ImageView(this);
		setImageFromAssets(imageView, "logo.png");
		BM_IconLayout.addView((View)imageView, convertSizeToDp(50.0f), convertSizeToDp(50.0f));

		final WindowManager.LayoutParams layoutParams2 = new WindowManager.LayoutParams(-2, -2, type, 8, -3);
		layoutParams2.gravity = 51;
		layoutParams2.x = 0;
		layoutParams2.y = 0;
		BM_IconLayout.setVisibility(0);
		BM_MainLayout.setVisibility(8);
		windowManager.addView(BM_IconLayout, layoutParams2);
		windowManager.addView(BM_MainLayout, layoutParams);
		BM_IconLayout.setOnTouchListener(new View.OnTouchListener() {
				float pressedX;
				float pressedY;
				float deltaX;
				float deltaY;
				float newX;
				float newY;
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getActionMasked()) {
						case MotionEvent.ACTION_DOWN:
							deltaX = layoutParams2.x - event.getRawX();
							deltaY = layoutParams2.y - event.getRawY();
							pressedX = event.getRawX();
							pressedY = event.getRawY();
							break;
						case MotionEvent.ACTION_UP:
							int Xdiff = (int) (event.getRawX() - pressedX);
							int Ydiff = (int) (event.getRawY() - pressedY);
							if (Xdiff == 0 && Ydiff == 0) {
								BM_MainLayout.setVisibility(View.VISIBLE);
								BM_IconLayout.setVisibility(View.GONE);
							}
							return true;
						case MotionEvent.ACTION_MOVE:
							newX = event.getRawX() + deltaX;
							newY = event.getRawY() + deltaY;
							float maxX = screenWidth - v.getWidth();
							float maxY = screenHeight - v.getHeight();
							if (newX < 0)
								newX = 0;
							if (newX > maxX)
								newX = (int) maxX;
							if (newY < 0)
								newY = 0;
							if (newY > maxY)
								newY = (int) maxY;
							layoutParams2.x = (int) newX;
							layoutParams2.y = (int) newY;
							windowManager.updateViewLayout(BM_IconLayout, layoutParams2);
							break;
						default:
							break;
					}
					return false;
				}
			});
			
			engbtn.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					lang = true;
					 checkmy.langtype = 0;
					BM_layoutlang.setVisibility(View.GONE);
					BM_MainLayout.setVisibility(View.VISIBLE);
					engfeature();
				}
			});
		cnbtn.setOnClickListener(new View.OnClickListener(){
				public void onClick(View v){
					lang = true;
					checkmy.langtype = 1;
					
					BM_layoutlang.setVisibility(View.GONE);
					BM_MainLayout.setVisibility(View.VISIBLE);
					cnfeatures();
				}
			});
		arbtn.setOnClickListener(new View.OnClickListener(){
				public void onClick(View v){
					lang = true;
					 checkmy.langtype = 2;
					BM_layoutlang.setVisibility(View.GONE);
					BM_MainLayout.setVisibility(View.VISIBLE);
					arfeatures();
				}
			});
			
			
			
			
			
			
			
			
			txt2.setOnClickListener(new View.OnClickListener(){
			public void onClick(View view) {
				BM_MainLayout.setVisibility(8);
				BM_IconLayout.setVisibility(0);
			}
		});
		
		mText.setOnClickListener(new View.OnClickListener(){
			public void onClick(View view) {
				BM_MainLayout.setVisibility(8);
				BM_IconLayout.setVisibility(0);
			}
		});
		mText.setOnClickListener(new View.OnClickListener() {
				@Override
			public void onClick(View v) {	 
			if (clickme ==0) {
				clickme = clickme+1;
				Toast.makeText(getApplicationContext(),"If you want to close floating, tap 2 times in 1 second", 1).show();
			}
			else
				if (clickme ==1) {
					clickme = 0;
					BM_MainLayout.setVisibility(8);
					BM_IconLayout.setVisibility(0);
				}
			}
		});
		}
		
		
		void engfeature(){
			 
		AddText(0, "ENGLISH LANGUAGE", "#000000");
		
		
		//-----------------------FEATURES-----------------------\\
		AddSwitch(0,"𝗦𝗽𝗼𝘄𝗻 𝗜𝘀𝗹𝗮𝗻𝗱 𝗕𝘆𝗽𝗮𝘀𝘀", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration("ISLAND_BYPASS", isChecked ? 1 : 0);	
			}
		}); 
		AddText(0, "𝗘𝗦𝗣 𝗚𝗲𝗻𝗲𝗿𝗶𝗰 𝗔𝗱𝗷𝘂𝘀𝘁𝗺𝗲𝗻𝘁", "#000000");
		AddCheckBox1(0,"Line", "Box", "Bone", "ESP::LINE", "ESP::BOX", "ESP::BONE");
		AddCheckBox1(0,"Health", "Name", "Distance", "ESP::HEALTH", "ESP::NAME", "ESP::DISTANCE");
		AddCheckBox1(0,"TeamID", "Head", "Nation", "ESP::TEAMID", "ESP::HEAD", "ESP::NATIONUID");
		// UID
		AddText(0, "𝗦𝗽𝗲𝗰𝗶𝗮𝗹 𝗙𝗲𝗮𝘁𝘂𝗿𝗲𝘀", "#000000");
		AddSwitch(0,"Throwable's Warning", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration("ESP::WARNING", isChecked ? 1 : 0);	
			}
		});
		AddSwitch(0,"Show Radar Map", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration("ESP::RADAR", isChecked ? 1 : 0);	
			}
		});
		AddSwitch(0,"Show LootBox", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration("ESP::DEADBOX", isChecked ? 1 : 0);
			}
		});
		AddSwitch(0,"Show LootBox Content", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration("ESP::DEADBOXITEMS", isChecked ? 1 : 0);
			}
		});
		AddSwitch(0,"Show 360 Alert", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration("ESP::360ALERT", isChecked ? 1 : 0);
			}
		});
		AddSwitch(0,"Show On Screen Alert", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration("ESP::ONSCREENALERT", isChecked ? 1 : 0);
			}
		});
		AddSwitch(0,"Enemy Aiming", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					UpdateConfiguration("ESP::ENEMYAIMING", isChecked ? 1 : 0);
				}
			});
		AddSwitch(0,"Don't Show Bots / Hide Al", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration("ESP::NOBOT", isChecked ? 1 : 0);
			}
		});
		AddText(0, "𝗩𝗲𝗵𝗰𝗶𝗹𝗲𝘀 𝗘𝗦𝗣", "#000000");
		AddSwitch(0,"All Vehciles Name & Distance", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration("ESP::VEHICLE", isChecked ? 1 : 0);
			}
		});
		AddSwitch(0,"Show All Vehciles Health", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration("ESP::VEHICLEHPALL", isChecked ? 1 : 0);
			}
		});
		AddSwitch(0,"Show All Vehciles Fuel", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration("ESP::VEHICLEFUELALL", isChecked ? 1 : 0);
			}
		});
		// =============================
		String str = "itemCategory";
		try {
			InputStream is = getAssets().open("items.png");
			byte[] buffer = new byte[is.available()];
			if (is.read(buffer) > 0) {
				is.close();
				String json = new String(buffer, StandardCharsets.UTF_8);
				UpdateConfiguration("CMD_PARSE_ITEMS", json);
				JSONArray arr = new JSONArray(json);
				for (int i = 0; i < arr.length(); i++) {
					JSONObject obj = arr.getJSONObject(i);
					if (obj.has(str)) {
						if ((obj.getString(str)).equals("Muzzle")) {
							CheckAttY = 1;
						}
						if (CheckAttY == 1) {
							AddText(1, obj.getString(str), "#000000");
						} else {
							AddText(1, obj.getString(str), "#000000");
						}
					} else {
						final String itemName = obj.getString("itemName");
						final int itemId = obj.getInt("itemId");
						i += 1;
						obj = arr.getJSONObject(i);
						if (obj.has(str)) {
							if ((obj.getString(str)).equals("Muzzle")) {
								CheckAttY = 1;
							}
							if (CheckAttY == 1) {
								AddText(1, obj.getString(str), "#000000");
							} else {
								AddText(1, obj.getString(str), "#000000");
							}
						} 
						if (!obj.has(str)) {
							final String itemName1 = obj.getString("itemName");
							final int itemId1 = obj.getInt("itemId");
							if (CheckAttY == 1) {
								AddSwitchItems(1, "ESP::ITEMS", itemName, itemName1, itemId, itemId1);
							} else {
								AddSwitchItems(1, "ESP::ITEMS", itemName, itemName1, itemId, itemId1);
							}
						}
					}
				}
			}
		} catch (Exception ex) {
		 ex.printStackTrace();
		}
// =============================
		AddSwitch(2,"Enable Aim", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if (isChecked) {
					startService(new Intent(getApplicationContext(),AimMenu.class));
					isBullet = true;
				} else {
					stopService(new Intent(getApplicationContext(),AimMenu.class));
					isBullet = false;
				}
			}
		});
		AddSwitch(2,"Prediction", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
	    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					UpdateConfiguration("AIM_PREDICTION", isChecked ? 1 : 0);
				}
			});
		
		AddRadioButton(2, new String[]{"Bullet Track", "Aimbot"}, 0, new RadioGroup.OnCheckedChangeListener() {
				public void onCheckedChanged(RadioGroup radioGroup, int i) {
					UpdateConfiguration("AIM_MODE", i);
				}
			});

		AddText(2, "𝗔𝗶𝗺 𝗧𝗮𝗿𝗴𝗲𝘁", "#000000");
		AddRadioButton(2, new String[]{"Shortest Distance", "Inside FOV"}, 0, new RadioGroup.OnCheckedChangeListener() {
				public void onCheckedChanged(RadioGroup radioGroup, int i) {
					UpdateConfiguration("AIM_TARGET_BY", i);
				}
			});
		int FOVSize = 0;
		AddSeekbar(2, "FOV Size", 0, 350, FOVSize, "", "", new SeekBar.OnSeekBarChangeListener() {
				public void onProgressChanged(SeekBar seekBar, int img, boolean isChecked) {
					UpdateConfiguration("AIM_INSIDE_FOV", img);
				}
				public void onStartTrackingTouch(SeekBar seekBar) {
				}
				public void onStopTrackingTouch(SeekBar seekBar) {
				}
			});
	 AddSwitch(2,"Recoil Compensation", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					UpdateConfiguration("RECOIL_COMPENSATION", isChecked ? 1 : 0);
				}
			}); 
		int RecoilCompensation  =0;
		AddSeekbar(2, "Recoil Value", 0, 2, RecoilCompensation, "", "", new SeekBar.OnSeekBarChangeListener(){
				public void onProgressChanged(SeekBar seekBar, int n, boolean isChecked) {
					UpdateConfiguration("RECOIL_COMPARISON_VALUE", n);
				}
				public void onStartTrackingTouch(SeekBar seekBar) {
				}
				public void onStopTrackingTouch(SeekBar seekBar) {
				}
			}); 
		AddText(2, "𝗔𝗶𝗺 𝗟𝗼𝗰𝗮𝘁𝗶𝗼𝗻", "#000000");
		AddRadioButton(2, new String[]{"Head", "Chest"}, 0, new RadioGroup.OnCheckedChangeListener(){
				public void onCheckedChanged(RadioGroup radioGroup, int i) {
					UpdateConfiguration("AIM::AIMPOS", i);
				}
			});
		AddText(2, "𝗧𝗿𝗶𝗴𝗴𝗲𝗿 𝗧𝘆𝗽𝗲", "#000000");
		AddRadioButton(2, new String[]{"Nothing", "Fire Only", "Scope Only", "Fire & Scope"}, 0, new RadioGroup.OnCheckedChangeListener(){
				public void onCheckedChanged(RadioGroup radioGroup, int i) {
					UpdateConfiguration("AIM::TRIGGER", i);
				}
			});
		AddSwitch(2,"Visibility Check", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					UpdateConfiguration("AIM::VISICHECK", isChecked ? 1 : 0);
				}
			});
		AddSwitch(2,"Ignore Knock", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					UpdateConfiguration("AIM::IGKNOCK", isChecked ? 1 : 0);
				}
			});
		AddSwitch(2,"Ignore Bot", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					UpdateConfiguration("AIM::IGBOT", isChecked ? 1 : 0);
				}
			});   
			
		AddSwitch(2,"𝐒𝐮𝐩𝐞𝐫 𝐀𝐢𝐦", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					UpdateConfiguration("AIM_LESS", isChecked ? 1 : 0);
				}
			});
		AddSwitch(2,"X Hit Effect", false, new CompoundButton.OnCheckedChangeListener() {
		@Override
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		 UpdateConfiguration("GKPMODS::XHIT", isChecked ? 1 : 0);
				}
			}); 
		AddSwitch(2,"Small Crosshair", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					UpdateConfiguration("GKPMODS::CROSS", isChecked ? 1 : 0);
				}
			}); 					
		// =============================
		AddSeekbar(3, "Radar Pos.X", 0, 140, 0, "", "", new SeekBar.OnSeekBarChangeListener(){
			public void onProgressChanged(SeekBar seekBar, int n, boolean isChecked) {
				UpdateConfiguration("RADAR::X",n);
			}
			public void onStartTrackingTouch(SeekBar seekBar) {
			}
			public void onStopTrackingTouch(SeekBar seekBar) {
			}
		});
		AddSeekbar(3, "Radar Pos.Y", 0, 52, 0, "", "", new SeekBar.OnSeekBarChangeListener(){
			public void onProgressChanged(SeekBar seekBar, int n, boolean isChecked) {
				UpdateConfiguration("RADAR::Y",n);
			}
			public void onStartTrackingTouch(SeekBar seekBar) {
			}
			public void onStopTrackingTouch(SeekBar seekBar) {
			}
		});
		AddSeekbar(3, "LootBox Content Max Distance", 0, 500, 10, "", " ", new SeekBar.OnSeekBarChangeListener(){
			public void onProgressChanged(SeekBar seekBar, int n, boolean isChecked) {
				UpdateConfiguration("ESP_LOOT_BOX_MAX_DISTANCE",n);
			}
			public void onStartTrackingTouch(SeekBar seekBar) {
			}
			public void onStopTrackingTouch(SeekBar seekBar) {
			}
		});
		AddSeekbar(3, "ESP Framerate", 30, 120, 60, "", " FPS", new SeekBar.OnSeekBarChangeListener(){
			public void onProgressChanged(SeekBar seekBar, int n, boolean isChecked) {
				UpdateConfiguration("ESP::FREMERATE",n);
			}
			public void onStartTrackingTouch(SeekBar seekBar) {
			}
			public void onStopTrackingTouch(SeekBar seekBar) {
			}
		});
		AddSeekbar(3, "Image transparency", 0, 10, 10, "", "", new SeekBar.OnSeekBarChangeListener(){
			public void onProgressChanged(SeekBar seekBar, int img, boolean isChecked) {
				BM_IconLayout.setAlpha((float)img / 10.0f);
			}
			public void onStartTrackingTouch(SeekBar seekBar) {
				BM_IconLayout.setVisibility(0);
			}
			public void onStopTrackingTouch(SeekBar seekBar) {
				BM_IconLayout.setVisibility(8);
			}
		});
		AddSeekbar(3, "Menu transparency", 0, 10, 10, "", "", new SeekBar.OnSeekBarChangeListener(){
			public void onProgressChanged(SeekBar seekBar, int trans, boolean isChecked) {
				BM_MainLayout.setAlpha((float)trans / 10.0f);
			}
			public void onStartTrackingTouch(SeekBar seekBar) {
			}
			public void onStopTrackingTouch(SeekBar seekBar) {
			}
		});
	}






void cnfeatures(){
			 
		AddText(0, "CHINA LANGUAGE", "#000000");
		//-----------------------FEATURES-----------------------\\
		AddSwitch(0,"𝗦𝗽𝗼𝘄𝗻 𝗜𝘀𝗹𝗮𝗻𝗱 𝗕𝘆𝗽𝗮𝘀𝘀", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration("ISLAND_BYPASS", isChecked ? 1 : 0);	
			}
		}); 
		AddText(0, "𝗘𝗦𝗣 𝗚𝗲𝗻𝗲𝗿𝗶𝗰 𝗔𝗱𝗷𝘂𝘀𝘁𝗺𝗲𝗻𝘁", "#000000");
		AddCheckBox1(0,"Line", "Box", "Bone", "ESP::LINE", "ESP::BOX", "ESP::BONE");
		AddCheckBox1(0,"Health", "Name", "Distance", "ESP::HEALTH", "ESP::NAME", "ESP::DISTANCE");
		AddCheckBox1(0,"TeamID", "Head", "Nation", "ESP::TEAMID", "ESP::HEAD", "ESP::NATIONUID");
		// UID
		AddText(0, "𝗦𝗽𝗲𝗰𝗶𝗮𝗹 𝗙𝗲𝗮𝘁𝘂𝗿𝗲𝘀", "#000000");
		AddSwitch(0,"Throwable's Warning", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration("ESP::WARNING", isChecked ? 1 : 0);	
			}
		});
		AddSwitch(0,"Show Radar Map", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration("ESP::RADAR", isChecked ? 1 : 0);	
			}
		});
		AddSwitch(0,"Show LootBox", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration("ESP::DEADBOX", isChecked ? 1 : 0);
			}
		});
		AddSwitch(0,"Show LootBox Content", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration("ESP::DEADBOXITEMS", isChecked ? 1 : 0);
			}
		});
		AddSwitch(0,"Show 360 Alert", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration("ESP::360ALERT", isChecked ? 1 : 0);
			}
		});
		AddSwitch(0,"Show On Screen Alert", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration("ESP::ONSCREENALERT", isChecked ? 1 : 0);
			}
		});
		AddSwitch(0,"Enemy Aiming", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					UpdateConfiguration("ESP::ENEMYAIMING", isChecked ? 1 : 0);
				}
			});
		AddSwitch(0,"Don't Show Bots / Hide Al", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration("ESP::NOBOT", isChecked ? 1 : 0);
			}
		});
		AddText(0, "𝗩𝗲𝗵𝗰𝗶𝗹𝗲𝘀 𝗘𝗦𝗣", "#000000");
		AddSwitch(0,"All Vehciles Name & Distance", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration("ESP::VEHICLE", isChecked ? 1 : 0);
			}
		});
		AddSwitch(0,"Show All Vehciles Health", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration("ESP::VEHICLEHPALL", isChecked ? 1 : 0);
			}
		});
		AddSwitch(0,"Show All Vehciles Fuel", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration("ESP::VEHICLEFUELALL", isChecked ? 1 : 0);
			}
		});
		// =============================
		String str = "itemCategory";
		try {
			InputStream is = getAssets().open("items.png");
			byte[] buffer = new byte[is.available()];
			if (is.read(buffer) > 0) {
				is.close();
				String json = new String(buffer, StandardCharsets.UTF_8);
				UpdateConfiguration("CMD_PARSE_ITEMS", json);
				JSONArray arr = new JSONArray(json);
				for (int i = 0; i < arr.length(); i++) {
					JSONObject obj = arr.getJSONObject(i);
					if (obj.has(str)) {
						if ((obj.getString(str)).equals("Muzzle")) {
							CheckAttY = 1;
						}
						if (CheckAttY == 1) {
							AddText(1, obj.getString(str), "#000000");
						} else {
							AddText(1, obj.getString(str), "#000000");
						}
					} else {
						final String itemName = obj.getString("itemName");
						final int itemId = obj.getInt("itemId");
						i += 1;
						obj = arr.getJSONObject(i);
						if (obj.has(str)) {
							if ((obj.getString(str)).equals("Muzzle")) {
								CheckAttY = 1;
							}
							if (CheckAttY == 1) {
								AddText(1, obj.getString(str), "#000000");
							} else {
								AddText(1, obj.getString(str), "#000000");
							}
						} 
						if (!obj.has(str)) {
							final String itemName1 = obj.getString("itemName");
							final int itemId1 = obj.getInt("itemId");
							if (CheckAttY == 1) {
								AddSwitchItems(1, "ESP::ITEMS", itemName, itemName1, itemId, itemId1);
							} else {
								AddSwitchItems(1, "ESP::ITEMS", itemName, itemName1, itemId, itemId1);
							}
						}
					}
				}
			}
		} catch (Exception ex) {
		 ex.printStackTrace();
		}
// =============================
		AddSwitch(2,"Enable Aim", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					if(isChecked) {
						startService(new Intent(getApplicationContext(),AimMenu.class));
						isBullet = true;
					} else {
						stopService(new Intent(getApplicationContext(),AimMenu.class));
						isBullet = false;	
					}
				}
			});
		AddSwitch(2,"Prediction", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
	   public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					UpdateConfiguration("AIM_PREDICTION", isChecked ? 1 : 0);
				}
			}); 
		
		AddText(2, "𝗔𝗶𝗺 𝗧𝗮𝗿𝗴𝗲𝘁", "#000000");
		AddRadioButton(2, new String[]{"Shortest Distance", "Inside FOV"}, 0, new RadioGroup.OnCheckedChangeListener() {
				public void onCheckedChanged(RadioGroup radioGroup, int i) {
					UpdateConfiguration("AIM_TARGET_BY", i);
				}
			});
		int FOVSize = 0;
		AddSeekbar(2, "FOV Size", 0, 350, FOVSize, "", "", new SeekBar.OnSeekBarChangeListener() {
				public void onProgressChanged(SeekBar seekBar, int img, boolean isChecked) {
					UpdateConfiguration("AIM_INSIDE_FOV", img);
				}
				public void onStartTrackingTouch(SeekBar seekBar) {
				}
				public void onStopTrackingTouch(SeekBar seekBar) {
				}
			});
	 AddSwitch(2,"Recoil Compensation", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					UpdateConfiguration("RECOIL_COMPENSATION", isChecked ? 1 : 0);
				}
			}); 
		int RecoilCompensation  =0;
		AddSeekbar(2, "Recoil Value", 0, 2, RecoilCompensation, "", "", new SeekBar.OnSeekBarChangeListener(){
				public void onProgressChanged(SeekBar seekBar, int n, boolean isChecked) {
					UpdateConfiguration("RECOIL_COMPARISON_VALUE", n);
				}
				public void onStartTrackingTouch(SeekBar seekBar) {
				}
				public void onStopTrackingTouch(SeekBar seekBar) {
				}
			}); 
		AddText(2, "𝗔𝗶𝗺 𝗟𝗼𝗰𝗮𝘁𝗶𝗼𝗻", "#000000");
		AddRadioButton(2, new String[]{"Head", "Chest"}, 0, new RadioGroup.OnCheckedChangeListener(){
				public void onCheckedChanged(RadioGroup radioGroup, int i) {
					UpdateConfiguration("AIM::AIMPOS", i);
				}
			});
		AddText(2, "𝗧𝗿𝗶𝗴𝗴𝗲𝗿 𝗧𝘆𝗽𝗲", "#000000");
		AddRadioButton(2, new String[]{"Nothing", "Fire Only", "Scope Only", "Fire & Scope"}, 0, new RadioGroup.OnCheckedChangeListener(){
				public void onCheckedChanged(RadioGroup radioGroup, int i) {
					UpdateConfiguration("AIM::TRIGGER", i);
				}
			});
		AddSwitch(2,"Visibility Check", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					UpdateConfiguration("AIM::VISICHECK", isChecked ? 1 : 0);
				}
			});
		AddSwitch(2,"Ignore Knock", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					UpdateConfiguration("AIM::IGKNOCK", isChecked ? 1 : 0);
				}
			});
		AddSwitch(2,"Ignore Bot", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					UpdateConfiguration("AIM::IGBOT", isChecked ? 1 : 0);
				}
			});   
			
		AddSwitch(2,"𝐒𝐮𝐩𝐞𝐫 𝐀𝐢𝐦", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					UpdateConfiguration("AIM_LESS", isChecked ? 1 : 0);
				}
			});
		AddSwitch(2,"X Hit Effect", false, new CompoundButton.OnCheckedChangeListener() {
		@Override
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		 UpdateConfiguration("GKPMODS::XHIT", isChecked ? 1 : 0);
				}
			}); 
		AddSwitch(2,"Small Crosshair", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					UpdateConfiguration("GKPMODS::CROSS", isChecked ? 1 : 0);
				}
			}); 					
		// =============================
		AddSeekbar(3, "Radar Pos.X", 0, 140, 0, "", "", new SeekBar.OnSeekBarChangeListener(){
			public void onProgressChanged(SeekBar seekBar, int n, boolean isChecked) {
				UpdateConfiguration("RADAR::X",n);
			}
			public void onStartTrackingTouch(SeekBar seekBar) {
			}
			public void onStopTrackingTouch(SeekBar seekBar) {
			}
		});
		AddSeekbar(3, "Radar Pos.Y", 0, 52, 0, "", "", new SeekBar.OnSeekBarChangeListener(){
			public void onProgressChanged(SeekBar seekBar, int n, boolean isChecked) {
				UpdateConfiguration("RADAR::Y",n);
			}
			public void onStartTrackingTouch(SeekBar seekBar) {
			}
			public void onStopTrackingTouch(SeekBar seekBar) {
			}
		});
		AddSeekbar(3, "LootBox Content Max Distance", 0, 500, 10, "", " ", new SeekBar.OnSeekBarChangeListener(){
			public void onProgressChanged(SeekBar seekBar, int n, boolean isChecked) {
				UpdateConfiguration("ESP_LOOT_BOX_MAX_DISTANCE",n);
			}
			public void onStartTrackingTouch(SeekBar seekBar) {
			}
			public void onStopTrackingTouch(SeekBar seekBar) {
			}
		});
		AddSeekbar(3, "ESP Framerate", 30, 120, 60, "", " FPS", new SeekBar.OnSeekBarChangeListener(){
			public void onProgressChanged(SeekBar seekBar, int n, boolean isChecked) {
				UpdateConfiguration("ESP::FREMERATE",n);
			}
			public void onStartTrackingTouch(SeekBar seekBar) {
			}
			public void onStopTrackingTouch(SeekBar seekBar) {
			}
		});
		AddSeekbar(3, "Image transparency", 0, 10, 10, "", "", new SeekBar.OnSeekBarChangeListener(){
			public void onProgressChanged(SeekBar seekBar, int img, boolean isChecked) {
				BM_IconLayout.setAlpha((float)img / 10.0f);
			}
			public void onStartTrackingTouch(SeekBar seekBar) {
				BM_IconLayout.setVisibility(0);
			}
			public void onStopTrackingTouch(SeekBar seekBar) {
				BM_IconLayout.setVisibility(8);
			}
		});
		AddSeekbar(3, "Menu transparency", 0, 10, 10, "", "", new SeekBar.OnSeekBarChangeListener(){
			public void onProgressChanged(SeekBar seekBar, int trans, boolean isChecked) {
				BM_MainLayout.setAlpha((float)trans / 10.0f);
			}
			public void onStartTrackingTouch(SeekBar seekBar) {
			}
			public void onStopTrackingTouch(SeekBar seekBar) {
			}
		});
	}





void arfeatures(){
			 
		AddText(0, "LODA LUSAN LANGUAGE", "#000000");
		//-----------------------FEATURES-----------------------\\
		AddSwitch(0,"𝗦𝗽𝗼𝘄𝗻 𝗜𝘀𝗹𝗮𝗻𝗱 𝗕𝘆𝗽𝗮𝘀𝘀", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration("ISLAND_BYPASS", isChecked ? 1 : 0);	
			}
		}); 
		AddText(0, "𝗘𝗦𝗣 𝗚𝗲𝗻𝗲𝗿𝗶𝗰 𝗔𝗱𝗷𝘂𝘀𝘁𝗺𝗲𝗻𝘁", "#000000");
		AddCheckBox1(0,"Line", "Box", "Bone", "ESP::LINE", "ESP::BOX", "ESP::BONE");
		AddCheckBox1(0,"Health", "Name", "Distance", "ESP::HEALTH", "ESP::NAME", "ESP::DISTANCE");
		AddCheckBox1(0,"TeamID", "Head", "Nation", "ESP::TEAMID", "ESP::HEAD", "ESP::NATIONUID");
		// UID
		AddText(0, "𝗦𝗽𝗲𝗰𝗶𝗮𝗹 𝗙𝗲𝗮𝘁𝘂𝗿𝗲𝘀", "#000000");
		AddSwitch(0,"Throwable's Warning", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration("ESP::WARNING", isChecked ? 1 : 0);	
			}
		});
		AddSwitch(0,"Show Radar Map", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration("ESP::RADAR", isChecked ? 1 : 0);	
			}
		});
		AddSwitch(0,"Show LootBox", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration("ESP::DEADBOX", isChecked ? 1 : 0);
			}
		});
		AddSwitch(0,"Show LootBox Content", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration("ESP::DEADBOXITEMS", isChecked ? 1 : 0);
			}
		});
		AddSwitch(0,"Show 360 Alert", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration("ESP::360ALERT", isChecked ? 1 : 0);
			}
		});
		AddSwitch(0,"Show On Screen Alert", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration("ESP::ONSCREENALERT", isChecked ? 1 : 0);
			}
		});
		AddSwitch(0,"Enemy Aiming", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					UpdateConfiguration("ESP::ENEMYAIMING", isChecked ? 1 : 0);
				}
			});
		AddSwitch(0,"Don't Show Bots / Hide Al", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration("ESP::NOBOT", isChecked ? 1 : 0);
			}
		});
		AddText(0, "𝗩𝗲𝗵𝗰𝗶𝗹𝗲𝘀 𝗘𝗦𝗣", "#000000");
		AddSwitch(0,"All Vehciles Name & Distance", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration("ESP::VEHICLE", isChecked ? 1 : 0);
			}
		});
		AddSwitch(0,"Show All Vehciles Health", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration("ESP::VEHICLEHPALL", isChecked ? 1 : 0);
			}
		});
		AddSwitch(0,"Show All Vehciles Fuel", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration("ESP::VEHICLEFUELALL", isChecked ? 1 : 0);
			}
		});
		// =============================
		String str = "itemCategory";
		try {
			InputStream is = getAssets().open("items.png");
			byte[] buffer = new byte[is.available()];
			if (is.read(buffer) > 0) {
				is.close();
				String json = new String(buffer, StandardCharsets.UTF_8);
				UpdateConfiguration("CMD_PARSE_ITEMS", json);
				JSONArray arr = new JSONArray(json);
				for (int i = 0; i < arr.length(); i++) {
					JSONObject obj = arr.getJSONObject(i);
					if (obj.has(str)) {
						if ((obj.getString(str)).equals("Muzzle")) {
							CheckAttY = 1;
						}
						if (CheckAttY == 1) {
							AddText(1, obj.getString(str), "#000000");
						} else {
							AddText(1, obj.getString(str), "#000000");
						}
					} else {
						final String itemName = obj.getString("itemName");
						final int itemId = obj.getInt("itemId");
						i += 1;
						obj = arr.getJSONObject(i);
						if (obj.has(str)) {
							if ((obj.getString(str)).equals("Muzzle")) {
								CheckAttY = 1;
							}
							if (CheckAttY == 1) {
								AddText(1, obj.getString(str), "#000000");
							} else {
								AddText(1, obj.getString(str), "#000000");
							}
						} 
						if (!obj.has(str)) {
							final String itemName1 = obj.getString("itemName");
							final int itemId1 = obj.getInt("itemId");
							if (CheckAttY == 1) {
								AddSwitchItems(1, "ESP::ITEMS", itemName, itemName1, itemId, itemId1);
							} else {
								AddSwitchItems(1, "ESP::ITEMS", itemName, itemName1, itemId, itemId1);
							}
						}
					}
				}
			}
		} catch (Exception ex) {
		 ex.printStackTrace();
		}
// =============================
		AddSwitch(2,"Enable Aim", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					if(isChecked) {
						startService(new Intent(getApplicationContext(),AimMenu.class));
						isBullet = true;
					} else {
						stopService(new Intent(getApplicationContext(),AimMenu.class));
						isBullet = false;	
					}
				}
			});
		AddSwitch(2,"Prediction", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
	   public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					UpdateConfiguration("AIM_PREDICTION", isChecked ? 1 : 0);
				}
			}); 
		
		AddText(2, "𝗔𝗶𝗺 𝗧𝗮𝗿𝗴𝗲𝘁", "#000000");
		AddRadioButton(2, new String[]{"Shortest Distance", "Inside FOV"}, 0, new RadioGroup.OnCheckedChangeListener() {
				public void onCheckedChanged(RadioGroup radioGroup, int i) {
					UpdateConfiguration("AIM_TARGET_BY", i);
				}
			});
		int FOVSize = 0;
		AddSeekbar(2, "FOV Size", 0, 350, FOVSize, "", "", new SeekBar.OnSeekBarChangeListener() {
				public void onProgressChanged(SeekBar seekBar, int img, boolean isChecked) {
					UpdateConfiguration("AIM_INSIDE_FOV", img);
				}
				public void onStartTrackingTouch(SeekBar seekBar) {
				}
				public void onStopTrackingTouch(SeekBar seekBar) {
				}
			});
	 AddSwitch(2,"Recoil Compensation", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					UpdateConfiguration("RECOIL_COMPENSATION", isChecked ? 1 : 0);
				}
			}); 
		int RecoilCompensation  =0;
		AddSeekbar(2, "Recoil Value", 0, 2, RecoilCompensation, "", "", new SeekBar.OnSeekBarChangeListener(){
				public void onProgressChanged(SeekBar seekBar, int n, boolean isChecked) {
					UpdateConfiguration("RECOIL_COMPARISON_VALUE", n);
				}
				public void onStartTrackingTouch(SeekBar seekBar) {
				}
				public void onStopTrackingTouch(SeekBar seekBar) {
				}
			}); 
		AddText(2, "𝗔𝗶𝗺 𝗟𝗼𝗰𝗮𝘁𝗶𝗼𝗻", "#000000");
		AddRadioButton(2, new String[]{"Head", "Chest"}, 0, new RadioGroup.OnCheckedChangeListener(){
				public void onCheckedChanged(RadioGroup radioGroup, int i) {
					UpdateConfiguration("AIM::AIMPOS", i);
				}
			});
		AddText(2, "𝗧𝗿𝗶𝗴𝗴𝗲𝗿 𝗧𝘆𝗽𝗲", "#000000");
		AddRadioButton(2, new String[]{"Nothing", "Fire Only", "Scope Only", "Fire & Scope"}, 0, new RadioGroup.OnCheckedChangeListener(){
				public void onCheckedChanged(RadioGroup radioGroup, int i) {
					UpdateConfiguration("AIM::TRIGGER", i);
				}
			});
		AddSwitch(2,"Visibility Check", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					UpdateConfiguration("AIM::VISICHECK", isChecked ? 1 : 0);
				}
			});
		AddSwitch(2,"Ignore Knock", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					UpdateConfiguration("AIM::IGKNOCK", isChecked ? 1 : 0);
				}
			});
		AddSwitch(2,"Ignore Bot", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					UpdateConfiguration("AIM::IGBOT", isChecked ? 1 : 0);
				}
			});   
			
		AddSwitch(2,"𝐒𝐮𝐩𝐞𝐫 𝐀𝐢𝐦", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					UpdateConfiguration("AIM_LESS", isChecked ? 1 : 0);
				}
			});
		AddSwitch(2,"X Hit Effect", false, new CompoundButton.OnCheckedChangeListener() {
		@Override
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		 UpdateConfiguration("GKPMODS::XHIT", isChecked ? 1 : 0);
				}
			}); 
		AddSwitch(2,"Small Crosshair", false, new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					UpdateConfiguration("GKPMODS::CROSS", isChecked ? 1 : 0);
				}
			}); 					
		// =============================
		AddSeekbar(3, "Radar Pos.X", 0, 140, 0, "", "", new SeekBar.OnSeekBarChangeListener(){
			public void onProgressChanged(SeekBar seekBar, int n, boolean isChecked) {
				UpdateConfiguration("RADAR::X",n);
			}
			public void onStartTrackingTouch(SeekBar seekBar) {
			}
			public void onStopTrackingTouch(SeekBar seekBar) {
			}
		});
		AddSeekbar(3, "Radar Pos.Y", 0, 52, 0, "", "", new SeekBar.OnSeekBarChangeListener(){
			public void onProgressChanged(SeekBar seekBar, int n, boolean isChecked) {
				UpdateConfiguration("RADAR::Y",n);
			}
			public void onStartTrackingTouch(SeekBar seekBar) {
			}
			public void onStopTrackingTouch(SeekBar seekBar) {
			}
		});
		AddSeekbar(3, "LootBox Content Max Distance", 0, 500, 10, "", " ", new SeekBar.OnSeekBarChangeListener(){
			public void onProgressChanged(SeekBar seekBar, int n, boolean isChecked) {
				UpdateConfiguration("ESP_LOOT_BOX_MAX_DISTANCE",n);
			}
			public void onStartTrackingTouch(SeekBar seekBar) {
			}
			public void onStopTrackingTouch(SeekBar seekBar) {
			}
		});
		AddSeekbar(3, "ESP Framerate", 30, 120, 60, "", " FPS", new SeekBar.OnSeekBarChangeListener(){
			public void onProgressChanged(SeekBar seekBar, int n, boolean isChecked) {
				UpdateConfiguration("ESP::FREMERATE",n);
			}
			public void onStartTrackingTouch(SeekBar seekBar) {
			}
			public void onStopTrackingTouch(SeekBar seekBar) {
			}
		});
		AddSeekbar(3, "Image transparency", 0, 10, 10, "", "", new SeekBar.OnSeekBarChangeListener(){
			public void onProgressChanged(SeekBar seekBar, int img, boolean isChecked) {
				BM_IconLayout.setAlpha((float)img / 10.0f);
			}
			public void onStartTrackingTouch(SeekBar seekBar) {
				BM_IconLayout.setVisibility(0);
			}
			public void onStopTrackingTouch(SeekBar seekBar) {
				BM_IconLayout.setVisibility(8);
			}
		});
		AddSeekbar(3, "Menu transparency", 0, 10, 10, "", "", new SeekBar.OnSeekBarChangeListener(){
			public void onProgressChanged(SeekBar seekBar, int trans, boolean isChecked) {
				BM_MainLayout.setAlpha((float)trans / 10.0f);
			}
			public void onStartTrackingTouch(SeekBar seekBar) {
			}
			public void onStopTrackingTouch(SeekBar seekBar) {
			}
		});
	}



	void AddCheckBox1(Object object, final String string, final String string1, final String string2, final String num, final String num1,final String num2 ) {
		final LinearLayout headerLayout = new LinearLayout(this);
		headerLayout.setOrientation(0);
		headerLayout.setGravity(Gravity.LEFT);
		LinearLayout.LayoutParams layparam = new LinearLayout.LayoutParams(-1, -2);
		layparam.gravity = Gravity.CENTER_HORIZONTAL;
		headerLayout.setLayoutParams(layparam);

		CheckBox checkBox = new CheckBox((Context)this);
		checkBox.setText((CharSequence)string);
		checkBox.setTextColor(Color.BLACK);
		checkBox.setTextSize(12);
		setCheckBoxColor(checkBox, Color.BLACK, Color.BLACK);
  
		LinearLayout.LayoutParams layparam2 = new LinearLayout.LayoutParams(convertSizeToDp(80), -2);
		checkBox.setLayoutParams(layparam2);

		CheckBox checkBox1 = new CheckBox((Context)this);
		checkBox1.setText((CharSequence)string1);
		checkBox1.setTextColor(Color.BLACK);

		checkBox1.setTextSize(12);
		setCheckBoxColor(checkBox1, Color.BLACK, Color.BLACK);
   		checkBox1.setLayoutParams(layparam2);
   		
   		CheckBox checkBox2 = new CheckBox((Context)this);
		checkBox2.setText((CharSequence)string2);
		checkBox2.setTextColor(Color.BLACK);
	 
		checkBox2.setTextSize(12);
		setCheckBoxColor(checkBox2, Color.BLACK, Color.BLACK);
   		checkBox2.setLayoutParams(layparam2);

		if (string2 == "") {
			headerLayout.addView(checkBox);
		} else if (string2 != "" & string != "") {
			headerLayout.addView(checkBox);
			headerLayout.addView(checkBox1);
			headerLayout.addView(checkBox2);
		}
		if (object instanceof Integer)
			pageLayouts[(Integer) object].addView(headerLayout);
		else if (object instanceof ViewGroup)
			((ViewGroup) object).addView(headerLayout);

		checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration(num, isChecked ? 1 : 0);
			}
		});
		checkBox1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration(num1, isChecked ? 1 : 0);
			}
		});
		checkBox2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				UpdateConfiguration(num2, isChecked ? 1 : 0);
			}
		});
	}
	
	void setEspSettings(String ErrolDec, int Color) {
		SharedPreferences sp=this.getSharedPreferences("ErrolDecMod", Context.MODE_PRIVATE);
		SharedPreferences.Editor ed= sp.edit();
		ed.putInt(ErrolDec, Color);
		ed.apply();
	}
	int getEspSettings(String ErrolDec) {
		SharedPreferences sp=this.getSharedPreferences("ErrolDecMod", Context.MODE_PRIVATE);
		return sp.getInt(ErrolDec, 2);
	}
	private void AddToggle(Object data, String name, final String num) {
		Switch switch_ = new Switch((Context)this);
		switch_.setText(name);
		switch_.setTextColor(Color.BLACK);
		switch_.setTextSize(13);
	 
		switch_.setPadding(dp(4), dp(4), dp(4), dp(4));
		switch_.setLayoutParams((ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, -2));
		if (Build.VERSION.SDK_INT >= 21) {
			ColorStateList colorStateList = new ColorStateList(new int[][]{new int[]{-android.R.attr.state_checked}, new int[]{android.R.attr.state_checked}}, new int[]{Color.BLACK, Color.BLACK});
			switch_.setButtonTintList(colorStateList);
		}
		if (data instanceof Integer)
			pageLayouts[(Integer) data].addView(switch_);
		else if (data instanceof ViewGroup)
			((ViewGroup)data).addView((View)switch_);
		switch_.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					UpdateConfiguration(num, isChecked ? 1 : 0);
				}
			}); 
	}
	void AddSeekbar(Object object, String string, final int n, int n2, int n3, final String string2, final String string3, final SeekBar.OnSeekBarChangeListener onSeekBarChangeListener) {
		int n4 = n3;
		LinearLayout linearLayout = new LinearLayout((Context)this);
		linearLayout.setLayoutParams((ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, -2));
		linearLayout.setOrientation(0);
		TextView textView = new TextView((Context)this);
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append(string);
		stringBuilder.append(":");
		textView.setText((CharSequence)stringBuilder.toString());
		textView.setTextSize(1, 12.5f);
		textView.setPadding(this.convertSizeToDp(10.0f), this.convertSizeToDp(5.0f), this.convertSizeToDp(10.0f), this.convertSizeToDp(5.0f));
		textView.setTextColor(Color.BLACK);
		textView.setLayoutParams((ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-2, -2));
		textView.setGravity(3);
		SeekBar seekBar = new SeekBar((Context)this);
		seekBar.setMax(n2);
		if (Build.VERSION.SDK_INT >= 26) {
			seekBar.setMin(n);
			seekBar.setProgress(n);
		}
		if (Build.VERSION.SDK_INT >= 21) {
			seekBar.setThumbTintList(ColorStateList.valueOf((int)-1));
			seekBar.setProgressTintList(ColorStateList.valueOf((int)Color.BLACK));
		}
		seekBar.setPadding(this.convertSizeToDp(15.0f), this.convertSizeToDp(5.0f), this.convertSizeToDp(15.0f), this.convertSizeToDp(5.0f));
		final TextView textView2 = new TextView((Context)this);
		StringBuilder stringBuilder2 = new StringBuilder();
		stringBuilder2.append(string2);
		stringBuilder2.append(n);
		stringBuilder2.append(string3);
		textView2.setText((CharSequence)stringBuilder2.toString());
		textView2.setGravity(5);
		textView2.setTextSize(1, 12.5f);
		textView2.setLayoutParams((ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -2));
		textView2.setPadding(this.convertSizeToDp(15.0f), this.convertSizeToDp(5.0f), this.convertSizeToDp(15.0f), this.convertSizeToDp(5.0f));
		textView2.setTextColor(Color.BLACK);
		if (n4 != 0) {
			if (n4 < n) {
				n4 = n;
			}
			if (n4 > n2) {
				n4 = n2;
			}
			StringBuilder stringBuilder3 = new StringBuilder();
			stringBuilder3.append(string2);
			stringBuilder3.append(n4);
			stringBuilder3.append(string3);
			textView2.setText((CharSequence)stringBuilder3.toString());
			seekBar.setProgress(n4);
		}
		SeekBar.OnSeekBarChangeListener onSeekBarChangeListener2 = new SeekBar.OnSeekBarChangeListener(){

			public void onProgressChanged(SeekBar seekBar, int n2, boolean bl) {
				SeekBar.OnSeekBarChangeListener onSeekBarChangeListener2;
				if (n2 < n) {
					n2 = n;
					seekBar.setProgress(n2);
				}
				if ((onSeekBarChangeListener2 = onSeekBarChangeListener) != null) {
					onSeekBarChangeListener2.onProgressChanged(seekBar, n2, bl);
				}
				TextView textView = textView2;
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.append(string2);
				stringBuilder.append(n2);
				stringBuilder.append(string3);
				textView.setText((CharSequence)stringBuilder.toString());
			}

			public void onStartTrackingTouch(SeekBar seekBar) {
				SeekBar.OnSeekBarChangeListener onSeekBarChangeListener2 = onSeekBarChangeListener;
				if (onSeekBarChangeListener2 != null) {
					onSeekBarChangeListener2.onStartTrackingTouch(seekBar);
				}
			}

			public void onStopTrackingTouch(SeekBar seekBar) {
				SeekBar.OnSeekBarChangeListener onSeekBarChangeListener2 = onSeekBarChangeListener;
				if (onSeekBarChangeListener2 != null) {
					onSeekBarChangeListener2.onStopTrackingTouch(seekBar);
				}
			}
		};
		seekBar.setOnSeekBarChangeListener(onSeekBarChangeListener2);
		linearLayout.addView((View)textView);
		linearLayout.addView((View)textView2);
		if (object instanceof ViewGroup) {
			((ViewGroup)object).addView((View)linearLayout);
			((ViewGroup)object).addView((View)seekBar);
			return;

		}
		if (object instanceof Integer) {
			pageLayouts[(Integer)object].addView((View)linearLayout);
			pageLayouts[(Integer)object].addView((View)seekBar);
		}
	}
	void AddSpcaing(Object data, float Spacing) {
		LinearLayout spacing = new LinearLayout(this);
		spacing.setBackgroundColor(Color.parseColor("#00000000"));
		if (data instanceof Integer)
			pageLayouts[(Integer) data].addView(spacing, -1, convertSizeToDp(3));
		else if (data instanceof ViewGroup)
			((ViewGroup) data).addView(spacing, -1, convertSizeToDp(3));
	}
	void AddDropdown(Object object, String[] list, int defaultSelected, AdapterView.OnItemSelectedListener listener) {
		final GradientDrawable ErrolDec_GD3 = new GradientDrawable();
		ErrolDec_GD3.setColor(Color.parseColor("#211C20"));
		ErrolDec_GD3.setStroke(7, Color.parseColor("#867DEA"));
		ErrolDec_GD3.setCornerRadius(10f);

		final GradientDrawable ErrolDec_GD4= new GradientDrawable();
		ErrolDec_GD4.setColor(Color.parseColor("#211C20"));
		ErrolDec_GD4.setStroke(7, Color.parseColor("#867DEA"));

		LinearLayout mainLayout = new LinearLayout(this);
		mainLayout.setOrientation(LinearLayout.VERTICAL);
		mainLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT));
		mainLayout.setGravity(Gravity.CENTER);

		LinearLayout holderLayout = new LinearLayout(this);
		holderLayout.setOrientation(LinearLayout.VERTICAL);
		holderLayout.setLayoutParams(new LinearLayout.LayoutParams(convertSizeToDp(207), ViewGroup.LayoutParams.WRAP_CONTENT));
		holderLayout.setPadding(15, 15, 15, 15);
		holderLayout.setBackgroundDrawable(ErrolDec_GD3);
		holderLayout.setGravity(Gravity.CENTER);

		// final Typeface type = Typeface.createFromAsset(getAssets(), "fonts/11.ttf"); 

		Spinner sp = new Spinner(this, Spinner.MODE_DROPDOWN);
		sp.setLayoutParams(new RelativeLayout.LayoutParams(convertSizeToDp(207), ViewGroup.LayoutParams.WRAP_CONTENT));
		ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list) {
			@Override
			public View getView(int position, View convertView, ViewGroup parent) {
				View v = super.getView(position, convertView, parent);
				((TextView) v).setTextColor(Color.BLACK);
				//((TextView) v).setTypeface(type);
				((TextView) v).setGravity(Gravity.CENTER);
				return v;
			}
			@Override
			public View getDropDownView(int position, View convertView, ViewGroup parent) {
				View v = super.getDropDownView(position, convertView, parent);
				((TextView) v).setTextColor(Color.BLACK);
				//((TextView) v).setTypeface(type);
				((TextView) v).setGravity(Gravity.CENTER);
				v.setBackgroundDrawable(ErrolDec_GD4);
				return v;
			}
		};
		dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		sp.setAdapter(dataAdapter);
		sp.setOnItemSelectedListener(listener);
		sp.setPadding(0, 5, 0, 5);
		sp.setSelection(defaultSelected);

		holderLayout.addView(sp);
		mainLayout.addView(holderLayout);
		if (object instanceof Integer)
			pageLayouts[(Integer) object].addView(mainLayout);
		else if (object instanceof ViewGroup)
			((ViewGroup) object).addView(mainLayout);
	}

	void AddSwitchItems(Object object, final String Class, String text, String text1, final int itemId, final int itemId2) {
		final LinearLayout headerLayout = new LinearLayout(this);
		headerLayout.setOrientation(0);
		headerLayout.setGravity(Gravity.LEFT);
		LinearLayout.LayoutParams layparam = new LinearLayout.LayoutParams(-1, -2);
		layparam.gravity = Gravity.CENTER_HORIZONTAL;
		headerLayout.setLayoutParams(layparam);

		CheckBox checkBox = new CheckBox((Context)this);
		checkBox.setText((CharSequence)text);
		checkBox.setTextColor(Color.BLACK);
		checkBox.setTextSize(13);
		setCheckBoxColor(checkBox, Color.parseColor("#000000"), Color.parseColor("#3793C2"));
	   // Typeface type = Typeface.createFromAsset(getAssets(), "fonts/pubgm.ttf"); 
		// checkBox.setTypeface(type);
		LinearLayout.LayoutParams layparam2 = new LinearLayout.LayoutParams(-2, -2);
		checkBox.setLayoutParams(layparam2);

		CheckBox checkBox2 = new CheckBox((Context)this);
		checkBox2.setText((CharSequence)text1);
		checkBox2.setTextColor(Color.BLACK);
		//checkBox2.setTypeface(type);
		checkBox2.setTextSize(13);
		setCheckBoxColor(checkBox2, Color.parseColor("#000000"), Color.parseColor("#3793C2"));
   		checkBox2.setLayoutParams(layparam2);

		headerLayout.addView(checkBox);
		if (Integer.valueOf(itemId2) != 99999) {
			headerLayout.addView(checkBox2);
		}
		if (object instanceof Integer)
			pageLayouts[(Integer) object].addView(headerLayout);
		else if (object instanceof ViewGroup)
			((ViewGroup) object).addView(headerLayout);
		checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					UpdateConfiguration(Class, Integer.valueOf(itemId));
				}
			});
		checkBox2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					UpdateConfiguration(Class, Integer.valueOf(itemId2));
				}
			});
	}
	void addcheck3(Object obj,String a, String b,String c,final String id1,final String id2,final String id3){
		LinearLayout la = new LinearLayout(this);
		la.setOrientation(0);
	//la.setLayoutParams(new LinearLayout.LayoutParams(-1,-2));
		la.setGravity(Gravity.LEFT);
		LinearLayout.LayoutParams lq = new LinearLayout.LayoutParams(-2,-2);
		LinearLayout.LayoutParams lq2 = new LinearLayout.LayoutParams(-2,-2);
		lq2.gravity = Gravity.LEFT;
		la.setLayoutParams(lq2);

		CheckBox ca = new CheckBox(this);
		ca.setText(a);
		ca.setTextColor(Color.BLACK);
		ca.setLayoutParams(lq);
		ca.setTextSize(12);

		CheckBox ca2 = new CheckBox(this);
		ca2.setText(b);
		ca2.setTextColor(Color.BLACK);
		ca2.setLayoutParams(lq2);
		ca2.setTextSize(12);

		CheckBox ca3 = new CheckBox(this);
		ca3.setText(c);
		ca3.setTextColor(Color.BLACK);
		ca3.setLayoutParams(lq2);
		ca3.setTextSize(12);
		// ca3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/pubgm.ttf"));
		
		setCheckBoxColor(ca,Color.parseColor("#000000"),Color.parseColor("#ff0000"));
		setCheckBoxColor(ca2,Color.parseColor("#000000"),Color.parseColor("#ff0000"));
		setCheckBoxColor(ca3,Color.parseColor("#000000"),Color.parseColor("#ff0000"));
		
		if (b == "") {
			la.addView(ca);
		} 
		else
		if (b != "" & a != "") {
			la.addView(ca);
			la.addView(ca2);
			la.addView(ca3);
		}

		ca.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					UpdateConfiguration(id1, isChecked ? 1 : 0);
				}
			});
		ca2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					UpdateConfiguration(id2, isChecked ? 1 : 0);
				}
			});	
		ca3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					UpdateConfiguration(id3, isChecked ? 1 : 0);
				}
			});	
		if (obj instanceof Integer)
			pageLayouts[(Integer) obj].addView(la);
		else if (obj instanceof ViewGroup)
			((ViewGroup) obj).addView(la);

	}
	void AddCheckErroldec(Object object, final String[] arrstring) {
		final CheckBox[] arrradioButton = new CheckBox[arrstring.length];
		LinearLayout[] ErrolDec = new LinearLayout[arrstring.length];
		final int j, i;
		int str = 0;
		for (i = 0; i < arrstring.length / 2; i++) {
			ErrolDec[i] = new LinearLayout(this);
			ErrolDec[i].setOrientation(LinearLayout.HORIZONTAL);
			for (j = str; j < 2 + str; j++) {
				arrradioButton[j] = new CheckBox((Context)this);
				arrradioButton[j].setText((CharSequence)arrstring[j]);
				arrradioButton[j].setTextSize(13);
				// Typeface type = Typeface.createFromAsset(getAssets(), "fonts/11.ttf"); 
				// arrradioButton[j].setTypeface(type);
				arrradioButton[j].setLayoutParams(new LinearLayout.LayoutParams(convertSizeToDp(207), -2));
				arrradioButton[j].setGravity(Gravity.CENTER_VERTICAL);
				arrradioButton[j].setTextColor(-1);
				setCheckBoxColor(arrradioButton[j], Color.parseColor(colorBtnBlue), Color.parseColor(colorBtnBlue));
				if (arrstring[j] != "ErrolDec") {
					ErrolDec[i].addView(arrradioButton[j]);
				}
				arrradioButton[j].setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
						@Override
						public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
							UpdateConfiguration("VEHICLE::" + arrstring[j].toUpperCase(), isChecked ? 1 : 0);
						}
					});
			}
			str = j;
			if (object instanceof Integer)
				pageLayouts[(Integer) object].addView(ErrolDec[i]);
			else if (object instanceof ViewGroup)
				((ViewGroup) object).addView(ErrolDec[i]);
		}
	}
	@TargetApi(Build.VERSION_CODES.ICE_CREAM_SANDWICH)
	void AddSwitch(Object data, String text, boolean checked, CompoundButton.OnCheckedChangeListener listener) {
		Switch toggle = new Switch(this);
		toggle.setText(text);
		toggle.setTextSize(1, 12.5f);
		toggle.setTextColor(Color.BLACK);
		toggle.setChecked(checked);
		toggle.setPadding(15, 15, 15, 15);
		toggle.setOnCheckedChangeListener(listener);
		toggle.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

		if (Build.VERSION.SDK_INT >= 21) {
			ColorStateList colorStateList = new ColorStateList(
			new int[][] {
				new int[]{-android.R.attr.state_checked}, // unchecked
				new int[]{android.R.attr.state_checked}  // checked
			},
			new int[] {
				Color.BLACK,
				Color.BLACK
			}
			);
			toggle.setButtonTintList(colorStateList);
		}
		if (data instanceof Integer)
			pageLayouts[(Integer) data].addView(toggle);
		else if (data instanceof ViewGroup)
			((ViewGroup) data).addView(toggle);
	}
	
	void AddCheckBoxErrolDecVIPHack(Object object, final String string, final String string2, final String Config1, final String Config2) {
		final LinearLayout headerLayout = new LinearLayout(this);
		headerLayout.setOrientation(0);
		headerLayout.setGravity(Gravity.LEFT);
		LinearLayout.LayoutParams layparam = new LinearLayout.LayoutParams(-1, -2);
		layparam.gravity = Gravity.CENTER_HORIZONTAL;
		headerLayout.setLayoutParams(layparam);

		CheckBox checkBox = new CheckBox((Context)this);
		checkBox.setText((CharSequence)string);
		checkBox.setTextColor(Color.BLACK);
		checkBox.setTextSize(13);
		setCheckBoxColor(checkBox, Color.parseColor("#000000"), Color.parseColor("#ff0000"));
		// Typeface type = Typeface.createFromAsset(getAssets(), "fonts/pubgm.ttf"); 
		// checkBox.setTypeface(type);
		LinearLayout.LayoutParams layparam2 = new LinearLayout.LayoutParams(convertSizeToDp(120), -2);
		checkBox.setLayoutParams(layparam2);

		CheckBox checkBox2 = new CheckBox((Context)this);
		checkBox2.setText((CharSequence)string2);
		checkBox2.setTextColor(Color.BLACK);
		//checkBox2.setTypeface(type);
		checkBox2.setTextSize(13);
		setCheckBoxColor(checkBox2, Color.parseColor("#000000"), Color.parseColor("#ff0000"));
   		checkBox2.setLayoutParams(layparam2);

		if (string2.equals("")) {
			headerLayout.addView(checkBox);
		} else if (!string2.equals("") & !string.equals("")) {
			headerLayout.addView(checkBox);
			headerLayout.addView(checkBox2);
		}
		if (object instanceof Integer)
			pageLayouts[(Integer) object].addView(headerLayout);
		else if (object instanceof ViewGroup)
			((ViewGroup) object).addView(headerLayout);
		checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					UpdateConfiguration(Config1, isChecked ? 1 : 0);
				}
			});
		checkBox2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					UpdateConfiguration(Config2, isChecked ? 1 : 0);
				}
			}); }
	public void setCheckBoxColor(CheckBox checkBox, int uncheckedColor, int checkedColor) {
		ColorStateList colorStateList = new ColorStateList(
			new int[][] {
				new int[] { -android.R.attr.state_checked }, // unchecked
				new int[] {  android.R.attr.state_checked }  // checked
			},
			new int[] {
				uncheckedColor,
				checkedColor
			}	);
		checkBox.setButtonTintList(colorStateList);
	}
	void AddFloatSeekbar(Object object, String string, final int n, int n2, int n3, final String string2, final String string3, final SeekBar.OnSeekBarChangeListener onSeekBarChangeListener) {
		int n4 = n3;
		LinearLayout linearLayout = new LinearLayout((Context)this);
		linearLayout.setLayoutParams((ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, -2));
		linearLayout.setOrientation(0);
		TextView textView = new TextView((Context)this);
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append(string);
		stringBuilder.append(":");
		textView.setText((CharSequence)stringBuilder.toString());
		textView.setTextSize(1, 12.5f);
		// Typeface type = Typeface.createFromAsset(getAssets(), "fonts/11.ttf"); 
		// textView.setTypeface(type);
		textView.setPadding(this.convertSizeToDp(10.0f), this.convertSizeToDp(5.0f), this.convertSizeToDp(10.0f), this.convertSizeToDp(5.0f));
		textView.setTextColor(-1);
		textView.setLayoutParams((ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-2, -2));
		textView.setGravity(3);
		SeekBar seekBar = new SeekBar((Context)this);
		seekBar.setMax(n2);
		if (Build.VERSION.SDK_INT >= 26) {
			seekBar.setMin(n);
			seekBar.setProgress(n);
		}
		if (Build.VERSION.SDK_INT >= 21) {
			seekBar.setThumbTintList(ColorStateList.valueOf((int)-1));
			seekBar.setProgressTintList(ColorStateList.valueOf((int)-1));
		}
		seekBar.setPadding(this.convertSizeToDp(15.0f), this.convertSizeToDp(5.0f), this.convertSizeToDp(15.0f), this.convertSizeToDp(5.0f));
		final TextView textView2 = new TextView((Context)this);
		StringBuilder stringBuilder2 = new StringBuilder();
		stringBuilder2.append(string2);
		stringBuilder2.append(String.valueOf(n));
		stringBuilder2.append(string3);
		textView2.setText((CharSequence)stringBuilder2.toString());
		textView2.setGravity(5);
		textView2.setTextSize(1, 12.5f);
		//textView2.setTypeface(type);
		textView2.setLayoutParams((ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -2));
		textView2.setPadding(this.convertSizeToDp(15.0f), this.convertSizeToDp(5.0f), this.convertSizeToDp(15.0f), this.convertSizeToDp(5.0f));
		textView2.setTextColor(-1);
		if (n4 != 0) {
			if (n4 < n) {
				n4 = n;
			}
			if (n4 > n2) {
				n4 = n2;
			}
			StringBuilder stringBuilder3 = new StringBuilder();
			stringBuilder3.append(string2);
			stringBuilder3.append((float)n3);
			stringBuilder3.append(string3);
			textView2.setText((CharSequence)stringBuilder3.toString());
			seekBar.setProgress(n3);
		}
		SeekBar.OnSeekBarChangeListener onSeekBarChangeListener2 = new SeekBar.OnSeekBarChangeListener(){
			public void onProgressChanged(SeekBar seekBar, int n2, boolean bl) {
				SeekBar.OnSeekBarChangeListener onSeekBarChangeListener2;
				if (n2 < n) {
					n2 = n;
					seekBar.setProgress(n2);
				}
				if ((onSeekBarChangeListener2 = onSeekBarChangeListener) != null) {
					onSeekBarChangeListener2.onProgressChanged(seekBar, n2, bl);
				}
				TextView textView = textView2;
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.append(string2);
				stringBuilder.append(String.valueOf(n2));
				stringBuilder.append(string3);
				textView.setText((CharSequence)stringBuilder.toString());
			}
			public void onStartTrackingTouch(SeekBar seekBar) {
				SeekBar.OnSeekBarChangeListener onSeekBarChangeListener2 = onSeekBarChangeListener;
				if (onSeekBarChangeListener2 != null) {
					onSeekBarChangeListener2.onStartTrackingTouch(seekBar);
				}
			}
			public void onStopTrackingTouch(SeekBar seekBar) {
				SeekBar.OnSeekBarChangeListener onSeekBarChangeListener2 = onSeekBarChangeListener;
				if (onSeekBarChangeListener2 != null) {
					onSeekBarChangeListener2.onStopTrackingTouch(seekBar);
				}
			}
		};
		seekBar.setOnSeekBarChangeListener(onSeekBarChangeListener2);
		linearLayout.addView((View)textView);
		linearLayout.addView((View)textView2);
		if (object instanceof ViewGroup) {
			((ViewGroup)object).addView((View)linearLayout);
			((ViewGroup)object).addView((View)seekBar);
			return;
		}
		if (object instanceof Integer) {
			pageLayouts[(Integer)object].addView((View)linearLayout);
			pageLayouts[(Integer)object].addView((View)seekBar);
		}
	}

	void AddRadioButton(Object object, String[] arrstring, int n, RadioGroup.OnCheckedChangeListener onCheckedChangeListener) {
		RadioGroup radioGroup = new RadioGroup((Context)this);
		radioGroup.setOrientation(1);
		RadioButton[] arrradioButton = new RadioButton[arrstring.length];
		for (int i = 0; i < arrstring.length; ++i) {
			arrradioButton[i] = new RadioButton((Context)this);
			if (i == n) {
				arrradioButton[i].setChecked(true);
			}
			arrradioButton[i].setPadding(this.convertSizeToDp(10.0f), this.convertSizeToDp(5.0f), this.convertSizeToDp(10.0f), this.convertSizeToDp(5.0f));
			arrradioButton[i].setText((CharSequence)arrstring[i]);
			arrradioButton[i].setTextSize(1, 12.5f);
			// Typeface type = Typeface.createFromAsset(getAssets(), "fonts/pubgm.ttf"); 
			// arrradioButton[i].setTypeface(type);
			arrradioButton[i].setId(i);
			arrradioButton[i].setGravity(Gravity.CENTER_VERTICAL);
			arrradioButton[i].setTextColor(Color.BLACK);
			setRadioButtonColor(arrradioButton[i], Color.parseColor("#000000"), Color.parseColor("#ff0000"));
			radioGroup.addView((View)arrradioButton[i]);
		}
		radioGroup.setOnCheckedChangeListener(onCheckedChangeListener);
		radioGroup.setLayoutParams((ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -2));
		if (object instanceof Integer)
			pageLayouts[(Integer) object].addView(radioGroup);
		else if (object instanceof ViewGroup)
			((ViewGroup) object).addView(radioGroup);
	}

	public void setRadioButtonColor(RadioButton checkBox, int uncheckedColor, int checkedColor) {
		ColorStateList colorStateList = new ColorStateList(new int[][] {new int[] { -android.R.attr.state_checked }, new int[] {  android.R.attr.state_checked}}, new int[] {uncheckedColor, checkedColor});
		checkBox.setButtonTintList(colorStateList);
	}

	void AddText(Object object, String string, String string2) {
		TextView textView = new TextView((Context)this);
		//textView.setBackgroundColor(Color.parseColor("#867DEA"));
		textView.setText(string);
		textView.setGravity(Gravity.LEFT);
		textView.setTextColor(Color.parseColor((String)string2));
		// textView.setTypeface(Typeface.createFromAsset(getAssets(), "fonts/pubgm.ttf"));
		textView.setPadding(dp(4), dp(1), dp(1), dp(1));
		textView.setTextSize(12);
		if (object instanceof Integer)
			pageLayouts[(Integer) object].addView(textView);
		else if (object instanceof ViewGroup)
			((ViewGroup) object).addView(textView);
	}
	
	int convertSizeToDp(float f) {
		return Math.round((float)TypedValue.applyDimension((int)1, (float)f, (DisplayMetrics)this.getResources().getDisplayMetrics()));
	}
	int dp(int i) {
		return (int) TypedValue.applyDimension(1, (float) i, getResources().getDisplayMetrics());
	}
	int dpi(float dp) {
		return (int) (dp * this.getResources().getDisplayMetrics().density + 0.5f);
	}
	
	public IBinder onBind(Intent intent) {
		return null;
	}
	
	public static void delete(String path) {
		File dir = new File(path);
		if (dir.isDirectory()) {
			String[] children = dir.list();
			for (int i = 0; i < children.length; i++) {
				new File(dir, children[i]).delete();
			}
		}
	}
	public int onStartCommand(Intent intent, int n, int n2) {
		return 2;
	}
	public static interface OnListChoosedListener {
		public void onChoosed(int var1);
	}
	private native void onSendConfig(String s, String v);
	
	private void setImageFromAssets(ImageView image, String name) {
		AssetManager assetManager=getBaseContext().getAssets();
		try {
			InputStream inputStream=assetManager.open(name);
			image.setImageDrawable(Drawable.createFromStream(inputStream, null));
		} catch (IOException e) {
			Toast.makeText(this, "Error could not load image from assets folder \n" + e.getMessage(), Toast.LENGTH_SHORT).show();
		}
	}
	
	void toast(String s) {
		Toast.makeText(getApplicationContext(),s,1).show();
	}
	
	void Login(final Context m_Context, final String userKey) {
		final Handler loginHandler = new Handler() {
			private boolean isSuccess;
			@Override
			public void handleMessage(Message msg) {
				if (msg.what == 0) {
					toast("Success");
					BM_layoutlang.setVisibility(View.VISIBLE);
					BM_layoutlogin.setVisibility(View.GONE);
				} else if (msg.what == 1) {
					toast(msg.obj.toString());
					
				}
			 
			}
		};
		
		new Thread(new Runnable() {
				@Override
			public void run() {
				String result = Check(m_Context, userKey);
				if (result.equals("OK")) {
					loginHandler.sendEmptyMessage(0);
				} else {
					Message msg = new Message();
					msg.what = 1;
					msg.obj = result;
					loginHandler.sendMessage(msg);
				}
			}
		}).start();
	}
	
	public void onTaskRemoved(Intent intent) {
		stopSelf();
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		super.onTaskRemoved(intent);
	}
}
