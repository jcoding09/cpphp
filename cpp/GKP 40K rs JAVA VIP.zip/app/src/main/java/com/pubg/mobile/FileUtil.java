package com.pubg.mobile;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileUtil {

	private static void createNewFile(String path) {
		int lastSep = path.lastIndexOf(File.separator);
		if (lastSep > 0) {
			String dirPath = path.substring(0, lastSep);
            makeDir(dirPath);
		}

		File file = new File(path);

		try {
			if (!file.exists())
				file.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
    
	public static void writeFile(String path, String str) {
		createNewFile(path);
		FileWriter fileWriter = null;

		try {
			fileWriter = new FileWriter(new File(path), false);
			fileWriter.write(str);
			fileWriter.flush();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (fileWriter != null)
					fileWriter.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public static void deleteFile(String path) {
		File file = new File(path);

		if (!file.exists())
			return;

		if (file.isFile()) {
			file.delete();
			return;
		}

		File[]fileArr = file.listFiles();

		if (fileArr != null) {
            for (File subFile:fileArr) {
				if (subFile.isDirectory()) {
					deleteFile(subFile.getAbsolutePath());
				}

				if (subFile.isFile()) {
					subFile.delete();
				}
			}
		}

		file.delete();
	}

	public static boolean isExistFile(String path) {
		File file = new File(path);
		return file.exists();
	}

	public static void makeDir(String path) {
		if (!isExistFile(path)) {
			File file = new File(path);
			file.mkdirs();
		}
	}

}
