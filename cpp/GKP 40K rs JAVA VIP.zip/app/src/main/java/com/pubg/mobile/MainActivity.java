package com.pubg.mobile;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Toast;
import android.content.Intent;
import android.view.KeyEvent;
import android.app.DownloadManager;
import android.net.Uri;
import android.content.Context;
import android.webkit.CookieManager;
import android.os.Environment;
import android.widget.LinearLayout;
import android.widget.Button;
import android.view.Gravity;
import android.graphics.Color;
import android.view.View.OnClickListener;
import android.view.View;
import android.webkit.URLUtil;


public class MainActivity extends Activity {

	private DownloadManager manager;
	LinearLayout la;
    LinearLayout layoutlogin,loginlayer;
	String ok;
	
	Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StaticActivity.Init(this);
		
		//downlaoder();
     la = new LinearLayout(this);
	 la.setGravity(Gravity.CENTER);
	 la.setBackgroundColor(Color.BLACK);
	 
	 btn = new Button(this);
	 btn.setText("Start");
	 btn.setBackgroundColor(Color.LTGRAY);
	 btn.setOnClickListener(new View.OnClickListener(){
		 public void onClick(View v){
			 Intent i = new Intent(getApplicationContext(),Launcher.class);
			 startService(i); 
		 }
	 });
	 la.addView(btn);
	 setContentView(la);
		//byte[] libon = Utils.fromBase64("aHR0cHM6Ly9rZXl2aXAudGVjaC9WSVBQQU5FTC9HTE9CQUwvNjRCSVQvTkRIL2xpYk15TGliTmFtZS5zbw==");
		//Toast.makeText(this,""+Utils.fromBase64("aHR0cHM6Ly9rZXl2aXAudGVjaC9WSVBQQU5FTC9HTE9CQUwvNjRCSVQvTkRIL2xpYk15TGliTmFtZS5zbw=="),1).show();
		StaticActivity.Init(this);
//downloader.execute(this);
	 }
	
		void downlaoder(){
					}
	int up = 0;
	int down = 0;
	@Override
	public boolean onKeyUp(int keyCode, KeyEvent event) {
		super.onKeyUp(keyCode, event);
		if (keyCode == KeyEvent.KEYCODE_VOLUME_UP)
		{
			if(up != 3) {
				up += 1;
				return false;
			}
			up = 0;
			super.startService(new Intent(this, Launcher.class));

			Toast.makeText(MainActivity.this,"Menu Visible",Toast.LENGTH_SHORT).show();
			return true;
		}
		return false;
	}

	@Override
	public boolean onKeyLongPress(int keyCode, KeyEvent event) {
		return super.onKeyLongPress(keyCode, event);

	}


	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		super.onKeyDown(keyCode, event);

		if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)
		{
			if(down != 3) {

				down += 1;
				return false;
			}
			down = 0;
			super.stopService(new Intent(this, Launcher.class));

			Toast.makeText(MainActivity.this,"Menu Gone",Toast.LENGTH_SHORT).show();
			return true;
		}
		return false;
	}
	}
