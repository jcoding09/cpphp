#pragma once

// PUBG (2.4.0) SDKGen By @BangJO Dev [Z]

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_LoginRes_type.BP_STRUCT_LoginRes_type
// 0x0068
struct FBP_STRUCT_LoginRes_type
{
	struct FString                                     BeginTime_0_61E8AB401E0B8B054798D4B700EA1325;             // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     EndTime_1_75DE77C05915E9FF6F6F79DB0FE48785;               // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ID_2_500551805D3D3EB8005C1DB60AD29B84;                    // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
	struct FString                                     ResPath_3_6DF67C00770BC06671BECC720D654108;               // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     BGMPath_4_459C2700734E2FA214B5EDF7032F4118;               // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     TexPath_5_02397DC0325EB369387098470F604108;               // 0x0048(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     VideoPath_6_2D0C0F403824D91B0A97369A07ADC1F8;             // 0x0058(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

