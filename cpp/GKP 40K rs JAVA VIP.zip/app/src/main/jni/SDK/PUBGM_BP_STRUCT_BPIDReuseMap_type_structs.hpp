#pragma once

// PUBG (2.4.0) SDKGen By @BangJO Dev [Z]

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_BPIDReuseMap_type.BP_STRUCT_BPIDReuseMap_type
// 0x0008
struct FBP_STRUCT_BPIDReuseMap_type
{
	int                                                BPID_0_5A377D80314217626ED8281902773264;                  // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ReuseID_1_0BD67A00095DAF70463F3A450CA7BEB4;               // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

