#pragma once

// PUBG (2.4.0) SDKGen By @BangJO Dev [Z]

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_VehiclePropsBPTable_type.BP_STRUCT_VehiclePropsBPTable_type
// 0x0028
struct FBP_STRUCT_VehiclePropsBPTable_type
{
	struct FString                                     Path_0_4EDAFC402F5F7A8148151E1F0E26A1A8;                  // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ID_1_788B5C402A5D724740AE2C51090E2714;                    // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	struct FString                                     CName_2_3B11AA00669A1BB25698D87D027CD8D5;                 // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

