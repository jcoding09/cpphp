#pragma once

// PUBG (2.4.0) SDKGen By @BangJO Dev [Z]

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_InFillingBPTable_type.BP_STRUCT_InFillingBPTable_type
// 0x0038
struct FBP_STRUCT_InFillingBPTable_type
{
	struct FString                                     CName_0_0FEB140031B746EE57576036054ADAB5;                 // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ID_1_2AA3C640595906337FE75E5E09E85434;                    // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	struct FString                                     Path_2_484966400B8C53E31A22A3DB08558148;                  // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Wrapper_3_467E5B40009CAA6B663AE8D80016F392;               // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

