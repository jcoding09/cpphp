#pragma once

// PUBG (2.4.0) SDKGen By @BangJO Dev [Z]

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_MilitaryRankLevel_type.BP_STRUCT_MilitaryRankLevel_type
// 0x0064
struct FBP_STRUCT_MilitaryRankLevel_type
{
	struct FString                                     MilitaryRankName_0_6803185A4F44EE4389F6A3B24C13845F;      // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                Exp_1_0727D7694F81C282360C298C96801A35;                   // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	struct FString                                     MilitaryRankType_2_F858884B40EBC459D56457B1741D963D;      // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                Level_3_756F8DA14F48640682AFFFBD2A052F83;                 // 0x0028(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
	struct FString                                     MilitaryRankBigIconPath_4_9A4E25B74B0B8657724BD1AD59F3CB7C;// 0x0030(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     MilitaryRankSmallIconPath_5_F068C6BA4EB3CFAFA8CD159178EB8765;// 0x0040(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     MilitaryRankTypeIconPath_6_9AE9634945BC5B59F5709EB9C63E9970;// 0x0050(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                NewExp_7_6999CF00319D98A86C1DE90507E74340;                // 0x0060(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

