#pragma once

// PUBG (2.4.0) SDKGen By @BangJO Dev [Z]

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_LobbyWeaponClassTable_type.BP_STRUCT_LobbyWeaponClassTable_type
// 0x001C
struct FBP_STRUCT_LobbyWeaponClassTable_type
{
	int                                                BPID_0_02DA9D400965BF17443160A108D6A034;                  // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     ClassPath_1_7626F6405EC62EED16FC055F06250DC8;             // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                StanbyActionID_2_3509AC801200C2500D9D3BBA040428D4;        // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

