#pragma once

// PUBG (2.4.0) SDKGen By @BangJO Dev [Z]

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_WeaponReuseCfgTable_type.BP_STRUCT_WeaponReuseCfgTable_type
// 0x0020
struct FBP_STRUCT_WeaponReuseCfgTable_type
{
	int                                                ReuseAttachMeshID_0_5434FBC01C8BEB516724520609513054;     // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ReuseAvatarID_1_4546FB007C83124E1571E69B0A8192B4;         // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ReuseDefaultAttachID_2_7C7649C07EECDDC5161C8EEB079CE084;  // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ReuseFovID_3_4A896E0025C515CC35B3061B01430A64;            // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ReuseSupportAttachID_4_52FB37C0468A0A5532B875EE0C4070F4;  // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ReuseSupportBulletID_5_2F445C800F9CE3205C956C620DD524E4;  // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                WeaponBPID_6_133CA14062C42FFD677CE3FD0F9C4324;            // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                WeaponID_7_4308BCC073680B1B09069F6E07FF9CE4;              // 0x001C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

