#pragma once

// PUBG (2.4.0) SDKGen By @BangJO Dev [Z]

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_WeaponDIYPatternTable_type.BP_STRUCT_WeaponDIYPatternTable_type
// 0x0030
struct FBP_STRUCT_WeaponDIYPatternTable_type
{
	int                                                ID_0_226BAE406BDC69532A372FEB06291874;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     PatternPath_1_0710E5C02A9BF0434B2DE2C40D2F8198;           // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                UniqueID_2_735A2C00726FA8746CAB7F5C0321A0F4;              // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
	TArray<int>                                        UVInfo_a_6_7BA908C0188400D1149B1C070CEDEE51;              // 0x0020(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

