#pragma once

// PUBG (2.4.0) SDKGen By @BangJO Dev [Z]

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_NATION_SWITCH.BP_STRUCT_NATION_SWITCH
// 0x0004
struct FBP_STRUCT_NATION_SWITCH
{
	bool                                               NationRankSwitch_0_90EC58964A07013E18D9C4A0C24C6D72;      // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               NationAllSwitch_1_FFDC7E7C4281022AAE40A5B03DD5CE4A;       // 0x0001(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               NationBattleSwitch_2_DCD8C0084AAD46192D3CA48FD5FCC651;    // 0x0002(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Updated_3_5B3974684ED721353E91AA966D7347A5;               // 0x0003(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

