#pragma once

// PUBG (2.4.0) SDKGen By @BangJO Dev [Z]

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_WeaponDIYMatTable_type.BP_STRUCT_WeaponDIYMatTable_type
// 0x0028
struct FBP_STRUCT_WeaponDIYMatTable_type
{
	int                                                ID_0_23417F401B45618B4AEC918F0E131BC4;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     MatTexturePath_1_414664006E34CD52101931710A03BB38;        // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     MatColorString_2_4F78E2004D402EF01AC1DCEC0130D107;        // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

