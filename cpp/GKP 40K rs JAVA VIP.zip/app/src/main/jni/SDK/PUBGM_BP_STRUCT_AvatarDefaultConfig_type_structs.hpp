#pragma once

// PUBG (2.4.0) SDKGen By @BangJO Dev [Z]

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_AvatarDefaultConfig_type.BP_STRUCT_AvatarDefaultConfig_type
// 0x0038
struct FBP_STRUCT_AvatarDefaultConfig_type
{
	int                                                id_0_582DD74020EEE8C12D00E1A40C84B664;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     pant_1_00F930C0654EFFCD6B08CAF404B7FCD4;                  // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     shirt_2_53D54E8062374FD817805CCA0B7038D4;                 // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     shoe_3_12522FC065073BE56B0E507104B703D5;                  // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

