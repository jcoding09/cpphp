#pragma once

// PUBG (2.4.0) SDKGen By @BangJO Dev [Z]

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_WeaponDIYColorTable_type.BP_STRUCT_WeaponDIYColorTable_type
// 0x0014
struct FBP_STRUCT_WeaponDIYColorTable_type
{
	struct FString                                     ColorString_0_4E7650C0415307B368226BB801F47B77;           // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ID_1_7AE1B68005F218745C79F2BF0B6565A4;                    // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

