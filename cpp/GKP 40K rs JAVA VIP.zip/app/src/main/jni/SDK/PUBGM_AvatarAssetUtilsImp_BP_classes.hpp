#pragma once

// PUBG (2.4.0) SDKGen By @BangJO Dev [Z]

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass AvatarAssetUtilsImp_BP.AvatarAssetUtilsImp_BP_C
// 0x0000 (0x0198 - 0x0198)
class UAvatarAssetUtilsImp_BP_C : public UAvatarAssetBPUtils
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass AvatarAssetUtilsImp_BP.AvatarAssetUtilsImp_BP_C");
		return pStaticClass;
	}

};


}

