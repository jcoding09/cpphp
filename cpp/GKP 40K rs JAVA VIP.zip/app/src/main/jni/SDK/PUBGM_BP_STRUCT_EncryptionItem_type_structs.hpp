#pragma once

// PUBG (2.4.0) SDKGen By @BangJO Dev [Z]

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_EncryptionItem_type.BP_STRUCT_EncryptionItem_type
// 0x0024
struct FBP_STRUCT_EncryptionItem_type
{
	struct FString                                     ItemEncryptionDesc_0_399BA2402808603F271CFB4E03C1CA13;    // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     ItemEncryptionName_1_737BA2C03FBE98C5185E865403C222B5;    // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ItemID_2_3E285B007414EFB844C62E11094B6174;                // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

