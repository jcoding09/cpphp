#pragma once

// PUBG (2.4.0) SDKGen By @BangJO Dev [Z]

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_VehicleShapeTable_type.BP_STRUCT_VehicleShapeTable_type
// 0x0038
struct FBP_STRUCT_VehicleShapeTable_type
{
	struct FString                                     MeshBasePath_0_417CD1001B80DC1E44CCF1BC0A899508;          // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     BPPath_1_04FA93804ECCC4B06DEB74AB015A0988;                // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ID_2_63908F0075AF39C00FB6A5F00F6121F4;                    // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
	struct FString                                     AnimBPPath_3_12EBB4C05FB48819333454CC00540308;            // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

