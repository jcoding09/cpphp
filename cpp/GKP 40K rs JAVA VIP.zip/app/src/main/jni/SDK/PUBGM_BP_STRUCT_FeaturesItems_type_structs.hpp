#pragma once

// PUBG (2.4.0) SDKGen By @BangJO Dev [Z]

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_FeaturesItems_type.BP_STRUCT_FeaturesItems_type
// 0x0018
struct FBP_STRUCT_FeaturesItems_type
{
	int                                                ID_4_70B6D9000F7C4138010820A90EFCE7B4;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     Features_6_6384C58014BE35983FAD42C605772F63;              // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

