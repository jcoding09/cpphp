#pragma once

// PUBG (2.4.0) SDKGen By @BangJO Dev [Z]

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_RegionConfig_type.BP_STRUCT_RegionConfig_type
// 0x0084
struct FBP_STRUCT_RegionConfig_type
{
	struct FString                                     RegionName_0_6FD56A274264F9D23BF6E78649990B96;            // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     RegionCode_1_5DC6C7FB4FECF18D480EFAA3DE14C386;            // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     NationLang_2_E7700BFA44598D0C74CD639FE4FC307D;            // 0x0020(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                IsNation_3_00FBDD66481A878845FE90B9489F0408;              // 0x0030(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0034(0x0004) MISSED OFFSET
	struct FString                                     res_path_4_1CDB9AEE44DDB2ADB7DB72921E8181A7;              // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     sort_key_5_CBE9558C47B42D474F2C8F9D0A3E0021;              // 0x0048(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     channels_7_1FF007005FFA1D9A6400BA67081DEF53;              // 0x0058(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     reserveSpeed_8_0F578F4067C2058558E70C3208D08F84;          // 0x0068(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               saveDataSwitch_9_6EE31AC02D136BA30297A2D5081D0658;        // 0x0078(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0079(0x0003) MISSED OFFSET
	int                                                ContinentId_10_230C0BC073A74B992EA01894063D1AD4;          // 0x007C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Region_11_31F78D001E5A5CBE2C9EFE69067DA8FE;               // 0x0080(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

