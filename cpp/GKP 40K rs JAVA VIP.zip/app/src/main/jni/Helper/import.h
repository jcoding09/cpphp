//
// Create by Putri on 30/05/2021
//
#ifndef PUT_CHEATS_CANVAS_IMPORT_H
#define PUT_CHEATS_CANVAS_IMPORT_H

#include <jni.h>
#include <string>
#include <cstdlib>
#include <unistd.h>
#include <sys/mman.h>
#include <android/log.h>
#include <sys/types.h>
//#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <cerrno>
#include <sys/un.h>
#include <cstring>
#include <string>
#include <cmath>

bool isESP = false;
bool isPlayerBox = false;
bool isPlayerLine = false;
bool isPlayerDist = false;
bool isPlayerHealth = false;
bool isPlayerName = false;
bool isPlayerHead = false;
bool isr360Alert = false;
bool isSkelton1 = false;
bool isGrenadeWarning = false;
bool isEnemyWeapon= false;
bool aimbot = false;
bool isUID = false;
bool isVehicles = false;
bool isVehiclesFuel = false;
bool isVehiclesHP = false;
bool isTeamID = false;
float FOV = 0;
bool recoil = false;
bool isLessRecoil = false;
bool isZeroRecoil = false;
bool isInstantHit = false;
bool isHitX = false;
bool isSmallCrosshair = false;
bool isNoShake = false;

bool iG_Knock = false;
bool bT_Enable = false;
bool iG_Bot = false;
bool visi_Check = false;

bool Aim_iG_Knock = false;
bool Aim_Enable = false;
bool Aim_iG_Bot = false;
bool Aim_visi_Check = false;

bool isRadar = false;

int btAimPos=0;
int btAimTrigger=0;

int Aim_Pos=0;
int Aim_Tirgger=0;

float itemSize = 15;
float vehicleSize = 15;
float fpsRender = 80;
float enemySize = 25;
float alertSize = 70;

int uimode=0;

std::string name;


#endif
