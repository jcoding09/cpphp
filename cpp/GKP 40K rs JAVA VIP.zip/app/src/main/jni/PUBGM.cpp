#include "Helper.h"
#include "Login.h"

#define GetActorArray 0x7FB82A8
#define GEngine_Offset 0xB550340
#define GNames_Offset 0X664B26C
#define GUObject_Offset 0xB360580
#define GNativeAndroidApp_Offset 0xB0EA468
#define Actors_Offset 0xA0

struct sPatches {
 MemoryPatch Bypass, Bypass1, Bypass2, Bypass3, Bypass4, Bypass5, Bypass6, Bypassv2, Bypass7;
}; sPatches Patches;

uintptr_t UE4, ANOGS, TPRT, TDMASTER;
android_app * g_App = 0;
ASTExtraPlayerCharacter * g_LocalPlayer = 0;
ASTExtraPlayerController * g_LocalController = 0;
json itemData;
json items_data;

std::map<int, bool> itemConfig;
std::map<std::string, u_long> Config;

int screenWidth = -1, glWidth, screenHeight = -1, glHeight;
float density = -1, Radar, RadarX = 320, RadarY = 255;
bool initImGui = false;

struct sColorsESP {
	float *PVLine;
    float *PVILine;
    float *BVLine;
    float *BVILine;
    float *PVBox;
    float *PVIBox;
    float *BVBox;
    float *BVIBox;
    float *PVSkeleton;
    float *PVISkeleton;
    float *BVSkeleton;
    float *BVISkeleton;
    float *TeamID;
    float *Name;
    float *Distance;
    float *Vehicle;
    float *Items;
	float *Fov;
	float Cross;
	float *DBox;
};
sColorsESP ColorsESP{0};

static UEngine *GEngine = 0;
UWorld *GetWorld() {
    while (!GEngine) {
        GEngine = UObject::FindObject<UEngine>("UAEGameEngine Transient.UAEGameEngine_1");
        sleep(1);
    }
    if (GEngine) {
   auto ViewPort = GEngine->GameViewport;
     if (ViewPort) {
    return ViewPort->World;
       }  }
    return 0;
       }
//====𝗣𝗔𝗜𝗗==𝗦𝗥𝗖==𝗝𝗢𝗜𝗡==𝗧𝗘𝗟𝗘𝗚𝗥𝗔𝗠=@𝗚𝗞𝗣𝗙𝗥𝗘𝗘𝗛𝗔𝗖𝗞𝗦===== //
TNameEntryArray * GetGNames() {
	return ((TNameEntryArray * ( *)())(UE4 + GNames_Offset))();
          }
std::vector<AActor *> getActors() {
    auto World = GetWorld();
    if (!World)
        return std::vector<AActor *>();
    auto PersistentLevel = World->PersistentLevel;
    if (!PersistentLevel)
        return std::vector<AActor *>();
    struct GovnoArray {
        uintptr_t base;
        int32_t count;
        int32_t max;
           };
    static thread_local GovnoArray Actors{};
    Actors = *(((GovnoArray*(*)(uintptr_t))(UE4 + GetActorArray))(reinterpret_cast<uintptr_t>(PersistentLevel)));
    if (Actors.count <= 0) {
        return {};
           }
    std::vector<AActor *> actors;
    for (int i = 0; i < Actors.count; i++) {
        auto Actor = *(uintptr_t *) (Actors.base + (i * sizeof(uintptr_t)));
        if (Actor) {
            actors.push_back(reinterpret_cast<AActor *const>(Actor));
        }    }
    return actors;
      }
//=====𝗣𝗔𝗜𝗗==𝗦𝗥𝗖==𝗝𝗢𝗜𝗡==𝗧𝗘𝗟𝗘𝗚𝗥𝗔𝗠=@𝗚𝗞𝗣𝗙𝗥𝗘𝗘𝗛𝗔𝗖𝗞𝗦===== //
bool IsPtrValid(void * addr) {
	if (!addr) {
	return false;
	     }
	static int fd = -1;
	if (fd == -1) {
fd = open("/dev/random", O_WRONLY);
	     }
	return write(fd, addr, 4) >= 0;
          }
struct sRegion {
	uintptr_t start, end;
         };
std::vector<sRegion> trapRegions;

bool isObjectInvalid(UObject * obj) {
	if (!IsPtrValid(obj)) {
		return true;
	     }
	if (!IsPtrValid(obj->ClassPrivate)) {
		return true;
	     }
	if (obj->InternalIndex <= 0) {
		return true;
	      }
	if (obj->NamePrivate.ComparisonIndex <= 0) {
		return true;
	      }
	if ((uintptr_t)(obj) % sizeof(uintptr_t) != 0x0 && (uintptr_t)(obj) % sizeof(uintptr_t) != 0x4) {
		return true;
	     }
	if (std::any_of(trapRegions.begin(), trapRegions.end(), [obj](sRegion region) {
	return ((uintptr_t)obj) >= region.start && ((uintptr_t)obj) <= region.end;
	}) || std::any_of(trapRegions.begin(), trapRegions.end(), [obj](sRegion region) {
		return ((uintptr_t)obj->ClassPrivate) >= region.start && ((uintptr_t)obj->ClassPrivate) <= region.end;
	})) {
	return true;
	   }
	return false;
      }
std::string getObjectPath(UObject * Object) {
	std::string s;
	for (auto super = Object->ClassPrivate; super; super = (UClass *)super->SuperStruct) {
	if (!s.empty())
	s += ".";
	s += super->NamePrivate.GetName();
	  }
	return s;
      }
#define W2S(w, s) UGameplayStatics::ProjectWorldToScreen(localController, w, true, s)

ASTExtraPlayerCharacter *GetTargetByDistance() {
    ASTExtraPlayerCharacter *result = 0;

    auto infinity = std::numeric_limits<float>::infinity();
    auto max = std::numeric_limits<uint32_t>::max();

    auto Actors = getActors();

    auto localPlayer = g_LocalPlayer;
    auto localController = g_LocalController;

    if (localPlayer) {
        for (auto Actor: Actors) {
            if (isObjectInvalid(Actor))
                continue;
            if (Actor->IsA(ASTExtraPlayerCharacter::StaticClass())) {
                auto Player = (ASTExtraPlayerCharacter *) Actor;
                if (Player->PlayerKey == localPlayer->PlayerKey)
                    continue;
                if (Player->TeamID == localPlayer->TeamID)
                    continue;
                if (Player->bDead)
                    continue;
                if (Config["AIM::VISICHECK"]) {
                    if (!localController->LineOfSightTo(Player, {0, 0, 0}, true))
                        continue;
                }
                if (Config["AIM::IGKNOCK"]) {
                    if (Player->Health == 0.0f)
                        continue;
                }
             if (Config["AIM::IGBOT"]) {
                 if (Player->bIsAI)
                   continue;
                     }
    float dist = g_LocalPlayer->GetDistanceTo(Actor);
           if (dist < max) {
             max = dist;
            result = Player;
         }  }  }  }
    return result; }
//=====𝗣𝗔𝗜𝗗==𝗦𝗥𝗖==𝗝𝗢𝗜𝗡==𝗧𝗘𝗟𝗘𝗚𝗥𝗔𝗠=@𝗚𝗞𝗣𝗙𝗥𝗘𝗘𝗛𝗔𝗖𝗞𝗦=====//
bool isInsideFOV(int x, int y) {
	if (!Config["AIM_INSIDE_FOV"])
		return true;
	int circle_x = glWidth / 2;
	int circle_y = glHeight / 2;
	int rad = Config["AIM_INSIDE_FOV"];
	return (x - circle_x) * (x - circle_x) + (y - circle_y) * (y - circle_y) <= rad * rad;
}
auto GetTargetByCrossDist() {
    ASTExtraPlayerCharacter *result = 0;
    auto infinity = std::numeric_limits<float>::infinity();
    auto max = std::numeric_limits<uint32_t>::max();

    auto Actors = getActors();

    auto localPlayer = g_LocalPlayer;
    auto localController = g_LocalController;

    if (localPlayer) {
        for (auto Actor: Actors) {
            if (isObjectInvalid(Actor))
                continue;

            if (Actor->IsA(ASTExtraPlayerCharacter::StaticClass())) {
                auto Player = (ASTExtraPlayerCharacter *) Actor;

                if (Player->PlayerKey == localPlayer->PlayerKey)
                    continue;
                if (Player->TeamID == localPlayer->TeamID)
                    continue;
                if (Player->bDead)
                    continue;
                if (Config["AIM::IGKNOCK"]) {
                    if (Player->Health == 0.0f)
                        continue;
                           }
                if (Config["AIM::VISICHECK"]) {
                    if (!localController->LineOfSightTo(Player, {0, 0, 0}, true))
                        continue;
                             }
                if (Config["AIM::IGBOT"]) {
                    if (Player->bIsAI)
                        continue;
                             }
                auto Root = Player->GetBonePos("Root", {});
                auto Head = Player->GetBonePos("Head", {});
                FVector2D RootSc, HeadSc;
                if (W2S(Root, &RootSc) && W2S(Head, &HeadSc)) {
                    float height = abs(HeadSc.Y - RootSc.Y);
                    float width = height * 0.65f;
                    FVector middlePoint = {HeadSc.X + (width / 2), HeadSc.Y + (height / 2), 0};
                    if ((middlePoint.X >= 0 && middlePoint.X <= glWidth) && (middlePoint.Y >= 0 && middlePoint.Y <= glHeight)) {
                        FVector2D v2Middle = FVector2D((float) (glWidth / 2), (float) (glHeight / 2));
                        FVector2D v2Loc = FVector2D(middlePoint.X, middlePoint.Y);
                        if(isInsideFOV((int)middlePoint.X, (int)middlePoint.Y)) {
                            float dist = FVector2D::Distance(v2Middle, v2Loc);
                            if (dist < max) {
                                max = dist;
                                result = Player;
                            }
                        }
                    }
   }    }   }   }
    return result;   }

ASTExtraPlayerCharacter *GetTargetForAim() {
    if(Config["AIM_TARGET_BY"] == 1) {
        return GetTargetByCrossDist();
    }
    if(Config["AIM_TARGET_BY"] == 0) {
        return GetTargetByDistance();
    }
    return 0;
}
//=====𝗣𝗔𝗜𝗗==𝗦𝗥𝗖==𝗝𝗢𝗜𝗡==𝗧𝗘𝗟𝗘𝗚𝗥𝗔𝗠=@𝗚𝗞𝗣𝗙𝗥𝗘𝗘𝗛𝗔𝗖𝗞𝗦=====//
void ( * orig_shoot_event)(USTExtraShootWeaponComponent * thiz, FVector start, FRotator rot, void * unk1, int unk2) = 0;
void shoot_event(USTExtraShootWeaponComponent * thiz, FVector start, FRotator rot, ASTExtraShootWeapon * weapon, int unk1) {
	if (Config["AIM_ENABLE"]) {
		if(Config["AIM_MODE"] == 0) {
			ASTExtraPlayerCharacter * Target = GetTargetByCrossDist();
			if (Target) {
				bool triggerOk = false;
				if (Config["AIM::TRIGGER"] != 0) {
					if (Config["AIM::TRIGGER"] == 1) {
						triggerOk = g_LocalPlayer->bIsWeaponFiring;
					} else if (Config["AIM::TRIGGER"] == 2) {
						triggerOk = g_LocalPlayer->bIsGunADS;
					} else if (Config["AIM::TRIGGER"] == 3) {
						triggerOk = g_LocalPlayer->bIsWeaponFiring && g_LocalPlayer->bIsGunADS;
					} else if (Config["AIM::TRIGGER"] == 4) {
						triggerOk = g_LocalPlayer->bIsWeaponFiring || g_LocalPlayer->bIsGunADS;
					}} else
					triggerOk = true;
				if (triggerOk) {
					FVector targetAimPos = Target->GetBonePos("Head", {});
					targetAimPos.Z += 15.0f;
					if (Config["AIM::AIMPOS"] == 1) {
						targetAimPos.Z -= 25.0f;
					}
					UShootWeaponEntity * ShootWeaponEntityComponent = thiz->ShootWeaponEntityComponent;
					if (ShootWeaponEntityComponent) {
						if ("AIM_PREDICTION") {
							ASTExtraVehicleBase * CurrentVehicle = Target->CurrentVehicle;
							if (CurrentVehicle) {
								FVector LinearVelocity = CurrentVehicle->ReplicatedMovement.LinearVelocity;
								float dist = g_LocalPlayer->GetDistanceTo(Target);
								auto timeToTravel = dist / ShootWeaponEntityComponent->BulletFireSpeed;
								targetAimPos = UKismetMathLibrary::Add_VectorVector(targetAimPos, UKismetMathLibrary::Multiply_VectorFloat(LinearVelocity, timeToTravel));
								targetAimPos.Z += LinearVelocity.Z * timeToTravel + 0.5 * Config["AIM_PREDICTION_VALUE"] * timeToTravel * timeToTravel;
							} else {
								FVector Velocity = Target->GetVelocity();
								float dist = g_LocalPlayer->GetDistanceTo(Target);
								auto timeToTravel = dist / ShootWeaponEntityComponent->BulletFireSpeed;
								targetAimPos = UKismetMathLibrary::Add_VectorVector(targetAimPos, UKismetMathLibrary::Multiply_VectorFloat(Velocity, timeToTravel));
								targetAimPos.Z += Velocity.Z * timeToTravel + 0.5 * Config["AIM_PREDICTION_VALUE"] * timeToTravel * timeToTravel;
							}
						}
						FVector fDir = UKismetMathLibrary::Subtract_VectorVector(targetAimPos, g_LocalController->PlayerCameraManager->CameraCache.POV.Location);
						rot = UKismetMathLibrary::Conv_VectorToRotator(fDir);
					}
				}
			}
		}  }
	return orig_shoot_event(thiz, start, rot, weapon, unk1);
       }
auto GetCurrentWeaponReplicated(ASTExtraPlayerCharacter * Akshat) {
	auto WeaponManagerComponent = Akshat->WeaponManagerComponent;
	if (WeaponManagerComponent) {
		auto propSlot = WeaponManagerComponent->GetCurrentUsingPropSlot();
		if ((int)propSlot.GetValue() >= 1 && (int)propSlot.GetValue() <= 3) {
	return (ASTExtraShootWeapon *)WeaponManagerComponent->CurrentWeaponReplicated;
		}  }  }
const char *GetVehicleName(ASTExtraVehicleBase *Vehicle) {
    switch (Vehicle->VehicleShapeType) {
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Motorbike:
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Motorbike_SideCart:
            return "Motorbike";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Dacia:
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_HeavyDacia:
            return "Dacia";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_MiniBus:
            return "Mini Bus";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_PickUp:
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_PickUp01:
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_HeavyPickup:
            return "Pick Up";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Buggy:
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_HeavyBuggy:
            return "Buggy";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_UAZ:
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_UAZ01:
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_UAZ02:
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_UAZ03:
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_HeavyUAZ:
            return "UAZ";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_PG117:
            return "PG117";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Aquarail:
            return "Aquarail";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Mirado:
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Mirado01:
            return "Mirado";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Rony:
            return "Rony";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Scooter:
            return "Scooter";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_SnowMobile:
            return "Snow Mobile";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_TukTukTuk:
            return "Tuk Tuk";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_SnowBike:
            return "Snow Bike";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Surfboard:
            return "Surf Board";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Snowboard:
            return "Snow Board";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Amphibious:
            return "Amphibious";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_LadaNiva:
            return "Lada Niva";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_UAV:
            return "UAV";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_MegaDrop:
            return "Mega Drop";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Lamborghini:
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Lamborghini01:
            return "Lamborghini";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_GoldMirado:
            return "Gold Mirado";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_BigFoot:
            return "Big Foot";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_HeavyUH60:
            return "UH60";
            break;
        default:
            return "Vehicle";
            break;  }
    return "Vehicle"; }
//=====𝗣𝗔𝗜𝗗==𝗦𝗥𝗖==𝗝𝗢𝗜𝗡==𝗧𝗘𝗟𝗘𝗚𝗥𝗔𝗠=@𝗚𝗞𝗣𝗙𝗥𝗘𝗘𝗛𝗔𝗖𝗞𝗦=====//
void DrawESPVIP(ImDrawList * draw) {
    if (Config["ISLAND_BYPASS"]) {
        Patches.Bypass.Modify();
        Patches.Bypass1.Modify();
        Patches.Bypass2.Modify();
        Patches.Bypass3.Modify();
        Patches.Bypass4.Modify();
        Patches.Bypass5.Modify();
        Patches.Bypass6.Modify();
        Patches.Bypass7.Modify();
    } else {
        Patches.Bypass.Restore();
        Patches.Bypass1.Restore();
        Patches.Bypass2.Restore();
        Patches.Bypass3.Restore();
        Patches.Bypass4.Restore();
        Patches.Bypass5.Restore();
        Patches.Bypass6.Restore();
        Patches.Bypass7.Restore();
    }
	if (bValid) {
		auto Actors = getActors();
		int totalEnemies = 0, totalBots = 0;
		ASTExtraPlayerCharacter * localPlayer = 0;
		ASTExtraPlayerController * localController = 0;
		std::string sFPS = std::to_string(fps.get());
		sFPS += "FPS :";
		draw->AddText(NULL, ((float) density / 13.0f), {(float) glWidth / 150 + glWidth / 30, 40}, IM_COL32(255, 0, 0, 255), sFPS.c_str());
		draw->AddText({ ((float) density / 10.0f), 80}, IM_COL32(255, 215, 0, 255),OBFUSCATE("Low Tier Only Esp Use || Play Safe"));
        draw->AddText(NULL, ((float) density / 10.0f),{(float) glWidth / 150 + glWidth / 40,640},IM_COL32(255, 0, 0, 255), OBFUSCATE("@GKPxStudio||GL2.4"));
        std::string sExpiredDate = ("EXPIRY KEY: ");
        sExpiredDate += expiredDate.c_str();
        draw->AddText({((float) density / 8.0f), 600}, IM_COL32(245, 66, 197, 255), sExpiredDate.c_str());
		
	for (int i = 0; i < Actors.size(); i++) {
			auto Actor = Actors[i];
		if (isObjectInvalid(Actor))
				continue;
	if (Actor->IsA(ASTExtraPlayerController::StaticClass())) {
		localController = (ASTExtraPlayerController *)Actor;
			break;
			}  }
		if (localController) {
	for (int i = 0; i < Actors.size(); i++) {
			auto Actor = Actors[i];
		if (isObjectInvalid(Actor))
					continue;
	if (Actor->IsA(ASTExtraPlayerCharacter::StaticClass())) {
	if (((ASTExtraPlayerCharacter *)Actor)->PlayerKey == localController->PlayerKey) {
		localPlayer = (ASTExtraPlayerCharacter *)Actor;
				break;
				} } }
			if (localPlayer) {
		if (localPlayer->PartHitComponent) {
	auto ConfigCollisionDistSqAngles = localPlayer->PartHitComponent->ConfigCollisionDistSqAngles;
	for (int j = 0; j < ConfigCollisionDistSqAngles.Num(); j++) {
		ConfigCollisionDistSqAngles[j].Angle = 90.0f;
					}
	localPlayer->PartHitComponent->ConfigCollisionDistSqAngles = ConfigCollisionDistSqAngles;
				}		       					 
	 if (Config["AIM_LESS"]) {
         auto WeaponManagerComponent = localPlayer->WeaponManagerComponent;
             if (WeaponManagerComponent) {
        auto CurrentWeaponReplicated = (ASTExtraShootWeapon *) WeaponManagerComponent->CurrentWeaponReplicated;
               if (CurrentWeaponReplicated) {
        auto ShootWeaponEntityComp = CurrentWeaponReplicated->ShootWeaponEntityComp;
        auto ShootWeaponEffectComp = CurrentWeaponReplicated->ShootWeaponEffectComp;
         if (ShootWeaponEntityComp && ShootWeaponEffectComp) {					
         	 if (Config["AIM_LESS"]) {
              ShootWeaponEntityComp->AccessoriesVRecoilFactor = 0.190f;
              ShootWeaponEntityComp->AccessoriesHRecoilFactor = 0.190f;
              ShootWeaponEntityComp->AccessoriesRecoveryFactor = 0.190f;
                                }
                            }
              }    }   }
                if (Config["AIM_ENABLE"]) {
       if(Config["AIM_MODE"] == 0) {
      auto WeaponManagerComponent = localPlayer->WeaponManagerComponent;
             if (WeaponManagerComponent) {
   	auto propSlot = WeaponManagerComponent->GetCurrentUsingPropSlot();
   if ((int) propSlot.GetValue() >= 1 && (int) propSlot.GetValue() <= 3) {
   	auto CurrentWeaponReplicated = (ASTExtraShootWeapon *) WeaponManagerComponent->CurrentWeaponReplicated;
            if (CurrentWeaponReplicated) {
     auto ShootWeaponComponent = CurrentWeaponReplicated->ShootWeaponComponent;
             if (ShootWeaponComponent) {
            int shoot_event_idx = 163;
     auto VTable = (void **) ShootWeaponComponent->VTable;
   if (VTable && (VTable[shoot_event_idx] != shoot_event)) {
   orig_shoot_event = decltype(orig_shoot_event)(VTable[shoot_event_idx]);
            VTable[shoot_event_idx] = (void *) shoot_event;
                                    	}
                                	}
              	}  	} 	}   }   }

				if (Config["AIM_ENABLE"]) {
				if(Config["AIM_MODE"] == 1) {
              ASTExtraPlayerCharacter *Target = GetTargetForAim();
                  	if (Target) {
                   	bool triggerOk = false;
                   if (Config["AIM::TRIGGER"] != 0) {
                   if (Config["AIM::TRIGGER"] != 1) {
                   	triggerOk = localPlayer->bIsWeaponFiring;
                 	} else if (Config["AIM::TRIGGER"] != 2) {
                      triggerOk = localPlayer->bIsGunADS;
                      } else if (Config["AIM::TRIGGER"] != 3) {
    triggerOk = localPlayer->bIsWeaponFiring && localPlayer->bIsGunADS;
                    } else if (Config["AIM::TRIGGER"] != 4) {
    triggerOk = localPlayer->bIsWeaponFiring || localPlayer->bIsGunADS;
                            	}
                     	} else triggerOk = true;
                        	if (triggerOk) {
                 	FVector targetAimPos = Target->GetBonePos("Head", {});
                            	targetAimPos.Z += 15.0f;
                         	if (Config["AIM::AIMPOS"] == 1) {
                             	targetAimPos.Z -= 25.0f;
                            	}
            auto WeaponManagerComponent = localPlayer->WeaponManagerComponent;
                          if (WeaponManagerComponent) {
    	auto propSlot = WeaponManagerComponent->GetCurrentUsingPropSlot();
          	if ((int) propSlot.GetValue() >= 1 && (int) propSlot.GetValue() <= 3) {
          	auto CurrentWeaponReplicated = (ASTExtraShootWeapon *) WeaponManagerComponent->CurrentWeaponReplicated;
                    if (CurrentWeaponReplicated) {
          	auto ShootWeaponComponent = CurrentWeaponReplicated->ShootWeaponComponent;
                   if (ShootWeaponComponent) {
       UShootWeaponEntity *ShootWeaponEntityComponent = ShootWeaponComponent->ShootWeaponEntityComponent;
                    if (ShootWeaponEntityComponent) {
                        if ("AIM_PREDICTION") {
       ASTExtraVehicleBase *CurrentVehicle = Target->CurrentVehicle;
                        if (CurrentVehicle) {
            	FVector LinearVelocity = CurrentVehicle->ReplicatedMovement.LinearVelocity;
                float dist = localPlayer->GetDistanceTo(Target);
                 auto timeToTravel = dist / ShootWeaponEntityComponent->BulletFireSpeed;
                    targetAimPos = UKismetMathLibrary::Add_VectorVector(targetAimPos, UKismetMathLibrary::Multiply_VectorFloat(LinearVelocity, timeToTravel));
                       	targetAimPos.Z += LinearVelocity.Z * timeToTravel + 0.5 * Config["AIM_PREDICTION_VALUE"] * timeToTravel * timeToTravel;
                             		} else {
              	FVector Velocity = Target->GetVelocity();
               float dist = localPlayer->GetDistanceTo(Target);
               auto timeToTravel = dist / ShootWeaponEntityComponent->BulletFireSpeed;
                targetAimPos = UKismetMathLibrary::Add_VectorVector(targetAimPos, UKismetMathLibrary::Multiply_VectorFloat(Velocity, timeToTravel));
                targetAimPos.Z += Velocity.Z * timeToTravel + 0.5 * Config["AIM_PREDICTION_VALUE"] * timeToTravel * timeToTravel;
                                      		} 	}
                        if (Config["RECOIL_COMPENSATION"]) {
                            if (g_LocalPlayer->bIsGunADS) {
                        	if (g_LocalPlayer->bIsWeaponFiring) {
                float dist = g_LocalPlayer->GetDistanceTo(Target) / 100.f;                                                                                 
               targetAimPos.Z -= dist * float(Config["RECOIL_COMPARISON_VALUE"]);
                                          	}  } 	}
        localController->SetControlRotation(ToRotator(localController->PlayerCameraManager->CameraCache.POV.Location, targetAimPos), "");
                                         }
                                 	} }
                          	} } } } } }
				if (Config["ESP::RADAR"]) {
					bool out = false;
					struct Vector3 Pos;
					Pos.X = (Config["RADAR::X"] * 10);
					Pos.Y = (Config["RADAR::Y"] * 10);
					struct Vector3 Size;
					Size.X = 200;
					Size.Y = 200;
					float RadarCenterX = Pos.X + (Size.X / 2);
					float RadarCenterY = Pos.Y + (Size.Y / 2);
					long CircleColor = IM_COL32(112, 128, 144, 80);
					long PointColor = IM_COL32(255, 218, 45, 255);
					draw->AddLine(ImVec2(RadarCenterX, RadarCenterY), ImVec2(RadarCenterX, Pos.Y), IM_COL32(0, 255, 0, 155), 1.0f); // center to top
					draw->AddLine(ImVec2(RadarCenterX, RadarCenterY), ImVec2(Pos.X, RadarCenterY), IM_COL32(0, 255, 0, 155), 1.0f); // center to bottom
					draw->AddLine(ImVec2(Pos.X, RadarCenterY), ImVec2(Pos.X + Size.X, RadarCenterY), IM_COL32(0, 255, 0, 155), 1.0f); //center to left
					draw->AddLine(ImVec2(RadarCenterX, RadarCenterY), ImVec2(RadarCenterX, Pos.Y + Size.Y), IM_COL32(0, 255, 0, 155), 1.0f); //center to right
					draw->AddLine({RadarCenterX + 70, RadarCenterY - 70}, {RadarCenterX, RadarCenterY}, IM_COL32(255, 218, 45, 155), 2);
					draw->AddLine({RadarCenterX - 70, RadarCenterY - 70}, {RadarCenterX, RadarCenterY}, IM_COL32(255, 218, 45, 155), 2);
					draw->AddLine({RadarCenterX, RadarCenterY}, {RadarCenterX, RadarCenterY}, PointColor, 2);
					draw->AddCircleFilled(ImVec2(RadarCenterX, RadarCenterY), 60.0f, CircleColor, 0); 
					draw->AddCircle(ImVec2(RadarCenterX, RadarCenterY), 60.0f, PointColor, 0); 
					draw->AddCircle(ImVec2(RadarCenterX, RadarCenterY), 100.0f, PointColor, 0);
					draw->AddCircleFilled(ImVec2(RadarCenterX + 0.5f, RadarCenterY + 0.5f), 3.0f, PointColor, 0); // Center of Cross Ci
				}
				for (int i = 0; i < Actors.size(); i++) {
					auto Actor = Actors[i];
					if (isObjectInvalid(Actor))
						continue;
					if (Actor->IsA(ASTExtraPlayerCharacter::StaticClass())) {
						auto Player = (ASTExtraPlayerCharacter *)Actor;
						long PBox, PLine, PSkeleton, PlayerBoxClrCf, PlayerBoxClrCf2;
						float Distance = Player->GetDistanceTo(localPlayer) / 100.0f;
						if (Distance > 500.0f)
							continue;
						if (Player->PlayerKey == localController->PlayerKey)
							continue;
						if (Player->TeamID == localController->TeamID)
							continue;
						if (Player->bDead)
							continue;
						if (!Player->Mesh)
							continue;
						if (Player->bIsAI) {
							totalBots++;
							PlayerBoxClrCf = IM_COL32(255, 255, 255, 255);
							PlayerBoxClrCf2 = IM_COL32(255, 255, 255, 25);
							PBox = ToColor(ColorsESP.BVBox);
                            PLine = ToColor(ColorsESP.BVLine);
                            PSkeleton = ToColor(ColorsESP.BVSkeleton);
                            if (!localController->LineOfSightTo(Player, {0, 0, 0}, true)) {
                                PBox = ToColor(ColorsESP.BVIBox);
                                PLine = ToColor(ColorsESP.BVILine);
                                PSkeleton = ToColor(ColorsESP.BVISkeleton);
                            }
						} else {
							totalEnemies++;
							PlayerBoxClrCf = IM_COL32(255, 0, 0, 255);
							PlayerBoxClrCf2 = IM_COL32(255, 0, 0, 25);
							PBox = ToColor(ColorsESP.PVBox);
                            PLine = ToColor(ColorsESP.PVLine);
                            PSkeleton = ToColor(ColorsESP.PVSkeleton);
							if (!localController->LineOfSightTo(Player, {0, 0, 0}, true)) {
								PlayerBoxClrCf = IM_COL32(0, 255, 0, 255);
						    	PlayerBoxClrCf2 = IM_COL32(0, 255, 0, 25);
						    	PBox = ToColor(ColorsESP.PVIBox);
                                PLine = ToColor(ColorsESP.PVILine);
                                PSkeleton = ToColor(ColorsESP.PVISkeleton);
							}	}
						if (Config["ESP::NOBOT"]) {
							if (Player->bIsAI)
								continue;
						                }
						float magic_number = (Distance);
						float mx = (glWidth / 4) / magic_number;
						float healthLength = glWidth / 17;
						if (healthLength < mx)
							healthLength = mx;
						auto HeadPos = Player->GetBonePos("Head", {});
						ImVec2 HeadPosSC;
						auto RootPos = Player->GetBonePos("Root", {});
						ImVec2 RootPosSC;
						auto upper_r = Player->GetBonePos("upperarm_r", {});
						ImVec2 upper_rPoSC;
						auto lowerarm_r = Player->GetBonePos("lowerarm_r", {});
						ImVec2 lowerarm_rPoSC;
						auto hand_r = Player->GetBonePos("hand_r", {});
						ImVec2 hand_rPoSC;
						auto upper_l = Player->GetBonePos("upperarm_l", {});
						ImVec2 upper_lPoSC;
						auto lowerarm_l = Player->GetBonePos("lowerarm_l", {});
						ImVec2 lowerarm_lSC;
						auto hand_l = Player->GetBonePos("hand_l", {});
						ImVec2 hand_lPoSC;
						auto thigh_l = Player->GetBonePos("thigh_l", {});
						ImVec2 thigh_lPoSC;
						auto calf_l = Player->GetBonePos("calf_l", {});
						ImVec2 calf_lPoSC;
						auto foot_l = Player->GetBonePos("foot_l", {});
						ImVec2 foot_lPoSC;
						auto thigh_r = Player->GetBonePos("thigh_r", {});
						ImVec2 thigh_rPoSC;
						auto calf_r = Player->GetBonePos("calf_r", {});
						ImVec2 calf_rPoSC;
						auto foot_r = Player->GetBonePos("foot_r", {});
						ImVec2 foot_rPoSC;
						auto neck_01 = Player->GetBonePos("neck_01", {});
						ImVec2 neck_01PoSC;
						auto pelvis = Player->GetBonePos("pelvis", {});
						ImVec2 pelvisPoSC;
						if (W2S(HeadPos, (FVector2D *) & HeadPosSC) && W2S(upper_r, (FVector2D *) & upper_rPoSC) && W2S(upper_l, (FVector2D *) & upper_lPoSC) && W2S(lowerarm_r, (FVector2D *) & lowerarm_rPoSC) && W2S(hand_r, (FVector2D *) & hand_rPoSC) && W2S(lowerarm_l, (FVector2D *) & lowerarm_lSC) && W2S(hand_l, (FVector2D *) & hand_lPoSC) && W2S(thigh_l, (FVector2D *) & thigh_lPoSC) && W2S(calf_l, (FVector2D *) & calf_lPoSC) && W2S(foot_l, (FVector2D *) & foot_lPoSC) && W2S(thigh_r, (FVector2D *) & thigh_rPoSC) && W2S(calf_r, (FVector2D *) & calf_rPoSC) && W2S(foot_r, (FVector2D *) & foot_rPoSC) && W2S(neck_01, (FVector2D *) & neck_01PoSC) && W2S(pelvis, (FVector2D *) & pelvisPoSC) && W2S(RootPos, (FVector2D *) & RootPosSC)) {
							FVector2D screen(glWidth, glHeight);
							FVector2D location(RootPosSC.x, HeadPosSC.y);
							if (Config["ESP::LINE"]) {
								draw->AddLine({(float)glWidth / 2, 0}, HeadPosSC, PLine, 2.0f);
							}
						    if (Config["ESP::HEAD"]) {
								float boxWidth = 9.f - Distance * 0.05;
								draw->AddCircle({HeadPosSC.x, HeadPosSC.y}, boxWidth, PSkeleton, 0, 2.0f);
							}
							if (Config["ESP::BONE"]) {
								float boxWidth = 7.f - Distance * 0.03;
								draw->AddLine({upper_rPoSC.x, upper_rPoSC.y}, neck_01PoSC, PSkeleton, 2.0f);
								draw->AddLine({upper_lPoSC.x, upper_lPoSC.y}, neck_01PoSC, PSkeleton, 2.0f);
								draw->AddLine({upper_rPoSC.x, upper_rPoSC.y}, lowerarm_rPoSC, PSkeleton, 2.0f);
								draw->AddLine({lowerarm_rPoSC.x, lowerarm_rPoSC.y}, hand_rPoSC, PSkeleton, 2.0f);
								draw->AddLine({upper_lPoSC.x, upper_lPoSC.y}, lowerarm_lSC, PSkeleton, 2.0f);
								draw->AddLine({lowerarm_lSC.x, lowerarm_lSC.y}, hand_lPoSC, PSkeleton, 2.0f);
							    draw->AddLine({thigh_rPoSC.x, thigh_rPoSC.y}, thigh_lPoSC, PSkeleton, 2.0f);
								draw->AddLine({thigh_lPoSC.x, thigh_lPoSC.y}, calf_lPoSC, PSkeleton, 2.0f);
								draw->AddLine({calf_lPoSC.x, calf_lPoSC.y}, foot_lPoSC, PSkeleton, 2.0f);
								draw->AddLine({thigh_rPoSC.x, thigh_rPoSC.y}, calf_rPoSC, PSkeleton, 2.0f);
								draw->AddLine({calf_rPoSC.x, calf_rPoSC.y}, foot_rPoSC, PSkeleton, 2.0f);
								draw->AddLine({neck_01PoSC.x, neck_01PoSC.y}, pelvisPoSC, PSkeleton, 2.0f);
								draw->AddLine({neck_01PoSC.x, neck_01PoSC.y}, HeadPosSC, PSkeleton, 2.0f);
							}
							if (Config["ESP::BOX"]) {
								float boxHeight = abs(HeadPosSC.y - RootPosSC.y);
                                float boxWidth = boxHeight * 0.65f;
								if (!localController->LineOfSightTo(Player, {0, 0, 0}, true)) {
								    Box4Line(draw, 0.5f, HeadPosSC.x - (boxWidth / 2), HeadPosSC.y, boxWidth, boxHeight,  PBox);
								} else {
								    Box4Line(draw, 0.5f, HeadPosSC.x - (boxWidth / 2), HeadPosSC.y, boxWidth, boxHeight,  PBox);
								}
							}
							if (Config["ESP::HEALTH"] || Config["ESP::NAME"] || Config["ESP::TEAMID"] || Config["ESP::DISTANCE"]) {
								int CurHP = (int) std::max(0, std::min((int) Player->Health, (int) Player->HealthMax));
								int MaxHP = (int) Player->HealthMax;
								long HPColor = IM_COL32(std::min(((510 * (MaxHP - CurHP)) / MaxHP), 255), std::min((510 * CurHP) / MaxHP, 255), 0, 155);
								if (Player->Health == 0.0f && !Player->bDead) {
									HPColor = IM_COL32(255, 0, 0, 155);
									CurHP = Player->NearDeathBreath;
									if (Player->NearDeatchComponent) {
										MaxHP = Player->NearDeatchComponent->BreathMax;
									}
								}
								float boxWidth = density / 1.6f;
								boxWidth -= std::min(((boxWidth / 2) / 00.0f) * Distance, boxWidth / 2);
								float boxHeight = boxWidth * 0.06f;
								ImVec2 vStart = {HeadPosSC.x - (boxWidth / 2), HeadPosSC.y - (boxHeight * 2.1f)};
								ImVec2 vEndFilled = {vStart.x + (CurHP * boxWidth / MaxHP), vStart.y + boxHeight};
								ImVec2 vEndRect = {vStart.x + boxWidth, vStart.y + boxHeight};
								draw->AddRectFilled(vStart, vEndFilled, HPColor);
								draw->AddRect(vStart, vEndRect, IM_COL32(0, 0, 0, 155));
								if (Config["ESP::NAME"] || Config["ESP::TEAMID"] || Config["ESP::DISTANCE"]) {
									float NameboxHeight = boxWidth * 0.18f;
									ImVec2 vStart = {HeadPosSC.x - (boxWidth / 2), HeadPosSC.y - (NameboxHeight * 1.73f)};
									ImVec2 vEndRect = {vStart.x + boxWidth, vStart.y + NameboxHeight};
									draw->AddRectFilled(vStart, vEndRect, AMGetRandomColorByIndexAlpa(Player->TeamID));
									draw->AddRect(vStart, vEndRect, AMGetRandomColorByIndexAlpaRect(Player->TeamID));
								}
							}
							if (Config["ESP::TEAMID"]) {
								float boxWidth = density / 1.8f;
								boxWidth -= std::min(((boxWidth / 2) / 00.0f) * Distance, boxWidth / 2);
								float boxHeight = boxWidth * 0.19f;
								std::string s;
								s += std::to_string(Player->TeamID);
								draw->AddText(NULL, ((float)density / 25.0f), {HeadPosSC.x - (boxWidth / 2), HeadPosSC.y - (boxHeight * 1.70f)}, ToColor(ColorsESP.TeamID), s.c_str());
							}
							if (Config["ESP::NAME"]) {
								float boxWidth = density / 1.8f;
								boxWidth -= std::min(((boxWidth / 2) / 00.0f) * Distance, boxWidth / 2);
								float boxHeight = boxWidth * 0.19f;
								std::string s;
								if (Player->bIsAI) {
            						s += "    ROBOT";
								} else {
           							s += Player->PlayerName.ToString();
		                        }
						        draw->AddText(NULL, ((float)density / 25.0f), {HeadPosSC.x - (boxWidth / 3), HeadPosSC.y - (boxHeight * 1.70f)}, ToColor(ColorsESP.Name), s.c_str());
							}
							if (Config["ESP::DISTANCE"]) {
								float boxWidth = density / 1.8f;
								boxWidth -= std::min(((boxWidth / 2) / 00.0f) * Distance, boxWidth / 2);
								float boxHeight = boxWidth * 0.19f;
								std::string s;
								s += std::to_string((int)Distance);
								s += "M";
								draw->AddText(NULL, ((float)density / 25.0f), {HeadPosSC.x + (boxWidth / 3), HeadPosSC.y - (boxHeight * 1.70f)}, ToColor(ColorsESP.Distance), s.c_str());
							}
							if (Config["ESP::NATIONUID"]) {
								float boxWidth = density / 1.8f;
								boxWidth -= std::min(((boxWidth / 2) / 00.0f) * Distance, boxWidth / 2);
								float boxHeight = boxWidth * 0.19f;
								std::string s;
								s += "    ";
								s += Player->PlayerUID.ToString();
								draw->AddText(NULL, ((float)density / 30.0f), {HeadPosSC.x - (boxWidth / 3), HeadPosSC.y - (boxHeight * 3.08f)}, IM_COL32(255, 254, 0, 255), s.c_str());
							}
							if (Config["ESP::NATIONUID"]) {
								float boxWidth = density / 1.8f;
								boxWidth -= std::min(((boxWidth / 2) / 00.0f) * Distance, boxWidth / 2);
								float boxHeight = boxWidth * 0.19f;
								std::string s;
								s += Player->Nation.ToString();
								draw->AddText(NULL, ((float)density / 30.0f), {HeadPosSC.x - (boxWidth / 2), HeadPosSC.y - (boxHeight * 3.08f)}, IM_COL32(111, 210, 255, 255), s.c_str());
							}
							if (Config["ESP::RADAR"]) {
								bool out = false;
								struct Vector3 Pos;
								Pos.X = (Config["RADAR::X"] * 10);
								Pos.Y = (Config["RADAR::Y"] * 10);
								struct Vector3 Size;
								Size.X = 200;
								Size.Y = 200;
								FVector MyPosition, EnemyPosition;
								ASTExtraVehicleBase * CurrentVehiclea = Player->CurrentVehicle;
								if (CurrentVehiclea) {
									MyPosition = CurrentVehiclea->RootComponent->RelativeLocation;
								} else {
									MyPosition = Player->RootComponent->RelativeLocation;
								}
								ASTExtraVehicleBase * CurrentVehicle = localPlayer->CurrentVehicle;
								if (CurrentVehicle) {
									EnemyPosition = CurrentVehicle->RootComponent->RelativeLocation;
								} else {
									EnemyPosition = localPlayer->RootComponent->RelativeLocation;
								}
								FVector RadarSketch = WorldToRadar(localController->PlayerCameraManager->CameraCache.POV.Rotation.Yaw, MyPosition, EnemyPosition, Pos.X, Pos.Y, Vector3(Size.X, Size.Y, 0), out);
								if (Distance >= 0.f) {
									if (Player->bIsAI) {
										draw->AddCircleFilled(ImVec2(RadarSketch.X, RadarSketch.Y), 5, IM_COL32(255, 255, 255, 155), 0.0f);
									} else {
										draw->AddCircleFilled(ImVec2(RadarSketch.X, RadarSketch.Y), 5, IM_COL32(0, 255, 0, 155), 0.0f);
									} } }
							if (Config["ESP::ONSCREENALERT"]) {
								bool shit = false;
								FVector MyPosition, EnemyPosition;
								ASTExtraVehicleBase * CurrentVehiclea = Player->CurrentVehicle;
								if (CurrentVehiclea) {
									MyPosition = CurrentVehiclea->RootComponent->RelativeLocation;
								} else {
									MyPosition = Player->RootComponent->RelativeLocation;
								}
								ASTExtraVehicleBase * CurrentVehicle = localPlayer->CurrentVehicle;
								if (CurrentVehicle) {
									EnemyPosition = CurrentVehicle->RootComponent->RelativeLocation;
								} else {
									EnemyPosition = localPlayer->RootComponent->RelativeLocation;
								}
								FVector EntityPos = WorldToRadar(localController->PlayerCameraManager->CameraCache.POV.Rotation.Yaw, MyPosition, EnemyPosition, NULL, NULL, Vector3(glWidth, glHeight, 0), shit);
								FVector angle = FVector();
								Vector3 forward = Vector3((float)(glWidth / 2) - EntityPos.X, (float)(glHeight / 2) - EntityPos.Y, 0.0f);
								VectorAnglesRadar(forward, angle);
								const auto angle_yaw_rad = DEG2RAD(angle.Y + 180.f);
								const auto new_point_x = (glWidth / 2) + (55/*alert dist from me*/) / 2 * 8 * cosf(angle_yaw_rad);
								const auto new_point_y = (glHeight / 2) + (55/*alert dist from me*/) / 2 * 8 * sinf(angle_yaw_rad);
			std::array<Vector3, 3> points { Vector3(new_point_x - ((90) / 4 + 3.5f) / 2, new_point_y - ((55) / 4 + 3.5f) / 2, 0.f), Vector3(new_point_x + ((90) / 4 + 3.5f) / 4, new_point_y, 0.f), Vector3(new_point_x - ((90) / 4 + 3.5f) / 2, new_point_y + ((55) / 4 + 3.5f) / 2, 0.f)};
								RotateTriangle(points, angle.Y + 180.f);
								if (Player->bIsAI) {
	 draw->AddTriangle(ImVec2(points.at(0).X, points.at(0).Y), ImVec2(points.at(1).X, points.at(1).Y), ImVec2(points.at(2).X, points.at(2).Y), IM_COL32(0, 255, 0, 255), 1.5f);
    draw->AddTriangleFilled(ImVec2(points.at(0).X, points.at(0).Y), ImVec2(points.at(1).X, points.at(1).Y), ImVec2(points.at(2).X, points.at(2).Y), IM_COL32(0, 255, 0, 255));
                                } else {
	draw->AddTriangle(ImVec2(points.at(0).X, points.at(0).Y), ImVec2(points.at(1).X, points.at(1).Y), ImVec2(points.at(2).X, points.at(2).Y), IM_COL32(255, 0, 0, 255), 1.5f);
	draw->AddTriangleFilled(ImVec2(points.at(0).X, points.at(0).Y), ImVec2(points.at(1).X, points.at(1).Y), ImVec2(points.at(2).X, points.at(2).Y), IM_COL32(255, 0, 0, 255));                            
				      }  }
			  if (Config["ESP::ENEMYAIMING"]) {
    if (!localController->LineOfSightTo(Actor, {0, 0, 0}, true)) {
                         }else{
    draw->AddText(NULL, ((float) density / 6.0f),{(float) glWidth / 4 + glWidth / 40,500},IM_COL32(255, 000, 000, 255),
                       "Enemy Aiming");     
    draw->AddLine({(float) glWidth / 2, 716}, HeadPosSC,1.0f);
                           }  }
							int borders = isOutsideSafezone(location, screen);
							if (Config["ESP::360ALERT"] && borders != 0) {
								float Distance = localPlayer->GetDistanceTo(Player) / 100.0f;
								std::string s;
								s += std::to_string((int)Distance);
								s += "m";
								float mScale = glHeight / (float) 1080;
								auto hintDotRenderPos = pushToScreenBorder(location, screen, borders, (int)((mScale * 100) / 3));
								auto hintTextRenderPos = pushToScreenBorder(location, screen, borders, -(int)((mScale * 36)));
								draw->AddCircleFilled(ImVec2(hintDotRenderPos.X, hintDotRenderPos.Y), mScale * 100, IM_COL32(255, 0, 0, 128), 0);
								draw->AddText(NULL, ((float)density / 30.0f), ImVec2(hintTextRenderPos.X, hintTextRenderPos.Y), IM_COL32(255, 255, 255, 255), s.c_str());
							}	} }
					if (Config["ESP::VEHICLE"] || Config["ESP::VEHICLEFUELALL"] || Config["ESP::VEHICLEHPALL"]) {
					    if (Actors[i]->IsA(ASTExtraVehicleBase::StaticClass())) {
						    auto Vehicle = (ASTExtraVehicleBase *)Actors[i];
						    if (!Vehicle->Mesh)
							    continue;
						    int CurHP = (int) std::max(0, std::min((int) Vehicle->VehicleCommon->HP, (int) Vehicle->VehicleCommon->HPMax));
						    int MaxHP = (int) Vehicle->VehicleCommon->HPMax;
						    long curHP_Color = IM_COL32(std::min(((510 * (MaxHP - CurHP)) / MaxHP), 255), std::min(((510 * CurHP) / MaxHP), 255), 0, 155);
						    float Distance = Vehicle->GetDistanceTo(localPlayer) / 100.f;
						    FVector2D vehiclePos;
						    if (W2S(Vehicle->K2_GetActorLocation(), & vehiclePos)) {
							    auto mWidthScale = std::min(0.10f * Distance, 50.f);
							    auto mWidth = 70.f - mWidthScale;
							    auto mHeight = mWidth * 0.15f;
				    if (Config["ESP::VEHICLE"]) {
					    std::string s = GetVehicleName(Vehicle);
								    s += " - ";
								    s += std::to_string((int)Distance);
								    s += " m";
		    draw->AddText(NULL, ((float)density / 25.0f), {vehiclePos.X - (mWidth / 2), vehiclePos.Y}, IM_COL32(255, 255, 0, 255), s.c_str());
				  if (Config["ESP::VEHICLEFUELALL"]) {
									    std::string sf;
									    sf += "[Fuel:";
									    sf += std::to_string((int)(100 * Vehicle->VehicleCommon->Fuel / Vehicle->VehicleCommon->FuelMax));
									    sf += "]";																							
			draw->AddText(NULL, ((float)density / 30.0f), {vehiclePos.X - (mWidth / 2), vehiclePos.Y + 15.f}, IM_COL32(255, 255, 0, 255), sf.c_str());
								    }
					  if (Config["ESP::VEHICLEHPALL"]) {
			      ImVec2 vStart = {vehiclePos.X - (mWidth / 2), vehiclePos.Y - (mHeight * 1.5f)};
				  ImVec2 vEndFilled = {vStart.x + (CurHP * mWidth / MaxHP), vStart.y + mHeight};
			      ImVec2 vEndRect = {vStart.x + mWidth, vStart.y + mHeight};
		          draw->AddRectFilled(vStart, vEndFilled, curHP_Color, 3.2f, 240);
			     draw->AddRect(vStart, vEndRect, IM_COL32(000, 000, 000, 255), 3.2f, 240);
					    }  }  } }  }
					if (Config["ESP::WARNING"]) {
						if (Actors[i]->IsA(ASTExtraGrenadeBase::StaticClass())) {
							auto Grenade = (ASTExtraGrenadeBase *) Actors[i];
							auto RootComponent = Grenade->RootComponent;
							if (!RootComponent)
								continue;
							float Distance = Grenade->GetDistanceTo(localPlayer) / 70.f;
							FVector2D grenadePos;
							if (W2S(Grenade->K2_GetActorLocation(), & grenadePos)) {
								std::string s = std::to_string((int) Distance);
								s += "M";
								std::string t;
								t += "!!!...THROWABLE WARNING...!!!";
auto textSize = ImGui::CalcTextSize2(t.c_str(), 0, ((float) density / 15.5f));
draw->AddText(NULL, ((float) density / 13.0f), ImVec2(glWidth / 2 - (textSize.x / 2), 110), IM_COL32(255, 0, 0, 220), t.c_str());
draw->AddText(NULL, ((float) density / 25.0f), {grenadePos.X - 10, grenadePos.Y - 10}, IM_COL32(255, 0, 0, 255), s.c_str());
							}
						}	}
					if (Actors[i]->IsA(APickUpWrapperActor::StaticClass())) {
						auto PickUp = (APickUpWrapperActor *)Actors[i];
						if (itemConfig[PickUp->DefineID.TypeSpecificID]) {
							auto RootComponent = PickUp->RootComponent;
							if (!RootComponent)
								continue;
							float Distance = PickUp->GetDistanceTo(localPlayer) / 100.f;
							FVector2D itemPos;
							if (W2S(PickUp->K2_GetActorLocation(), & itemPos)) {
								std::string s;
								uint32_t tc = 0xFF000000;
								for (auto & e : itemData) {
						if (e["itemId"] == PickUp->DefineID.TypeSpecificID) {
						s = e["itemName"].get<std::string>();
						tc = strtoul(e["itemTextColor"].get<std::string>().c_str(), 0, 16);
								break;
									}
						}
								s += " - ";
								s += std::to_string((int)Distance);
								s += "m";
		draw->AddText(NULL, ((float)density / 25.0f), {itemPos.X, itemPos.Y}, tc, s.c_str());
				}		}		}
		if (Config["ESP::DEADBOX"])  {
		if (Actors[i]->IsA(APickUpListWrapperActor::StaticClass())) {
			auto Pick = (APickUpListWrapperActor *) Actors[i];
					if (!Pick->RootComponent)
							continue;
		auto PickUpDataList = (TArray<FPickUpItemData>)Pick->GetDataList();
		float Distance = Pick->GetDistanceTo(localPlayer) / 100.f;
			FVector2D PickUpListsPos;
			Vector3 origin, extends;
		if (W2S(Pick->K2_GetActorLocation(), & PickUpListsPos)) {
					std::string s = "LootBox";
					s += " - ";
			    	s += std::to_string((int) Distance);
					s += "M";
		draw->AddText(NULL, ((float) density / 20.0f), {PickUpListsPos.X, PickUpListsPos.Y}, IM_COL32(50, 255, 0, 255), s.c_str());
			if (Config["ESP::DEADBOXITEMS"])  {
	if (Distance <= (float) (Config["LOOTBOX_CONTENT_MAX_DISTANCE"])) {
    auto mWidthScale = std::min(0.1f * Distance, 35.f);
			auto boxWidth = 75.f - mWidthScale;
			auto boxHeight = boxWidth * 0.120f;
		Rect PlayerRect(PickUpListsPos.X - (boxWidth / 2), PickUpListsPos.Y, boxWidth, boxHeight);
			float posY = PickUpListsPos.Y - (PlayerRect.height * 2.0f);
				for (int j = 0; j < PickUpDataList.Num(); j++) {
				std::vector<std::string> s2;
						std::string itm;
					uint32_t tc = 0xFF000000;
				for (auto & category : items_data) {
				for (auto & item : category["Items"]) {
			if (item["itemId"] == PickUpDataList[j].ID.TypeSpecificID) {
		tc = strtoul(item["itemTextColor"].get<std::string>().c_str(), 0, 16);
			itm += item["itemName"].get<std::string>();
					s2.push_back(itm);										
					     break;
							}
						}	}
					if (!s2.empty())  {
				if (PickUpDataList[j].Count > 1) {
								s2.push_back(" * ");
				s2.push_back(std::to_string(PickUpDataList[j].Count));
									}
								std::string s3;
								for (auto & s4 : s2)   {
									s3 += s4;
										}
	draw->AddText(NULL, ((float) density / 22.0f), {PickUpListsPos.X, posY}, tc, s3.c_str());
						posY -= PlayerRect.height * 2.0f;
						}
					  }
					}	}
				}
		}	}	}	}  }
   if (Config["AIM_ENABLE"]) {
   if (Config["AIM_TARGET_BY"] == 1) {
 draw->AddCircle(ImVec2(glWidth / 2, glHeight / 2), Config["AIM_INSIDE_FOV"], IM_COL32(255, 0, 0, 255), 0, 2.0f);
		    }	}
			
		g_LocalController = localController;
		g_LocalPlayer = localPlayer;
		if (totalEnemies > 0 || totalBots > 0) {
		    std::string s;
			if (totalEnemies + totalBots < 10) {
    			s += "  E  ";
    			s += std::to_string((int)totalEnemies);
    			s += "  |  ";
    			s += std::to_string((int)totalBots);
    			s += "  B";
			} else {
    			s += " E ";
    			s += std::to_string((int)totalEnemies);
    			s += "  |  ";
    			s += std::to_string((int)totalBots);
    			s += "  B";
			}
			draw->AddRectFilled(ImVec2(glWidth / 2 - 80, 50), ImVec2(glWidth / 2 + 80, 90), IM_COL32(127, 38, 118, 0), 0.0f);
			draw->AddRect(ImVec2(glWidth / 2 - 80, 50), ImVec2(glWidth / 2 + 80, 90), IM_COL32(255, 0, 0, 255), 0.0f, 0, 3.0f);
			draw->AddText(nullptr, ((float)density / 16.5f), ImVec2(glWidth / 2 - 71, 55), IM_COL32(255, 0, 0, 255), s.c_str());
		} else {
			std::string s;
			s += "E  ";
			s += std::to_string((int)totalEnemies);
			s += "  |  ";
			s += std::to_string((int)totalBots);
			s += "  B";
			draw->AddRectFilled(ImVec2(glWidth / 2 - 80, 50), ImVec2(glWidth / 2 + 80, 90), IM_COL32(127, 38, 118, 0), 0.0f);
			draw->AddRect(ImVec2(glWidth / 2 - 80, 50), ImVec2(glWidth / 2 + 80, 90), IM_COL32(255, 0, 0, 255), 3.0f);
			draw->AddText(nullptr, ((float)density / 16.5f), ImVec2(glWidth / 2 - 58, 55), IM_COL32(255, 0, 0, 255), s.c_str());
		}
		fps.update();
	} }

#define SLEEP_TIME 1000LL / 60LL
[[noreturn]] void * maps_thread(void *) {
	while (true) {
	auto t1 = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
			
		std::vector<sRegion> tmp;
		char line[512];
		FILE * f = fopen("/proc/self/maps", "r");
		if (f) {
			while (fgets(line, sizeof line, f)) {
				uintptr_t start, end;
				char tmpProt[16];
				if (sscanf(line, "%" PRIXPTR "-%" PRIXPTR " %16s %*s %*s %*s %*s", & start, & end, tmpProt) > 0) {
					if (tmpProt[0] != 'r') {
						tmp.push_back({start, end});
					}
				} }
			fclose(f);
		      }
		trapRegions = tmp;
	auto td = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count() - t1;
	std::this_thread::sleep_for(std::chrono::milliseconds(std::max(std::min(0LL, SLEEP_TIME - td), SLEEP_TIME)));
	     } }
		 
[[noreturn]] void * gkp_thread(void *) {
	bool godview = false, godview1 = false, godview2 = false, godview3 = false, godview4 = false, godview5 = false, godview6 = false;
	while (true) {
		auto t1 = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
		auto localPlayer = g_LocalPlayer;
		auto localController = g_LocalController;
		if (localPlayer && localController) {
			
if (Config["GKPMODS::RECOIL"] || Config["GKPMODS::SHAKE"] || Config["GKPMODS::XHIT"] || Config["GKPMODS::CROSS"]) {
	auto WeaponManagerComponent = localPlayer->WeaponManagerComponent;
				if (WeaponManagerComponent) {
					auto Slot = WeaponManagerComponent->GetCurrentUsingPropSlot();
					if ((int)Slot.GetValue() >= 1 && (int)Slot.GetValue() <= 3) {
						auto CurrentWeaponReplicated = (ASTExtraShootWeapon *)WeaponManagerComponent->CurrentWeaponReplicated;
						if (CurrentWeaponReplicated) {
							auto ShootWeaponEntityComp = CurrentWeaponReplicated->ShootWeaponEntityComp;
							auto ShootWeaponEffectComp = CurrentWeaponReplicated->ShootWeaponEffectComp;
			if (ShootWeaponEntityComp && ShootWeaponEffectComp) {
					if (Config["GKPMODS::RECOIL"]) {
				ShootWeaponEntityComp->AccessoriesVRecoilFactor = 0.0f;
			ShootWeaponEntityComp->AccessoriesHRecoilFactor = 0.0f;
			ShootWeaponEntityComp->AccessoriesRecoveryFactor = 0.0f;
				ShootWeaponEntityComp->RecoilKickADS = 0.0f;
								}
			       if (Config["GKPMODS::SHAKE"]) {
			ShootWeaponEffectComp->CameraShakeInnerRadius = 0.0f;
			 ShootWeaponEffectComp->CameraShakeOuterRadius = 0.0f;
				ShootWeaponEffectComp->CameraShakFalloff = 0.0f;
								}
			if (Config["GKPMODS::CROSS"]) {
			ShootWeaponEntityComp->GameDeviationFactor = 0.0f;
								}		
	
				if (Config["GKPMODS::XHIT"]) {
			ShootWeaponEntityComp->DamageImpulse = 6.0f;
		ShootWeaponEntityComp->ExtraHitPerformScale = 6.0f;
								}
							}
						}
					}
				}
			}
		}
auto td = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count() - t1;
std::this_thread::sleep_for(std::chrono::milliseconds(std::max(std::min(0LL, SLEEP_TIME - td), SLEEP_TIME)));
	 }
	return 0;
      }
uintptr_t GetBaseAddress(const char * name) {
	uintptr_t base = 0;
	char line[512];
	FILE * f = fopen("/proc/self/maps", "r");
	if (!f) {
		return 0;
              }
	while (fgets(line, sizeof line, f)) {
		uintptr_t tmpBase;
		char tmpName[256];
 if (sscanf(line, "%" PRIXPTR "-%*" PRIXPTR " %*s %*s %*s %*s %s", & tmpBase, tmpName) > 0) {
if (!strcmp(basename(tmpName), name)) {
	base = tmpBase;
	break;
   	} } }
	fclose(f);
	return base; }

EGLBoolean( * orig_eglSwapBuffers)(EGLDisplay dpy, EGLSurface surface);
EGLBoolean _eglSwapBuffers(EGLDisplay dpy, EGLSurface surface) {
	eglQuerySurface(dpy, surface, EGL_WIDTH, & glWidth);
	eglQuerySurface(dpy, surface, EGL_HEIGHT, & glHeight);
	if (glWidth <= 0 || glHeight <= 0)
		return orig_eglSwapBuffers(dpy, surface);
	if (!g_App)
		return orig_eglSwapBuffers(dpy, surface);
	screenWidth = ANativeWindow_getWidth(g_App->window);
	screenHeight = ANativeWindow_getHeight(g_App->window);
	density = AConfiguration_getDensity(g_App->config);
	if (!initImGui) {
		ImGui::CreateContext();
		ImGuiStyle * style = & ImGui::GetStyle();
		ImGui::StyleColorsLight(style);
		style->WindowRounding = 4.0f;
		style->FramePadding = ImVec2(4, 5);
		style->FrameRounding = 5.0f;
		style->ScaleAllSizes(std::max(2.5f, density / 400.0f));
		ImGui_ImplAndroid_Init();
		ImGui_ImplOpenGL3_Init("#version 300 es");
		ImGuiIO & io = ImGui::GetIO();
		io.ConfigWindowsMoveFromTitleBarOnly = true;
		io.IniFilename = NULL;
		static const ImWchar icons_ranges[] = {0xf000, 0xf3ff, 0};
		ImFontConfig icons_config;
		icons_config.MergeMode = true;
		icons_config.PixelSnapH = true;
		icons_config.OversampleH = 2.5;
		icons_config.OversampleV = 2.5;
		ImFontConfig cfg;
		cfg.SizePixels = ((float)density / 20.0f);
		io.Fonts->AddFontDefault( & cfg);
		ColorsESP.PVLine = CREATE_COLOR(0, 255, 0, 255);
        ColorsESP.PVILine = CREATE_COLOR(255, 0, 0, 255);
        ColorsESP.BVLine = CREATE_COLOR(255, 215, 0, 255);
        ColorsESP.BVILine = CREATE_COLOR(15, 18, 212, 255);
        ColorsESP.PVBox = CREATE_COLOR(0, 255, 0, 255);
        ColorsESP.PVIBox = CREATE_COLOR(255, 0, 0, 255);
        ColorsESP.BVBox = CREATE_COLOR(255, 215, 0, 255);
        ColorsESP.BVIBox = CREATE_COLOR(255, 0, 0, 255);
        ColorsESP.PVSkeleton = CREATE_COLOR(255, 199, 0, 255);
        ColorsESP.PVISkeleton = CREATE_COLOR(255, 0, 0, 255);
        ColorsESP.BVSkeleton = CREATE_COLOR(255, 215, 0, 255);
        ColorsESP.BVISkeleton = CREATE_COLOR(176, 100, 14, 255);
        ColorsESP.Name = CREATE_COLOR(19, 16, 97, 255);
        ColorsESP.TeamID = CREATE_COLOR(116, 35, 117, 255);
        ColorsESP.Distance = CREATE_COLOR(71, 117, 181, 255);
        ColorsESP.Vehicle = CREATE_COLOR(255, 255, 0, 255); 
        ColorsESP.Items = CREATE_COLOR(255, 215, 0, 255);   
        ColorsESP.Fov = CREATE_COLOR(255, 0, 0, 255);
		Config["LOOTBOX_CONTENT_MAX_DISTANCE"] = 10.0f;
		initImGui = true; }
		
	ImGuiIO & io = ImGui::GetIO();
	ImGui_ImplOpenGL3_NewFrame();
	ImGui_ImplAndroid_NewFrame(glWidth, glHeight);
	ImGui::NewFrame();
	DrawESPVIP(ImGui::GetBackgroundDrawList());
	ImGui::SetNextWindowSize(ImVec2((float)glWidth * 0.0f, (float)glHeight * 0.0f), ImGuiCond_Once);
	ImGui::End();
	ImGui::Render();
	ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
	return orig_eglSwapBuffers(dpy, surface);
           }

int32_t ( * orig_onInputEvent)(struct android_app * app, AInputEvent * inputEvent);
int32_t onInputEvent(struct android_app * app, AInputEvent * inputEvent) {
	if (initImGui) {
ImGui_ImplAndroid_HandleInputEvent(inputEvent, {(float)screenWidth / (float)glWidth, (float)screenHeight / (float)glHeight});
         	}
 return orig_onInputEvent(app, inputEvent); }
 
void * main_thread(void *) {
	
	UE4 = GetBaseAddress("libUE4.so");
	while (!UE4) {
		UE4 = GetBaseAddress("libUE4.so");
		sleep(1);
	      }
	ANOGS = GetBaseAddress("libanogs.so");
	while (!ANOGS) {
		ANOGS = GetBaseAddress("libanogs.so");
		sleep(1);
	      }
	TPRT = GetBaseAddress("libgcloud.so");
	while (!TPRT) {
		TPRT = GetBaseAddress("libgcloud.so");
		sleep(1);
	       }
	TDMASTER = GetBaseAddress("libTDataMaster.so");
	while (!TDMASTER) {
   TDMASTER = GetBaseAddress("libTDataMaster.so");
		sleep(1); }	
	FName::GNames = GetGNames();
	while (!FName::GNames) {
		FName::GNames = GetGNames();
		sleep(1);
	       }
	UObject::GUObjectArray = (FUObjectArray *)(UE4 + GUObject_Offset);
	while (!g_App) {
		g_App = * (android_app * *)(UE4 + GNativeAndroidApp_Offset);
		sleep(1);
	        }
	while (!g_App->onInputEvent)
		sleep(1);
	orig_onInputEvent = decltype(orig_onInputEvent)(g_App->onInputEvent);
	g_App->onInputEvent = onInputEvent;
//===========Spawn==========Island==========bypass=============//
 /*
 Patches.Bypass = MemoryPatch::createWithHex("libanogs.so",0x1fd50,"C7 B7 89 15");
 Patches.Bypass1 = MemoryPatch::createWithHex("libanogs.so",0x1fba0,"C7 B7 89 15");
 Patches.Bypass2 = MemoryPatch::createWithHex("libanogs.so",0x1ef58,"C7 B7 89 15");
 Patches.Bypass3 = MemoryPatch::createWithHex("libanogs.so",0x1f7c8,"C7 B7 89 15");
 */

//===============GKP====2.3======BYPASS=============//
	void * egl = dlopen_ex("libEGL.so", 4);
	while (!egl) {
		egl = dlopen_ex("libEGL.so", 4);
		sleep(1); }
	void * addr = dlsym_ex(egl, "eglSwapBuffers");
	HOOK(addr, _eglSwapBuffers, & orig_eglSwapBuffers);
	dlclose_ex(egl);

	pthread_t t;
	pthread_create( & t, 0, maps_thread, 0);
	pthread_create( & t, 0, gkp_thread, 0);
	items_data = json::parse(JSON_ITEMS);
	return 0; }
__attribute__((constructor)) void _init() {
	pthread_t t;
	pthread_create( & t, 0, main_thread, 0); }
