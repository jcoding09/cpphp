#include "SDK.hpp"
#include "Helper/import.h"
#include "Helper/Includes.h"
#include "imgui/imgui.h"
#include "KittyMemory/MemoryPatch.h"
#include "imgui/backends/imgui_impl_android.h"
#include "imgui/backends/imgui_impl_opengl3.h"
#include "Helper/fake_dlfcn.h"
#include "Tools.h"
#include "StrEnc.h"
#include "Spoof.h"
#include "Helper/plthook.h"
#include "Helper/Items.h"
#include "Helper/json.hpp"
#include "Helper/Vector3.hpp"
#include "Helper/Color.h"
#include "string"
using namespace SDK;

#define IM_PI                   3.14159265358979323846f
#define RAD2DEG(x) ((float)(x) * (float)(180.f / IM_PI))
#define DEG2RAD(x) ((float)(x) * (float)(IM_PI / 180.f))

#define CREATE_COLOR(r, g, b, a) new float[4]{(float)r, (float)g, (float)b, (float)a};

int32_t ToColor(float *col) {
	return ImGui::ColorConvertFloat4ToU32(*(ImVec4 *)(col));
}

void Box4Line(ImDrawList *draw, float thicc, int x, int y, int w, int h, int color) {
    int iw = w / 4;
    int ih = h / 4;
    draw->AddRect(ImVec2(x, y),ImVec2(x + iw, y), color, thicc);
    draw->AddRect(ImVec2(x + w - iw, y),ImVec2(x + w, y), color, thicc);
    draw->AddRect(ImVec2(x, y),ImVec2(x, y + ih), color, thicc);
    draw->AddRect(ImVec2(x + w - 1, y),ImVec2(x + w - 1, y + ih), color, thicc);;

    draw->AddRect(ImVec2(x, y + h),ImVec2(x + iw, y + h), color, thicc);
    draw->AddRect(ImVec2(x + w - iw, y + h),ImVec2(x + w, y + h), color, thicc);
    draw->AddRect(ImVec2(x, y + h - ih), ImVec2(x, y + h), color, thicc);
    draw->AddRect(ImVec2(x + w - 1, y + h - ih), ImVec2(x + w - 1, y + h), color, thicc);
}

void DrawBoxEnemy(ImDrawList *draw, ImVec2 X, ImVec2 Y, float thicc, int color) {
    draw->AddLine({X.x, X.y}, {Y.x, Y.y}, color, thicc);
}

void VectorAnglesRadar(Vector3 & forward, FVector & angles) {
	if (forward.X == 0.f && forward.Y == 0.f) {
		angles.X = forward.Z > 0.f ? -90.f : 90.f;
		angles.Y = 0.f;
	} else {
		angles.X = RAD2DEG(atan2(-forward.Z, forward.Magnitude(forward)));
		angles.Y = RAD2DEG(atan2(forward.Y, forward.X));
	}
	angles.Z = 0.f;
}

void RotateTriangle(std::array<Vector3, 3> & points, float rotation) {
	const auto points_center = (points.at(0) + points.at(1) + points.at(2)) / 3;
	for (auto & point : points) {
		point = point - points_center;
		const auto temp_x = point.X;
		const auto temp_y = point.Y;
		const auto theta = DEG2RAD(rotation);
		const auto c = cosf(theta);
		const auto s = sinf(theta);
		point.X = temp_x * c - temp_y * s;
		point.Y = temp_x * s + temp_y * c;
		point = point + points_center;
	}
}
// Project by @ERROLDECOwner
FVector WorldToRadar(float Yaw, FVector Origin, FVector LocalOrigin, float PosX, float PosY, Vector3 Size, bool & outbuff) {
	bool flag = false;
	double num = (double)Yaw;
	double num2 = num * 0.017453292519943295;
	float num3 = (float)std::cosf(num2);
	float num4 = (float)std::sinf(num2);
	float num5 = Origin.X - LocalOrigin.X;
	float num6 = Origin.Y - LocalOrigin.Y;
	FVector Xector;
	Xector.X = (num6 * num3 - num5 * num4) / 150.f;
	Xector.Y = (num5 * num3 + num6 * num4) / 150.f;
    FVector Xector2;
	Xector2.X = Xector.X + PosX + Size.X / 2.f;
	Xector2.Y = -Xector.Y + PosY + Size.Y / 2.f;
	bool flag2 = Xector2.X > PosX + Size.X;
	if (flag2) {
		Xector2.X = PosX + Size.X;
	} else {
		bool flag3 = Xector2.X < PosX;
		if (flag3) {
			Xector2.X = PosX;
		}
	}
	bool flag4 = Xector2.Y > PosY + Size.Y;
	if (flag4) {
		Xector2.Y = PosY + Size.Y;
	} else {
		bool flag5 = Xector2.Y < PosY;
		if (flag5) {
			Xector2.Y = PosY;
		}
	}
	bool flag6 = Xector2.Y == PosY || Xector2.X == PosX;
	if (flag6) {
		flag = true;
	}
	outbuff = flag;
	return Xector2;
}

FVector2D pushToScreenBorder(FVector2D Pos, FVector2D screen, int borders, int offset) {
	int x = (int)Pos.X;
	int y = (int)Pos.Y;
	if ((borders & 1) == 1) {
		y = 0 - offset;
	}
	if ((borders & 2) == 2) {
		x = (int)screen.X + offset;
	}
	if ((borders & 4) == 4) {
		y = (int)screen.Y + offset;
	}
	if ((borders & 8) == 8) {
		x = 0 - offset;
	}
	return FVector2D(x, y);
}

int isOutsideSafezone(FVector2D pos, FVector2D screen) {
	FVector2D mSafezoneTopLeft(screen.X * 0.04f, screen.Y * 0.04f);
	FVector2D mSafezoneBottomRight(screen.X * 0.96f, screen.Y * 0.96f);
	int result = 0;
	if (pos.Y < mSafezoneTopLeft.Y) {
		result |= 1;
	}
	if (pos.X > mSafezoneBottomRight.X) {
		result |= 2;
	}
	if (pos.Y > mSafezoneBottomRight.Y) {
		result |= 4;
	}
	if (pos.X < mSafezoneTopLeft.X) {
		result |= 8;
	}
	return result;
}

class FPSCounter {
	protected:
	unsigned int m_fps;
	unsigned int m_fpscount;
	long m_fpsinterval;
	public:
	FPSCounter() : m_fps(0), m_fpscount(0), m_fpsinterval(0) { }
	void update() {
		m_fpscount++;
		if (m_fpsinterval < time(0)) {
			m_fps = m_fpscount;

			m_fpscount = 0;
			m_fpsinterval = time(0) + 1;
		}
	}
	unsigned int get() const {
		return m_fps;
	}
} fps;

bool WriteAddr(void *addr, void *buffer, size_t length) {
    unsigned long page_size = sysconf(_SC_PAGESIZE);
    unsigned long size = page_size * sizeof(uintptr_t);
    return mprotect((void *) ((uintptr_t) addr - ((uintptr_t) addr % page_size) - page_size), (size_t) size, PROT_EXEC | PROT_READ | PROT_WRITE) == 0 && memcpy(addr, buffer, length) != 0;
}

template<typename T>
void Write(uintptr_t addr, T value) {
    WriteAddr((void *) addr, &value, sizeof(T));
}
// Project by @ERROLDECOwner
class Rect {
public:
    float x;
    float y;
    float width;
    float height;

    Rect() {
        this->x = 0;
        this->y = 0;
        this->width = 0;
        this->height = 0;
    }

    Rect(float x, float y, float width, float height) {
        this->x = x;
        this->y = y;
        this->width = width;
        this->height = height;
    }

    bool operator==(const Rect &src) const {
        return (src.x == this->x && src.y == this->y && src.height == this->height &&
                src.width == this->width);
    }

    bool operator!=(const Rect &src) const {
        return (src.x != this->x && src.y != this->y && src.height != this->height &&
                src.width != this->width);
    }
};

FRotator ToRotator(FVector local, FVector target) {
    FVector rotation = UKismetMathLibrary::Subtract_VectorVector(local, target);
    float hyp = sqrt(rotation.X * rotation.X + rotation.Y * rotation.Y);
    FRotator newViewAngle = {0};
    newViewAngle.Pitch = -atan(rotation.Z / hyp) * (180.f / (float) 3.14159265358979323846);
    newViewAngle.Yaw = atan(rotation.Y / rotation.X) * (180.f / (float) 3.14159265358979323846);
    newViewAngle.Roll = (float) 0.f;
    if (rotation.X >= 0.f)
        newViewAngle.Yaw += 180.0f;
    return newViewAngle;
}