if (skinxsuit == 1) {

if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);

auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[5].ItemId = 1405870; //suit id
if (skinxsuit != Slotsybc[5].ItemId) {
skinxsuit = Slotsybc[5].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
}


if (skinxsuit == 2) {

if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);

auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[5].ItemId = 1405628; //suit id
if (skinxsuit != Slotsybc[5].ItemId) {
skinxsuit = Slotsybc[5].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
}


if (skinxsuit == 3) {

if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);

auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[5].ItemId = 1406152; //suit id
if (skinxsuit != Slotsybc[5].ItemId) {
skinxsuit = Slotsybc[5].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
}

if (skinxsuit == 4) {


if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);

auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[5].ItemId = 1406475; //suit id
if (skinxsuit != Slotsybc[5].ItemId) {
skinxsuit = Slotsybc[5].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
}


if (skinxsuit == 5) {

if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);

auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[5].ItemId = 1405983; //suit id
if (skinxsuit != Slotsybc[5].ItemId) {
skinxsuit = Slotsybc[5].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
}

if (skinxsuit == 6) {

if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);

auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[5].ItemId = 1406638; //suit id
if (skinxsuit != Slotsybc[5].ItemId) {
skinxsuit = Slotsybc[5].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
}

if (skinxsuit == 7) {

if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);

auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[5].ItemId = 1406311; //suit id
if (skinxsuit != Slotsybc[5].ItemId) {
skinxsuit = Slotsybc[5].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
}

if (skinxsuit == 8) {

if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);

auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[5].ItemId = 1406971; //suit id
if (skinxsuit != Slotsybc[5].ItemId) {
skinxsuit = Slotsybc[5].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
}

if (skinxsuit == 9) {

if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);

auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[5].ItemId = 1407102; //suit id
if (skinxsuit != Slotsybc[5].ItemId) {
skinxsuit = Slotsybc[5].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
}

if (skinxsuit == 10) {

if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);

auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[5].ItemId = 1406872; //suit id
if (skinxsuit != Slotsybc[5].ItemId) {
skinxsuit = Slotsybc[5].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
}

if (skinxsuit == 11) {

if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);

auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[5].ItemId = 1406469; //suit id
if (skinxsuit != Slotsybc[5].ItemId) {
skinxsuit = Slotsybc[5].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
}

if (skinxsuit == 12) {

if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);

auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[5].ItemId = 1407259; //suit id
if (skinxsuit != Slotsybc[5].ItemId) {
skinxsuit = Slotsybc[5].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
}
if (skinxsuit == 13) {

if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);

auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[5].ItemId = 1405623; //suit id
if (skinxsuit != Slotsybc[5].ItemId) {
skinxsuit = Slotsybc[5].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
}

if (skinxsuit == 14) {

if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);

auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[5].ItemId = 1400687; //suit id
if (skinxsuit != Slotsybc[5].ItemId) {
skinxsuit = Slotsybc[5].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
}   
if (skinxsuit == 15) {

if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);

auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[5].ItemId = 1406891; //suit id
if (skinxsuit != Slotsybc[5].ItemId) {
skinxsuit = Slotsybc[5].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
}
if (skintop == 1) {
if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);
auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[5].ItemId = 1400324; //Mission close
if (skintop != Slotsybc[5].ItemId) {
skintop = Slotsybc[5].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
}
if (skintop == 2) {
if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);
auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[5].ItemId = 1400321; //Mission open
if (skintop != Slotsybc[5].ItemId) {
skintop = Slotsybc[5].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
}
if (skintop == 3) {
if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);
auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[5].ItemId = 1404049; 
if (skintop != Slotsybc[5].ItemId) {
skintop = Slotsybc[5].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
}
if (skintop == 4) {
if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);
auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[5].ItemId = 1400569; 
if (skintop != Slotsybc[5].ItemId) {
skintop = Slotsybc[5].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
}
if (skintop == 5) {
if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);
auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[5].ItemId = 1404000; 
if (skintop != Slotsybc[5].ItemId) {
skintop = Slotsybc[5].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
}
if (skindown == 1) {
if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);
auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[6].ItemId = 1404191; //suit id
if (skindown != Slotsybc[6].ItemId) {
skindown = Slotsybc[6].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
}
if (skindown == 2) {
if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);
auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[6].ItemId = 1404050; //suit id
if (skindown != Slotsybc[6].ItemId) {
skindown = Slotsybc[6].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
}
if (skindown == 3) {
if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);
auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[6].ItemId = 1400650; //suit id
if (skindown != Slotsybc[6].ItemId) {
skindown = Slotsybc[6].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
}
if (skindown == 4) {
if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);
auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[6].ItemId = 1404002; //suit id
if (skindown != Slotsybc[6].ItemId) {
skindown = Slotsybc[6].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
}
if (skinhair == 1) {
if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);
auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[4].ItemId = 40605012; //kosi4ki
if (skinhair != Slotsybc[4].ItemId) {
skinhair = Slotsybc[4].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
}
if (skinhair == 2) {
if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);
auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[4].ItemId = 40605011; //ZaliZ
if (skinhair != Slotsybc[4].ItemId) {
skinhair = Slotsybc[4].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
}
if (skinhair == 3) {
if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);
auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[4].ItemId = 40605010; //ZaliZ
if (skinhair != Slotsybc[4].ItemId) {
skinhair = Slotsybc[4].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
} 
if (skinface == 1) {
if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);
auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[1].ItemId = 1400563; //ZaliZ
if (skinface != Slotsybc[1].ItemId) {
skinface = Slotsybc[1].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
}
if (skinboots == 1) {
if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);
auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[7].ItemId = 1404051; //kosi4ki
if (skinboots != Slotsybc[7].ItemId) {
skinboots = Slotsybc[7].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
}
if (skinboots == 2) {
if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);
auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[7].ItemId = 1404003; //kosi4ki
if (skinboots != Slotsybc[7].ItemId) {
skinboots = Slotsybc[7].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
}
if (skinhead == 1) {
if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);
auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[2].ItemId = 1402218; //kosi4ki
if (skinhead != Slotsybc[2].ItemId) {
skinhead = Slotsybc[2].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
}
if (skinmask == 1) {
if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);
auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[3].ItemId = 1404198; //kosi4ki
if (skinhead != Slotsybc[3].ItemId) {
skinhead = Slotsybc[3].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
}
if (skinmask == 2) {
if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);
auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[3].ItemId = 1403019; //kosi4ki
if (skinhead != Slotsybc[3].ItemId) {
skinhead = Slotsybc[3].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
}
if (skinset == 1) {
if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);
auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[1].ItemId = 1400563; //ZaliZ
if (skinface != Slotsybc[1].ItemId) {
skinface = Slotsybc[1].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);
auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[4].ItemId = 40605011; //ZaliZ
if (skinhair != Slotsybc[4].ItemId) {
skinhair = Slotsybc[4].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);
auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[5].ItemId = 1404049; 
if (skintop != Slotsybc[5].ItemId) {
skintop = Slotsybc[5].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);
auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[6].ItemId = 1404050; //suit id
if (skindown != Slotsybc[6].ItemId) {
skindown = Slotsybc[6].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);
auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[7].ItemId = 1404051; //kosi4ki
if (skinboots != Slotsybc[7].ItemId) {
skinboots = Slotsybc[7].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
}
if (skinset == 2) {
if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);
auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[1].ItemId = 1400563; //ZaliZ
if (skinface != Slotsybc[1].ItemId) {
skinface = Slotsybc[1].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);
auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[4].ItemId = 40605011; //ZaliZ
if (skinhair != Slotsybc[4].ItemId) {
skinhair = Slotsybc[4].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);
auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[5].ItemId = 1400569; 
if (skintop != Slotsybc[5].ItemId) {
skintop = Slotsybc[5].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);
auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[6].ItemId = 1400650; //suit id
if (skindown != Slotsybc[6].ItemId) {
skindown = Slotsybc[6].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);
auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[7].ItemId = 1404003; //kosi4ki
if (skinboots != Slotsybc[7].ItemId) {
skinboots = Slotsybc[7].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
}
if (skinset == 3) {
if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);
auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[1].ItemId = 1400563; //ZaliZ
if (skinface != Slotsybc[1].ItemId) {
skinface = Slotsybc[1].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);
auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[4].ItemId = 40605011; //ZaliZ
if (skinhair != Slotsybc[4].ItemId) {
skinhair = Slotsybc[4].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);
auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[5].ItemId = 1404000; 
if (skintop != Slotsybc[5].ItemId) {
skintop = Slotsybc[5].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);
auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[6].ItemId = 1404002; //suit id
if (skindown != Slotsybc[6].ItemId) {
skindown = Slotsybc[6].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
if (localPlayer && localPlayer->AvatarComponent2) {
auto AvatarComp = localPlayer->AvatarComponent2;
FNetAvatarSyncData NetAvatarComp = *(FNetAvatarSyncData*)((uintptr_t)AvatarComp + 0x388);
auto Slotsybc = NetAvatarComp.SlotSyncData;
Slotsybc[7].ItemId = 1404003; //kosi4ki
if (skinboots != Slotsybc[7].ItemId) {
skinboots = Slotsybc[7].ItemId;
localPlayer->AvatarComponent2->OnRep_BodySlotStateChanged();
}
}
}// end skin hack