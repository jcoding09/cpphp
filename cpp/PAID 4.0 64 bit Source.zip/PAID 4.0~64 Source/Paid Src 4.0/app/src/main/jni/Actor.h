#include <vector>
UWorld* GEWorld;
int GWorldNum = 0;
TUObjectArray gobjects;
UWorld* GetWorld()
{
	if (GWorldNum == 0) {
		gobjects = UObject::GUObjectArray->ObjObjects;
		for (int i = 0; i < gobjects.Num(); i++)
			if (auto obj = gobjects.GetByIndex(i)) {
				if (obj->IsA(UEngine::StaticClass())) {
					auto GEngine = (UEngine*)obj;
					if (GEngine) {
						auto ViewPort = GEngine->GameViewport;
						if (ViewPort)
						{
							GEWorld = ViewPort->World;
							GWorldNum = i;
							return ViewPort->World;
						}
					}
				}
			}
	}
	else {
		auto GEngine = (UEngine*)(gobjects.GetByIndex(GWorldNum));
		if (GEngine) {
			auto ViewPort = GEngine->GameViewport;
			if (ViewPort) {
				GEWorld = ViewPort->World;
				return ViewPort->World;
			}
		}
	}
	return 0;
}

std::vector<AActor*> GetActors()
{
	auto World = GetWorld();
	if (!World)
		return std::vector<AActor*>();
	auto PersistentLevel = World->PersistentLevel;
	if (!PersistentLevel)
		return std::vector<AActor*>();
	auto Actors = *(TArray<AActor*> *)((uintptr_t)PersistentLevel + 0xA0);
	std::vector<AActor*> actors;
	for (int i = 0; i < Actors.Num(); i++)
	{
		auto Actor = Actors[i];
		if (Actor)
		{
			actors.push_back(Actor);
		}
	}
	return actors;
}

template <class T>
void GetAllActors(std::vector<T*>& Actors)
{
	UGameplayStatics* gGameplayStatics = (UGameplayStatics*)gGameplayStatics->StaticClass();
	auto GWorld = GetWorld();
	if (GWorld)
	{
		TArray<AActor*> Actors2;
		gGameplayStatics->GetAllActorsOfClass((UObject*)GWorld, T::StaticClass(), &Actors2);
		for (int i = 0; i < Actors2.Num(); i++)
		{
			Actors.push_back((T*)Actors2[i]);
		}
	}
}

FVector GetBoneLocation(ASTExtraPlayerCharacter* Actor, const char* BoneName)
{
	return Actor->GetBonePos(BoneName, FVector());
}

void NekoHook(FRotator& angles) {
	if (angles.Pitch > 180)
		angles.Pitch -= 360;
	if (angles.Pitch < -180)
		angles.Pitch += 360;

	if (angles.Pitch < -75.f)
		angles.Pitch = -75.f;
	else if (angles.Pitch > 75.f)
		angles.Pitch = 75.f;

	while (angles.Yaw < -180.0f)
		angles.Yaw += 360.0f;
	while (angles.Yaw > 180.0f)
		angles.Yaw -= 360.0f;
}
void NekoHook(float* angles) {
	if (angles[0] > 180)
		angles[0] -= 360;
	if (angles[0] < -180)
		angles[0] += 360;

	if (angles[0] < -75.f)
		angles[0] = -75.f;
	else if (angles[0] > 75.f)
		angles[0] = 75.f;

	while (angles[1] < -180.0f)
		angles[1] += 360.0f;
	while (angles[1] > 180.0f)
		angles[1] -= 360.0f;
}

void NekoHook(FVector2D angles) {
	if (angles.X > 180)
		angles.X -= 360;
	if (angles.X < -180)
		angles.X += 360;

	if (angles.X < -75.f)
		angles.X = -75.f;
	else if (angles.X > 75.f)
		angles.X = 75.f;

	while (angles.Y < -180.0f)
		angles.Y += 360.0f;
	while (angles.Y > 180.0f)
		angles.Y -= 360.0f;
}

const char *GetLootName(APickUpListWrapperActor *Loot) {
    switch (Loot->BoxType) {
    case EPickUpBoxType::EPickUpBoxType__EPickUpBoxType_TombBox:
        return "DEADBOX";
    case EPickUpBoxType::EPickUpBoxType__EPickUpBoxType_AirDropBox:
        return "DROP";
    default:
        return "BOX";
    }
}
