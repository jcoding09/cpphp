static int helmett3 = 0;
static int bag3 = 0;
int sEmote1 = 2200101;
int sEmote2 = 2200201;
int sEmote3 = 2200301;
bool ModSkinnn = false;
int ModEmote1 = 0;
#include "jsonPreferences.h"
#include "FFCSKIN.h"
static int skinxsuit = 0;
static int skintop = 0;
static int skindown = 0;
static int skinhair = 0;
static int skinface = 0;
static int skinhead = 0;
static int skinboots = 0;
static int skinmask = 0;
static int skinset = 0;
bool deadboxskin;
int MenuSkinSelecttt;
bool ModSkinn = false;
bool KillMessage = false;
bool LobbySkin = false;
bool DeasBoxSkin = false; 
bool suitandolayermenu,weaponskinmenu,carskinmenu;
std::string strSkinTestWeaponIdd;
std::string strSkinTest;
bool Skins;
bool Boxx;
bool PlayerMenu;
bool WeaponMenu;
bool WeaponMenu1;
bool VehicleMenu;
namespace Active {inline int SkinCarDefault = 0;inline int SkinCarMod = 0;inline int SkinCarNew = 0;}
namespace CauserDeadBox {inline bool Active = false;inline std::string KillByWeaponID = "";inline int CurBulletNumInClipNew = 0;inline int CurBulletNumInClipLast = 0;inline UDeadBoxAvatarComponent * DeadBoxPointer = 0;}
