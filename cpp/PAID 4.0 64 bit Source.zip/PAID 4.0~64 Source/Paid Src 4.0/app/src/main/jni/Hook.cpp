#include <jni.h>
#include <string>
#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <thread>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <unistd.h>
#include <sys/mman.h>
#include <cstdlib>
#include <iostream>
#include <unordered_map>
#include <string>
#include <cstdlib>
#include <ctime>
#include <dlfcn.h>
#include "Main/Tools.h" 
#include "Main/Logger.h"
#include "Main/oxorany.h"
#include "Main/obfuscate.h"
#include "Main/Utils.h"
#include "Main/KittyMemory/MemoryPatch.h"
#define targetLibName oxorany("libUE4.so")
#include "Main/Macros.h"
#define ARM64_SYSREG(reg0, reg1, reg2, reg3, op) (((reg0) & 0x1F) | (((reg1) & 0x1F) << 5) | (((reg2) & 0x7) << 10) | (((reg3) & 0xF) << 16) | (((op) & 0x7) << 20))

#ifdef __aarch64__
uint64_t _ReadStatusReg(uint64_t reg) {
    return 0;
}
#endif
char *Offset;
#define ret_zero
#define _BYTE  uint8_t
#define _WORD  uint16_t
#define _DWORD uint32_t
#define _QWORD __int64
#define _OWORD uint64_t
#define _QWORD uint64_t
#define _BOOL8 uint64_t
#define _QWORD uint64_t
#define targetLibName oxorany("libUE4.so")
#define targetLibName oxorany("libanogs.so")
#define targetLibName oxorany("libanort.so")
#define targetLibName oxorany("libhdmpve.so")
#define targetLibName ("libTBlueData.so")
#define targetLibName ("libRoosterNN.so")
#define targetLibName ("libhdmpve.so")
#define targetLibName ("libCrashKit.so")
#define targetLibName ("libITOP.so")
#define targetLibName ("libAntsVoice.so")
#define word_DA09BD0
#define waitpid
#define asc_39C9BD9
#define off_D6D7F60
#define unk_38D9882
#define qword_50CBD58
#define JUMPOUT
#define xmmword
#define LODWORD
#define __clz
#define unk_38D9882
#define _WriteStatusReg

DWORD TBlueBase = 0;
DWORD AntBase = 0;
DWORD BufferBase = 0;
DWORD HdmpveBase = 0;
DWORD roosterBase = 0;
DWORD roosterSize = 0;
DWORD roosterAlloc = 0;
DWORD EGLBase = 0;
DWORD EGLSize = 0;
DWORD EGLAlloc = 0;
DWORD libEgl_base = 0;
DWORD libcBase = 0;
DWORD libcSize = 0;
DWORD libcAlloc = 0;
DWORD libanogsBase = 0;
DWORD libTBlueDataBase = 0;
DWORD libUE4Base = 0;
DWORD libanortBase = 0;
DWORD libEGLBase = 0;
DWORD libanogsAlloc = 0;
DWORD libUE4Alloc = 0;
DWORD libEGLAlloc = 0;
DWORD libanogsSize = 0; //0x51CCBC;  //3.9.0
DWORD libUE4Size = 0;//0xBFDD568;	//3.9.0
DWORD NewBase = 0;

size_t getLibrarySize(const char *libraryName)
{
    FILE *mapsFile = fopen("/proc/self/maps", "r");
    if (mapsFile == nullptr)
    {
        return 0;
    }

    char line[256];
    size_t size = 0;
    uintptr_t startAddr = 0, endAddr = 0;
    while (fgets(line, sizeof(line), mapsFile))
    {
        if (strstr(line, libraryName))
        {
            sscanf(line, "%lx-%lx", &startAddr, &endAddr);
            size = endAddr - startAddr;
            break;
        }
    }

    fclose(mapsFile);
    return size;
}

void chfiles(){

    char mode[] = "0555";
    char *path = "/data/data/com.pubg.imobile/files/ano_tmp";
    char *path2 = "/data/data/com.pubg.imobile/files";
    int m = strtol(mode,0,8);
    while(true){
        chmod(path,m);
        chmod(path2,m);
        sleep(1);
    }

}
void chRestore(){
    char mode[] = "0777";
    char *path = "/data/data/com.pubg.imobile/files/ano_tmp";
    char *path2 = "/data/data/com.pubg.imobile/files";
    int m = strtol(mode,0,8);
    chmod(path,m);
    chmod(path2,m);
    LOGI(OBFUSCATE("permissions restored"));
}

void *anogs_thread(void *) {
    while (!isLibraryLoaded("libUE4.so")) { sleep(1); }
	while (!isLibraryLoaded("libanogs.so")) { sleep(1); }
	while (!isLibraryLoaded("libanort.so")) { sleep(1); }
	//system("chmod 000 /data/data/com.pubg.imobile/files/ano_tmp");
	libanogsBase = findLibrary(oxorany("libanogs.so"));
    libUE4Base = findLibrary(oxorany("libUE4.so"));
    TBlueBase = findLibrary(oxorany("libTBlueData.so"));
    libanortBase = findLibrary(oxorany("libanort.so"));
    AntBase = findLibrary(oxorany("libAntsVoice.so"));
    HdmpveBase = findLibrary(oxorany("libhdmpve.so"));
    libcBase = findLibrary(oxorany("libc.so"));
    libanogsSize = getLibrarySize(oxorany("libanogs.so"));
    libUE4Size =   getLibrarySize(oxorany("libUE4.so"));
    libanogsAlloc = (DWORD)malloc(libanogsSize);
    libUE4Alloc   = (DWORD)malloc(libUE4Size);
    memcpy((void *)libanogsAlloc, (void *)libanogsBase, libanogsSize);
    memcpy((void *)libUE4Alloc, (void *)libUE4Base, libUE4Size);
    void *handle = dlopen(oxorany("libc.so"), 4);
    void *memcpy_addr = dlsym(handle, oxorany("memcpy"));
	void *pthread_create_addr = dlsym(handle, oxorany("pthread_create"));
    void *inet_pton_addr = dlsym(handle, oxorany("inet_pton"));
	LOGI("ZenX- libsafe loaded....");
	dlclose(handle);

chRestore();//restore permissions
    sleep(55);//lobby wait
    chfiles();//change permissions + 7day fix
    return NULL;
}
__attribute__((constructor))
void lib_main() {

    pthread_t ptid;
    pthread_create(&ptid, NULL, anogs_thread, NULL);
	
}
