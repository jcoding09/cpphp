void (*orig_Broadcast)(ASTExtraPlayerController* thiz, struct FFatalDamageParameter* FatalDamageParameter);
void hk_Broadcast(ASTExtraPlayerController* thiz, struct FFatalDamageParameter* FatalDamageParameter) {
if (ModSkinn && KillMessage){
if (g_PlayerController->PlayerKey == FatalDamageParameter->CauserKey) {
if (g_LocalPlayer -> WeaponManagerComponent) {
if (g_LocalPlayer -> WeaponManagerComponent -> CurrentWeaponReplicated) {
CauserDeadBox::KillByWeaponID = std::to_string((int) g_LocalPlayer -> WeaponManagerComponent -> CurrentWeaponReplicated -> GetWeaponID());
CauserDeadBox::CurBulletNumInClipNew = ((ASTExtraShootWeapon * ) g_LocalPlayer -> WeaponManagerComponent -> CurrentWeaponReplicated) -> CurBulletInClip.CurBulletNumInClip;
}
int KillMsgSkinId = 0;
int KillMsgSkinIdd = 0;
if (preferences.Config.Skin.XSuits >= 1)
KillMsgSkinIdd = new_Skin.XSuits;
if (strstr(CauserDeadBox::KillByWeaponID.c_str(), "103007")) {
if (preferences.Config.Skin.MK14 >= 1)
KillMsgSkinId = new_Skin.MK14;
}
if (strstr(CauserDeadBox::KillByWeaponID.c_str(), "105010")) {
if (preferences.Config.Skin.MG3 >= 1)
KillMsgSkinId = new_Skin.MG3;
}
if (strstr(CauserDeadBox::KillByWeaponID.c_str(), "102105")) {
if (preferences.Config.Skin.P90 >= 1)
KillMsgSkinId = new_Skin.P90;
}
if (strstr(CauserDeadBox::KillByWeaponID.c_str(), "103007")) {
if (preferences.Config.Skin.MK14 >= 1)
KillMsgSkinId = new_Skin.MK14;
}
if (strstr(CauserDeadBox::KillByWeaponID.c_str(), "101001")) {
if (preferences.Config.Skin.AKM >= 1)
KillMsgSkinId = new_Skin.AKM;
}
if (strstr(CauserDeadBox::KillByWeaponID.c_str(), "101002")) {
if (preferences.Config.Skin.M16A4 >= 1)
KillMsgSkinId = new_Skin.M16A4;
}
if (strstr(CauserDeadBox::KillByWeaponID.c_str(), "101003")) {
if (preferences.Config.Skin.Scar >= 1)
KillMsgSkinId = new_Skin.Scar;
}
if (strstr(CauserDeadBox::KillByWeaponID.c_str(), "101004")) {
if (preferences.Config.Skin.M416 >= 1)
KillMsgSkinId = new_Skin.M416_1;
}
if (strstr(CauserDeadBox::KillByWeaponID.c_str(), "101005")) {
if (preferences.Config.Skin.Groza >= 1)
KillMsgSkinId = new_Skin.Groza;
}
if (strstr(CauserDeadBox::KillByWeaponID.c_str(), "101006")) {
if (preferences.Config.Skin.AUG >= 1)
KillMsgSkinId = new_Skin.AUG;
}
if (strstr(CauserDeadBox::KillByWeaponID.c_str(), "101008")) {
if (preferences.Config.Skin.M762 >= 1)
KillMsgSkinId = new_Skin.M762;
}
if (strstr(CauserDeadBox::KillByWeaponID.c_str(), "101102")) {
if (preferences.Config.Skin.ACE32 >= 1)
KillMsgSkinId = new_Skin.ACE32;
}
if (strstr(CauserDeadBox::KillByWeaponID.c_str(), "102001")) {
if (preferences.Config.Skin.UZI >= 1)
KillMsgSkinId = new_Skin.UZI;
}
if (strstr(CauserDeadBox::KillByWeaponID.c_str(), "102002")) {
if (preferences.Config.Skin.UMP >= 1)
KillMsgSkinId = new_Skin.UMP;
}
if (strstr(CauserDeadBox::KillByWeaponID.c_str(), "102003")) {
if (preferences.Config.Skin.Vector >= 1)
KillMsgSkinId = new_Skin.Vector;
}
if (strstr(CauserDeadBox::KillByWeaponID.c_str(), "102004")) {
if (preferences.Config.Skin.Thompson >= 1)
KillMsgSkinId = new_Skin.Thompson;
}
if (strstr(CauserDeadBox::KillByWeaponID.c_str(), "102005")) {
if (preferences.Config.Skin.Bizon >= 1)
KillMsgSkinId = new_Skin.Bizon;
}
if (strstr(CauserDeadBox::KillByWeaponID.c_str(), "103001")) {
if (preferences.Config.Skin.K98 >= 1)
KillMsgSkinId = new_Skin.K98;
}
if (strstr(CauserDeadBox::KillByWeaponID.c_str(), "103002")) {
if (preferences.Config.Skin.M24 >= 1)
KillMsgSkinId = new_Skin.M24;
}
if (strstr(CauserDeadBox::KillByWeaponID.c_str(), "103003")) {
if (preferences.Config.Skin.AWM >= 1)
KillMsgSkinId = new_Skin.AWM;
}
if (strstr(CauserDeadBox::KillByWeaponID.c_str(), "105002")) {
if (preferences.Config.Skin.DP28 >= 1)
KillMsgSkinId = new_Skin.DP28;
}
if (strstr(CauserDeadBox::KillByWeaponID.c_str(), "105001")) {
if (preferences.Config.Skin.M249 >= 1)
KillMsgSkinId = new_Skin.M249;
}
if (strstr(CauserDeadBox::KillByWeaponID.c_str(), "108004")) {
if (preferences.Config.Skin.Pan >= 1)
KillMsgSkinId = new_Skin.Pan;
}
FatalDamageParameter->CauserWeaponAvatarID = KillMsgSkinId;
FatalDamageParameter->CauserClothAvatarID = KillMsgSkinIdd;
}
}
}
return orig_Broadcast(thiz, FatalDamageParameter);
}
static int prevXSuits = preferences.Config.Skin.XSuits;
static auto start = std::chrono::high_resolution_clock::now();
static bool callFunction = false;
static bool callNotify = false;
static bool callModSkin = false;
// ================================================================================================================================ //
std::chrono::steady_clock::time_point lastChangeTime;
