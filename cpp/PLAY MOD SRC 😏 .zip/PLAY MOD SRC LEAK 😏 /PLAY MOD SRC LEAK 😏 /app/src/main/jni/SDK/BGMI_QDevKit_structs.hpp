#pragma once

// PUBG MOBILE (3.8.0) TG @Mrkaushikhaxor  
// 时间 Thu May 15 09:51:51 2025
 
namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum QDevKit.EQFirebaseRemoteConfigStatus
enum class EQFirebaseRemoteConfigStatus : uint8_t
{
	EQFirebaseRemoteConfigStatus__kUnfetched = 0,
	EQFirebaseRemoteConfigStatus__kFetchedSuccessfully = 1,
	EQFirebaseRemoteConfigStatus__kFetchedFailed = 2,
	EQFirebaseRemoteConfigStatus__EQFirebaseRemoteConfigStatus_MAX = 3
};



}

